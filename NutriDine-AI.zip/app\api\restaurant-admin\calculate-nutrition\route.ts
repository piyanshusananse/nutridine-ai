import { calculateRecipeNutrition, MASTER_INGREDIENTS } from '@/lib/engine/ingredient-calculator';
import { NextResponse } from 'next/server';

export async function GET() {
  // Returns master ingredients catalog for the restaurant owner dropdown
  try {
    const list = Object.values(MASTER_INGREDIENTS).map((item) => ({
      id: item.id,
      name: item.name,
      category: item.category,
      caloriesPer100g: item.caloriesPer100g,
      proteinPer100g: item.proteinPer100g,
      carbsPer100g: item.carbsPer100g,
      fatPer100g: item.fatPer100g,
      fiberPer100g: item.fiberPer100g,
      sodiumMgPer100g: item.sodiumMgPer100g,
      allergens: item.allergens,
      isVegetarian: item.isVegetarian,
      isVegan: item.isVegan,
      isGlutenFree: item.isGlutenFree,
      isJainFriendly: item.isJainFriendly,
    }));

    return NextResponse.json({ success: true, ingredients: list });
  } catch (error) {
    console.error('Error fetching master ingredients:', error);
    return NextResponse.json(
      { success: false, error: { code: 'FETCH_ERROR', message: 'Failed to fetch ingredients catalog.' } },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { items } = body; // Array of { ingredientKey: string, quantityGrams: number }

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: { code: 'VALIDATION_ERROR', message: 'Please provide an array of ingredients with quantities in grams.' },
        },
        { status: 400 }
      );
    }

    const calculated = calculateRecipeNutrition(items);

    return NextResponse.json({
      success: true,
      nutritionSource: 'ESTIMATED',
      disclaimer: 'Calculated from standard ingredient composition database. Actual values may vary based on specific cooking techniques.',
      calculatedNutrition: calculated,
    });
  } catch (error) {
    console.error('Error calculating recipe nutrition:', error);
    return NextResponse.json(
      { success: false, error: { code: 'CALC_ERROR', message: 'Failed to calculate nutrition from ingredients.' } },
      { status: 500 }
    );
  }
}
