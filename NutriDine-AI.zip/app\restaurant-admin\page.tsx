'use client';

import { MASTER_INGREDIENTS } from '@/lib/engine/ingredient-calculator';
import { useUser } from '@/context/UserContext';
import {
  AlertCircle,
  BarChart3,
  Calculator,
  CheckCircle2,
  ChefHat,
  FileSpreadsheet,
  Layers,
  Plus,
  RefreshCw,
  Scale,
  Sparkles,
  Store,
  Trash2,
  Upload,
  UtensilsCrossed,
  X,
  Zap,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';

interface RecipeRow {
  ingredientKey: string;
  quantityGrams: number;
}

export default function RestaurantAdminPage() {
  const { showToast } = useUser();

  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string>('rest-mumbai-spice');
  const [restaurantData, setRestaurantData] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'DISHES' | 'CALCULATOR' | 'ADD_DISH' | 'IMPORT' | 'ANALYTICS'>('DISHES');
  const [isLoading, setIsLoading] = useState(false);

  // Add Dish Form State
  const [dishName, setDishName] = useState('');
  const [categoryName, setCategoryName] = useState('Tandoor & Starters');
  const [price, setPrice] = useState('280');
  const [servingSize, setServingSize] = useState('1 serving (300g)');
  const [calories, setCalories] = useState('350');
  const [protein, setProtein] = useState('38');
  const [carbs, setCarbs] = useState('12');
  const [fat, setFat] = useState('14');
  const [fiber, setFiber] = useState('4');
  const [sodium, setSodium] = useState('450');
  const [ingredients, setIngredients] = useState('Chicken, yogurt, spices, garlic, lemon');
  const [allergens, setAllergens] = useState('DAIRY');
  const [isVeg, setIsVeg] = useState(false);
  const [isVegan, setIsVegan] = useState(false);
  const [isGf, setIsGf] = useState(true);
  const [prepMethod, setPrepMethod] = useState('Tandoori Grilled');
  const [nutritionSource, setNutritionSource] = useState<'EXACT' | 'RESTAURANT_PROVIDED' | 'ESTIMATED' | 'AI_ESTIMATED'>('RESTAURANT_PROVIDED');

  // Ingredient Calculator State
  const [recipeRows, setRecipeRows] = useState<RecipeRow[]>([
    { ingredientKey: 'paneer', quantityGrams: 150 },
    { ingredientKey: 'bell_pepper', quantityGrams: 50 },
    { ingredientKey: 'onion', quantityGrams: 40 },
    { ingredientKey: 'mustard_oil', quantityGrams: 10 },
    { ingredientKey: 'curd_dahi', quantityGrams: 30 },
  ]);
  const [calculatedRecipe, setCalculatedRecipe] = useState<any>(null);
  const [isCalculatingRecipe, setIsCalculatingRecipe] = useState(false);

  // Import State
  const [importFormat, setImportFormat] = useState<'json' | 'csv'>('csv');
  const [importRawText, setImportRawText] = useState(
    `Name,Category,Price,Ingredients,Calories,Protein\nGrilled Salmon Skewers,Starters,380,"Salmon, lemon, dill, olive oil",320,38\nHerb Quinoa Bowl,Mains,290,"Quinoa, kale, avocado, tahini",460,18`
  );

  useEffect(() => {
    async function loadRestaurants() {
      try {
        const res = await fetch('/api/restaurants');
        const data = await res.json();
        if (data.success && data.restaurants.length > 0) {
          setRestaurants(data.restaurants);
          setSelectedRestaurantId(data.restaurants[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    }
    loadRestaurants();
  }, []);

  const loadMenu = async () => {
    if (!selectedRestaurantId) return;
    setIsLoading(true);
    try {
      const res = await fetch(`/api/restaurants/${selectedRestaurantId}`);
      const data = await res.json();
      if (data.success) {
        setRestaurantData(data.restaurant);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMenu();
  }, [selectedRestaurantId]);

  // Ingredient Calculator Handlers
  const handleAddRecipeRow = () => {
    setRecipeRows([...recipeRows, { ingredientKey: 'paneer', quantityGrams: 50 }]);
  };

  const handleRemoveRecipeRow = (idx: number) => {
    setRecipeRows(recipeRows.filter((_, i) => i !== idx));
  };

  const handleUpdateRecipeRow = (idx: number, key: string, grams: number) => {
    const updated = [...recipeRows];
    updated[idx] = { ingredientKey: key, quantityGrams: grams };
    setRecipeRows(updated);
  };

  const handleCalculateRecipe = async () => {
    setIsCalculatingRecipe(true);
    try {
      const res = await fetch('/api/restaurant-admin/calculate-nutrition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: recipeRows }),
      });
      const json = await res.json();
      if (json.success) {
        setCalculatedRecipe(json.calculatedNutrition);
        showToast('Nutrition computed from ingredient breakdown!');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsCalculatingRecipe(false);
    }
  };

  const handleApplyCalculatedToDishForm = () => {
    if (!calculatedRecipe) return;
    setCalories(calculatedRecipe.calories.toString());
    setProtein(calculatedRecipe.protein.toString());
    setCarbs(calculatedRecipe.carbohydrates.toString());
    setFat(calculatedRecipe.fat.toString());
    setFiber(calculatedRecipe.fiber.toString());
    setSodium(calculatedRecipe.sodium.toString());
    setAllergens(calculatedRecipe.allergens.join(', '));
    setIsVeg(calculatedRecipe.isVegetarian);
    setIsVegan(calculatedRecipe.isVegan);
    setIsGf(calculatedRecipe.isGlutenFree);
    setNutritionSource('ESTIMATED');
    setServingSize(`${calculatedRecipe.totalWeightGrams}g portion`);

    const ingredientNames = calculatedRecipe.itemizedBreakdown.map(
      (b: any) => `${b.name} (${b.quantityGrams}g)`
    );
    setIngredients(ingredientNames.join(', '));

    setActiveTab('ADD_DISH');
    showToast('Applied calculated nutrition values to dish form!');
  };

  // Create Dish Handler
  const handleCreateDish = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/restaurant-admin/dishes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: selectedRestaurantId,
          name: dishName,
          categoryName,
          price: parseFloat(price),
          servingSize,
          calories: parseInt(calories, 10),
          protein: parseFloat(protein),
          carbohydrates: parseFloat(carbs),
          fat: parseFloat(fat),
          fiber: parseFloat(fiber),
          sodium: parseFloat(sodium),
          ingredients,
          allergens,
          isVegetarian: isVeg,
          isVegan: isVegan,
          isGlutenFree: isGf,
          preparationMethod: prepMethod,
          nutritionSource,
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast(`"${dishName}" saved to menu successfully!`);
        setDishName('');
        setActiveTab('DISHES');
        loadMenu();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Dish Handler
  const handleDeleteDish = async (dishId: string, name: string) => {
    if (!confirm(`Are you sure you want to delete "${name}" from this menu?`)) return;
    try {
      const res = await fetch(`/api/restaurant-admin/dishes?id=${dishId}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success) {
        showToast(`"${name}" removed from menu.`);
        loadMenu();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Import Menu Handler
  const handleImport = async () => {
    try {
      const res = await fetch('/api/restaurant-admin/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: selectedRestaurantId,
          format: importFormat,
          data: importRawText,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Successfully imported ${data.importedCount} dishes!`);
        setActiveTab('DISHES');
        loadMenu();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
            <Store className="w-3.5 h-3.5" />
            <span>Restaurant & Kitchen Portal</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black">Menu & Nutrition Management</h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Manage your restaurant profile, calculate dish nutrition from ingredients, and verify allergen tags.
          </p>
        </div>

        {/* Restaurant Selector */}
        <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md p-2 rounded-2xl border border-white/20">
          <Store className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
          <select
            value={selectedRestaurantId}
            onChange={(e) => setSelectedRestaurantId(e.target.value)}
            className="bg-transparent text-white text-xs font-bold focus:outline-none cursor-pointer pr-4"
          >
            {restaurants.map((r) => (
              <option key={r.id} value={r.id} className="text-slate-900 bg-white">
                {r.name} ({r.city})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800 scrollbar-none">
        <button
          onClick={() => setActiveTab('DISHES')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'DISHES'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4" />
          <span>Menu Catalog ({restaurantData?.menuItems?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('CALCULATOR')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'CALCULATOR'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Calculator className="w-4 h-4 text-emerald-500" />
          <span>Ingredient Auto-Calculator 🥗</span>
        </button>

        <button
          onClick={() => setActiveTab('ADD_DISH')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'ADD_DISH'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>Add New Dish</span>
        </button>

        <button
          onClick={() => setActiveTab('IMPORT')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'IMPORT'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Batch CSV Import</span>
        </button>

        <button
          onClick={() => setActiveTab('ANALYTICS')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'ANALYTICS'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Performance Analytics</span>
        </button>
      </div>

      {/* TAB 1: MENU CATALOG */}
      {activeTab === 'DISHES' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black text-slate-900 dark:text-white">
              Dishes at {restaurantData?.name || 'Selected Restaurant'}
            </h2>
            <button
              onClick={() => setActiveTab('ADD_DISH')}
              className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow hover:bg-emerald-700 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Dish</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-4">Dish</th>
                    <th className="p-4">Category</th>
                    <th className="p-4">Price (₹)</th>
                    <th className="p-4">Calories</th>
                    <th className="p-4">Macros (P / C / F)</th>
                    <th className="p-4">Data Source</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {restaurantData?.menuItems?.map((dish: any) => (
                    <tr key={dish.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              dish.imageUrl ||
                              'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80'
                            }
                            alt={dish.name}
                            className="w-10 h-10 rounded-xl object-cover"
                          />
                          <div>
                            <div className="font-extrabold text-slate-900 dark:text-white">{dish.name}</div>
                            <div className="text-[10px] text-slate-400">{dish.servingSize}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-slate-600 dark:text-slate-300 font-medium">
                        {dish.category?.name || 'Mains'}
                      </td>
                      <td className="p-4 font-black text-slate-900 dark:text-white">₹{Math.round(dish.price)}</td>
                      <td className="p-4 font-bold text-slate-900 dark:text-white">{dish.calories} kcal</td>
                      <td className="p-4 text-slate-600 dark:text-slate-300">
                        <span className="text-emerald-600 font-bold">{dish.protein}g</span> /{' '}
                        <span className="text-sky-600 font-bold">{dish.carbohydrates}g</span> /{' '}
                        <span className="text-amber-600 font-bold">{dish.fat}g</span>
                      </td>
                      <td className="p-4">
                        <span
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-black ${
                            dish.nutritionSource === 'ESTIMATED'
                              ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          }`}
                        >
                          {dish.nutritionSource.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => handleDeleteDish(dish.id, dish.name)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Delete Dish"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INGREDIENT AUTO-CALCULATOR */}
      {activeTab === 'CALCULATOR' && (
        <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-bold mb-2">
              <Calculator className="w-3.5 h-3.5" />
              <span>Automated Recipe Nutrition Engine</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              Ingredient Nutrition Auto-Calculator
            </h2>
            <p className="text-xs text-slate-500 max-w-2xl mt-1">
              Add your recipe ingredients and exact gram weights. Our system computes calories, protein, carbohydrates, fats, dietary fiber, sodium, and auto-detects allergens!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Recipe Builder Rows */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Recipe Ingredients & Quantities
                </h3>
                <button
                  type="button"
                  onClick={handleAddRecipeRow}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold flex items-center gap-1 cursor-pointer dark:text-white"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Ingredient</span>
                </button>
              </div>

              <div className="space-y-2">
                {recipeRows.map((row, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700"
                  >
                    <select
                      value={row.ingredientKey}
                      onChange={(e) => handleUpdateRecipeRow(idx, e.target.value, row.quantityGrams)}
                      className="flex-1 bg-white dark:bg-slate-900 px-3 py-2 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 dark:text-white"
                    >
                      {Object.values(MASTER_INGREDIENTS).map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.name} ({item.caloriesPer100g} kcal/100g)
                        </option>
                      ))}
                    </select>

                    <div className="flex items-center gap-1 bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
                      <input
                        type="number"
                        min="1"
                        max="5000"
                        value={row.quantityGrams}
                        onChange={(e) =>
                          handleUpdateRecipeRow(idx, row.ingredientKey, parseInt(e.target.value, 10) || 0)
                        }
                        className="w-16 text-xs font-bold bg-transparent focus:outline-none dark:text-white"
                      />
                      <span className="text-slate-400 text-xs font-bold">g</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveRecipeRow(idx)}
                      className="p-2 text-slate-400 hover:text-rose-600 cursor-pointer"
                      title="Remove ingredient"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleCalculateRecipe}
                  disabled={isCalculatingRecipe}
                  className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Calculator className="w-4 h-4" />
                  <span>Calculate Nutritional Values</span>
                </button>
              </div>
            </div>

            {/* Right: Calculated Summary & Breakdown */}
            <div className="lg:col-span-5 space-y-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
                Calculated Recipe Nutrition
              </h3>

              {calculatedRecipe ? (
                <div className="bg-slate-50 dark:bg-slate-800/80 p-5 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4">
                  <div className="flex items-baseline justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
                    <div>
                      <span className="text-2xl font-black text-slate-900 dark:text-white">
                        {calculatedRecipe.calories} kcal
                      </span>
                      <span className="text-xs text-slate-400 block">Total Serving: {calculatedRecipe.totalWeightGrams}g</span>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-black">
                      ESTIMATED
                    </span>
                  </div>

                  {/* Macros Grid */}
                  <div className="grid grid-cols-3 gap-2 text-xs text-center">
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Protein</span>
                      <span className="font-extrabold text-emerald-600 text-sm">{calculatedRecipe.protein}g</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Carbs</span>
                      <span className="font-extrabold text-sky-600 text-sm">{calculatedRecipe.carbohydrates}g</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Fats</span>
                      <span className="font-extrabold text-amber-600 text-sm">{calculatedRecipe.fat}g</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-center">
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Fibre</span>
                      <span className="font-extrabold text-teal-600 text-xs">{calculatedRecipe.fiber}g</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Sodium</span>
                      <span className="font-extrabold text-slate-700 dark:text-slate-300 text-xs">{calculatedRecipe.sodium}mg</span>
                    </div>
                  </div>

                  {/* Auto-detected badges */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-slate-700 text-xs">
                    <span className="font-bold text-slate-500 text-[11px]">Auto-Detected Classification:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {calculatedRecipe.isVegetarian && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-[10px]">
                          🌱 Vegetarian
                        </span>
                      )}
                      {calculatedRecipe.isVegan && (
                        <span className="px-2 py-0.5 rounded-md bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-300 font-bold text-[10px]">
                          🌿 Vegan
                        </span>
                      )}
                      {calculatedRecipe.isGlutenFree && (
                        <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 font-bold text-[10px]">
                          🌾 Gluten-Free
                        </span>
                      )}
                      {calculatedRecipe.isJainFriendly && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold text-[10px]">
                          ✨ Jain-Friendly
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Allergens */}
                  {calculatedRecipe.allergens && calculatedRecipe.allergens.length > 0 && (
                    <div className="space-y-1 text-xs">
                      <span className="font-bold text-rose-600 text-[11px]">Allergens Present:</span>
                      <div className="flex flex-wrap gap-1">
                        {calculatedRecipe.allergens.map((a: string) => (
                          <span
                            key={a}
                            className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-bold text-[10px]"
                          >
                            ⚠️ {a}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Apply Button */}
                  <button
                    type="button"
                    onClick={handleApplyCalculatedToDishForm}
                    className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:text-slate-950 text-white font-extrabold text-xs shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Populate Into Add Dish Form</span>
                  </button>
                </div>
              ) : (
                <div className="bg-slate-50 dark:bg-slate-800/40 p-8 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 text-center space-y-2 text-xs text-slate-400">
                  <Calculator className="w-8 h-8 text-slate-400 mx-auto" />
                  <p>Click &quot;Calculate Nutritional Values&quot; to view real-time macro aggregation.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ADD DISH FORM */}
      {activeTab === 'ADD_DISH' && (
        <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h2 className="text-xl font-black text-slate-900 dark:text-white">Add New Menu Dish</h2>
              <p className="text-xs text-slate-500">
                Enter dish details, or populate directly from the Ingredient Auto-Calculator tab!
              </p>
            </div>

            <button
              type="button"
              onClick={() => setActiveTab('CALCULATOR')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-200 cursor-pointer"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Use Ingredient Auto-Calculator</span>
            </button>
          </div>

          <form onSubmit={handleCreateDish} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Dish Name</label>
                <input
                  type="text"
                  required
                  value={dishName}
                  onChange={(e) => setDishName(e.target.value)}
                  placeholder="e.g. Tandoori Paneer Tikka"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Category</label>
                <input
                  type="text"
                  required
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  placeholder="e.g. Starters"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Price (₹ INR)</label>
                <input
                  type="number"
                  step="1"
                  required
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="320"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
            </div>

            {/* Ingredients & Allergens Box */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Ingredients List
                </label>
                <textarea
                  rows={3}
                  value={ingredients}
                  onChange={(e) => setIngredients(e.target.value)}
                  placeholder="e.g. Paneer (150g), bell pepper, onions, yogurt, spices"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Declared Allergens (e.g. DAIRY, TREE_NUTS, GLUTEN, MUSTARD)
                </label>
                <textarea
                  rows={3}
                  value={allergens}
                  onChange={(e) => setAllergens(e.target.value)}
                  placeholder="e.g. DAIRY, MUSTARD"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
            </div>

            {/* Macro Inputs */}
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 pt-2">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Calories (kcal)</label>
                <input
                  type="number"
                  value={calories}
                  onChange={(e) => setCalories(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Protein (g)</label>
                <input
                  type="number"
                  step="0.1"
                  value={protein}
                  onChange={(e) => setProtein(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Carbs (g)</label>
                <input
                  type="number"
                  step="0.1"
                  value={carbs}
                  onChange={(e) => setCarbs(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Fat (g)</label>
                <input
                  type="number"
                  step="0.1"
                  value={fat}
                  onChange={(e) => setFat(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Fiber (g)</label>
                <input
                  type="number"
                  step="0.1"
                  value={fiber}
                  onChange={(e) => setFiber(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Nutrition Source</label>
                <select
                  value={nutritionSource}
                  onChange={(e) => setNutritionSource(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white font-bold"
                >
                  <option value="ESTIMATED">Calculated (Estimated)</option>
                  <option value="RESTAURANT_PROVIDED">Restaurant-Provided</option>
                  <option value="EXACT">Lab Verified</option>
                </select>
              </div>
            </div>

            {/* Checkboxes */}
            <div className="flex flex-wrap gap-4 pt-2">
              <label className="flex items-center gap-2 cursor-pointer font-bold">
                <input type="checkbox" checked={isVeg} onChange={(e) => setIsVeg(e.target.checked)} />
                <span>Vegetarian</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer font-bold">
                <input type="checkbox" checked={isVegan} onChange={(e) => setIsVegan(e.target.checked)} />
                <span>Vegan</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer font-bold">
                <input type="checkbox" checked={isGf} onChange={(e) => setIsGf(e.target.checked)} />
                <span>Gluten-Free</span>
              </label>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                type="submit"
                className="px-8 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-lg shadow-emerald-600/20 cursor-pointer"
              >
                Save Dish to Menu
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 4: BATCH CSV IMPORT */}
      {activeTab === 'IMPORT' && (
        <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">Batch Import Menu</h2>
            <p className="text-xs text-slate-500">
              Import full restaurant menus via CSV or JSON.
            </p>
          </div>

          <textarea
            rows={8}
            value={importRawText}
            onChange={(e) => setImportRawText(e.target.value)}
            className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
          />

          <div className="flex justify-end">
            <button
              onClick={handleImport}
              className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-lg shadow-emerald-600/20 cursor-pointer"
            >
              Process & Import Menu
            </button>
          </div>
        </div>
      )}

      {/* TAB 5: DISH ANALYTICS */}
      {activeTab === 'ANALYTICS' && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Top Recommended Dish</span>
            <div className="text-xl font-black text-emerald-600">Tandoori Chicken Tikka</div>
            <p className="text-xs text-slate-500">96% average goal match across 140+ diners</p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Most Popular Filter</span>
            <div className="text-xl font-black text-sky-600">High Protein (&gt;35g)</div>
            <p className="text-xs text-slate-500">62% of diners enable protein optimization</p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Top Allergen Filtered</span>
            <div className="text-xl font-black text-rose-600">Peanuts & Gluten</div>
            <p className="text-xs text-slate-500">Auto-excluded accurately for allergic diners</p>
          </div>
        </div>
      )}
    </div>
  );
}
