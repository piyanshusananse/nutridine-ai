'use client';

import { PRESET_PERSONAS, useUser } from '@/context/UserContext';
import { ActivityLevel, AllergenType, DietaryPreferenceType, Sex, UserGoal } from '@/lib/engine/types';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Flame,
  Layers,
  Lock,
  Scale,
  ShieldAlert,
  Sparkles,
  Trash2,
  User,
  Zap,
} from 'lucide-react';
import React, { useState } from 'react';

const ALLERGEN_OPTIONS: { id: AllergenType; label: string }[] = [
  { id: 'PEANUTS', label: 'Peanuts' },
  { id: 'TREE_NUTS', label: 'Tree Nuts' },
  { id: 'DAIRY', label: 'Dairy' },
  { id: 'EGGS', label: 'Eggs' },
  { id: 'SOY', label: 'Soy' },
  { id: 'GLUTEN', label: 'Gluten / Wheat' },
  { id: 'SHELLFISH', label: 'Shellfish' },
  { id: 'FISH', label: 'Fish' },
  { id: 'SESAME', label: 'Sesame' },
  { id: 'MUSTARD', label: 'Mustard' },
];

const DIETARY_OPTIONS: { id: DietaryPreferenceType; label: string }[] = [
  { id: 'NON_VEGETARIAN', label: 'Non-Vegetarian' },
  { id: 'VEGETARIAN', label: 'Vegetarian' },
  { id: 'VEGAN', label: 'Vegan' },
  { id: 'EGGETARIAN', label: 'Eggetarian' },
  { id: 'PESCATARIAN', label: 'Pescatarian' },
  { id: 'JAIN', label: 'Jain' },
  { id: 'HALAL', label: 'Halal' },
  { id: 'GLUTEN_FREE', label: 'Gluten-Free' },
  { id: 'LACTOSE_FREE', label: 'Lactose-Free' },
  { id: 'LOW_CARB', label: 'Low-Carb / Keto' },
];

export default function ProfilePage() {
  const { activePersona, userProfile, bmi, energyNeeds, switchPersona, updateProfile, showToast } =
    useUser();

  const [name, setName] = useState(userProfile.name);
  const [age, setAge] = useState(userProfile.age);
  const [sex, setSex] = useState<Sex>(userProfile.sex);
  const [heightCm, setHeightCm] = useState(userProfile.heightCm);
  const [weightKg, setWeightKg] = useState(userProfile.weightKg);
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(userProfile.activityLevel);
  const [goal, setGoal] = useState<UserGoal>(userProfile.goal);
  const [calorieOverride, setCalorieOverride] = useState(
    userProfile.targetCaloriesOverride?.toString() || ''
  );
  const [dietaryPrefs, setDietaryPrefs] = useState<DietaryPreferenceType[]>(
    userProfile.dietaryPreferences || []
  );
  const [allergies, setAllergies] = useState<AllergenType[]>(userProfile.allergies || []);

  const toggleDietary = (pref: DietaryPreferenceType) => {
    if (dietaryPrefs.includes(pref)) {
      setDietaryPrefs(dietaryPrefs.filter((p) => p !== pref));
    } else {
      setDietaryPrefs([...dietaryPrefs, pref]);
    }
  };

  const toggleAllergy = (a: AllergenType) => {
    if (allergies.includes(a)) {
      setAllergies(allergies.filter((x) => x !== a));
    } else {
      setAllergies([...allergies, a]);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      age: Number(age),
      sex,
      heightCm: Number(heightCm),
      weightKg: Number(weightKg),
      activityLevel,
      goal,
      targetCaloriesOverride: calorieOverride ? parseInt(calorieOverride, 10) : null,
      dietaryPreferences: dietaryPrefs,
      allergies,
    });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-black text-slate-900 dark:text-white flex items-center gap-2">
          <User className="w-8 h-8 text-emerald-600" />
          <span>My Profile & Wellness Targets</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Manage your personal body composition inputs, active fitness goals, and allergen safety restrictions.
        </p>
      </div>

      {/* 1. DEMO PERSONA SWITCHER */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 dark:from-emerald-950/40 dark:via-teal-950/20 dark:to-sky-950/20 p-5 sm:p-6 rounded-3xl border border-emerald-200 dark:border-emerald-800/60 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase tracking-wider text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4" />
            Quick Switch Demo Personas
          </span>
          <span className="text-[10px] text-slate-500">Live AI Re-scoring across all menus</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {PRESET_PERSONAS.map((p) => {
            const isSelected = activePersona.id === p.id;
            return (
              <button
                key={p.id}
                onClick={() => {
                  switchPersona(p.id);
                  setName(p.profile.name);
                  setAge(p.profile.age);
                  setSex(p.profile.sex);
                  setHeightCm(p.profile.heightCm);
                  setWeightKg(p.profile.weightKg);
                  setActivityLevel(p.profile.activityLevel);
                  setGoal(p.profile.goal);
                  setDietaryPrefs(p.profile.dietaryPreferences);
                  setAllergies(p.profile.allergies);
                }}
                className={`p-3.5 rounded-2xl text-left border transition-all cursor-pointer flex items-start gap-3 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md font-bold'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-emerald-400 text-slate-800 dark:text-slate-200'
                }`}
              >
                <span className="text-2xl">{p.avatar}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-extrabold text-sm">{p.name}</div>
                  <div className="text-[10px] opacity-80 line-clamp-1">{p.tagline}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. PROFILE EDIT FORM */}
      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Inputs Column */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <h3 className="text-base font-black text-slate-900 dark:text-white">Personal Metrics</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Biological Sex</label>
              <select
                value={sex}
                onChange={(e) => setSex(e.target.value as Sex)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white font-bold"
              >
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Age</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(parseInt(e.target.value, 10) || 25)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Height ({heightCm} cm)
              </label>
              <input
                type="range"
                min={130}
                max={220}
                value={heightCm}
                onChange={(e) => setHeightCm(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600 mt-2"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Weight ({weightKg} kg / {Math.round(weightKg * 2.20462)} lbs)
              </label>
              <input
                type="range"
                min={40}
                max={150}
                value={weightKg}
                onChange={(e) => setWeightKg(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600 mt-2"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Activity Level</label>
              <select
                value={activityLevel}
                onChange={(e) => setActivityLevel(e.target.value as ActivityLevel)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white font-bold"
              >
                <option value="SEDENTARY">Sedentary (1.2x)</option>
                <option value="LIGHT">Lightly Active (1.375x)</option>
                <option value="MODERATE">Moderately Active (1.55x)</option>
                <option value="VERY_ACTIVE">Very Active (1.725x)</option>
                <option value="EXTRA_ACTIVE">Extremely Active (1.9x)</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Primary Goal</label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value as UserGoal)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white font-bold"
              >
                <option value="WEIGHT_LOSS">Weight / Fat Loss</option>
                <option value="MUSCLE_GAIN">Muscle Gain</option>
                <option value="MAINTENANCE">Maintenance</option>
                <option value="BETTER_NUTRITION">Better Nutrition</option>
                <option value="IMPROVED_PROTEIN">Improved Protein</option>
                <option value="BETTER_ENERGY">Better Energy</option>
              </select>
            </div>
          </div>

          {/* Allergies Box */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="font-bold text-rose-700 dark:text-rose-400 text-xs block">
              Declared Allergies (Hard Exclusions)
            </label>
            <div className="flex flex-wrap gap-1.5">
              {ALLERGEN_OPTIONS.map((a) => {
                const isSelected = allergies.includes(a.id);
                return (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => toggleAllergy(a.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {a.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dietary Prefs */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="font-bold text-slate-700 dark:text-slate-300 text-xs block">
              Dietary Lifestyle Preferences
            </label>
            <div className="flex flex-wrap gap-1.5">
              {DIETARY_OPTIONS.map((d) => {
                const isSelected = dietaryPrefs.includes(d.id);
                return (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => toggleDietary(d.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {d.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
            <button
              type="submit"
              className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-lg shadow-emerald-600/20 cursor-pointer"
            >
              Update Profile
            </button>
          </div>
        </div>

        {/* Right Output Calculations Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white">
              Estimated Energy & Targets
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                <span className="text-slate-500">Calculated BMI</span>
                <span className="font-extrabold text-slate-900 dark:text-white">
                  {bmi.bmi} ({bmi.category})
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                <span className="text-slate-500">BMR (Basal Needs)</span>
                <span className="font-extrabold text-slate-900 dark:text-white">{energyNeeds.bmr} kcal/day</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                <span className="text-slate-500">Estimated TDEE</span>
                <span className="font-extrabold text-slate-900 dark:text-white">{energyNeeds.tdee} kcal/day</span>
              </div>
              <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
                <span className="font-bold text-emerald-800 dark:text-emerald-300">Goal Target Calories</span>
                <span className="font-black text-emerald-600 text-base">
                  {energyNeeds.targetCalories} kcal/day
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 flex items-center justify-between">
                <span className="font-bold text-sky-800 dark:text-sky-300">Target Protein Range</span>
                <span className="font-black text-sky-600 text-base">
                  {energyNeeds.proteinRangeMin}–{energyNeeds.proteinRangeMax} g/day
                </span>
              </div>
            </div>

            {/* Optional Calorie Override */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <label className="font-bold text-slate-700 dark:text-slate-300 block">
                Manual Calorie Target Override
              </label>
              <input
                type="number"
                value={calorieOverride}
                onChange={(e) => setCalorieOverride(e.target.value)}
                placeholder="Leave blank to use estimated calories"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
              />
            </div>
          </div>

          {/* Privacy & Data Deletion */}
          <div className="bg-slate-50 dark:bg-slate-900/60 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-slate-900 dark:text-white font-extrabold">
              <Lock className="w-4 h-4 text-emerald-600" />
              <span>Privacy & Security Protection</span>
            </div>
            <p className="text-slate-500 leading-relaxed text-[11px]">
              Your health metrics are stored privately and never exposed publicly or sold to restaurant owners.
            </p>
          </div>
        </div>
      </form>
    </div>
  );
}
