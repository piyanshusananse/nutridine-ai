import prisma from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId') || 'user-alex';
    const date = searchParams.get('date') || new Date().toISOString().split('T')[0];

    const logs = await prisma.foodLog.findMany({
      where: {
        userId,
        date,
      },
      orderBy: {
        createdAt: 'asc',
      },
    });

    const summary = logs.reduce(
      (acc, item) => ({
        calories: acc.calories + item.calories * item.quantity,
        protein: acc.protein + item.protein * item.quantity,
        carbs: acc.carbs + item.carbs * item.quantity,
        fat: acc.fat + item.fat * item.quantity,
        fiber: acc.fiber + item.fiber * item.quantity,
        sodium: acc.sodium + item.sodium * item.quantity,
        sugar: acc.sugar + item.sugar * item.quantity,
      }),
      { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sodium: 0, sugar: 0 }
    );

    return NextResponse.json({
      success: true,
      date,
      logs,
      summary: {
        calories: Math.round(summary.calories),
        protein: Number(summary.protein.toFixed(1)),
        carbs: Number(summary.carbs.toFixed(1)),
        fat: Number(summary.fat.toFixed(1)),
        fiber: Number(summary.fiber.toFixed(1)),
        sodium: Math.round(summary.sodium),
        sugar: Number(summary.sugar.toFixed(1)),
      },
    });
  } catch (error) {
    console.error('Error fetching food logs:', error);
    return NextResponse.json(
      { success: false, error: { code: 'FETCH_ERROR', message: 'Failed to fetch daily food logs.' } },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      userId = 'user-alex',
      menuItemId,
      dishName,
      restaurantName,
      mealType = 'LUNCH',
      calories,
      protein,
      carbs,
      fat,
      fiber = 0,
      sodium = 0,
      sugar = 0,
      quantity = 1,
      date = new Date().toISOString().split('T')[0],
    } = body;

    if (!dishName || calories === undefined || protein === undefined) {
      return NextResponse.json(
        {
          success: false,
          error: { code: 'VALIDATION_ERROR', message: 'Dish name, calories, and protein are required.' },
        },
        { status: 400 }
      );
    }

    const newLog = await prisma.foodLog.create({
      data: {
        userId,
        menuItemId: menuItemId || null,
        dishName,
        restaurantName: restaurantName || 'Custom Dish',
        mealType,
        calories: parseInt(calories, 10),
        protein: parseFloat(protein),
        carbs: parseFloat(carbs || 0),
        fat: parseFloat(fat || 0),
        fiber: parseFloat(fiber || 0),
        sodium: parseFloat(sodium || 0),
        sugar: parseFloat(sugar || 0),
        quantity: parseInt(quantity, 10) || 1,
        date,
      },
    });

    return NextResponse.json({ success: true, log: newLog }, { status: 201 });
  } catch (error) {
    console.error('Error adding food log:', error);
    return NextResponse.json(
      { success: false, error: { code: 'CREATE_ERROR', message: 'Failed to log food.' } },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { success: false, error: { code: 'VALIDATION_ERROR', message: 'Log ID is required.' } },
        { status: 400 }
      );
    }

    await prisma.foodLog.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'Logged food deleted.' });
  } catch (error) {
    console.error('Error deleting food log:', error);
    return NextResponse.json(
      { success: false, error: { code: 'DELETE_ERROR', message: 'Failed to delete food log.' } },
      { status: 500 }
    );
  }
}
