'use client';

import { MenuItemData } from '@/lib/engine/types';
import {
  Check,
  CheckCircle2,
  ChefHat,
  Flame,
  PackageCheck,
  Receipt,
  Sparkles,
  Timer,
  UtensilsCrossed,
  X,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';

interface FoodPrepAnimationModalProps {
  dish: MenuItemData | null;
  restaurantName?: string;
  onClose: () => void;
}

const PREPARATION_STAGES = [
  {
    id: 1,
    title: 'Order Confirmed',
    subtitle: 'Sent to restaurant kitchen display',
    icon: Receipt,
    color: 'emerald',
    durationMs: 2500,
    fact: 'Your order was verified against your allergy restrictions.',
  },
  {
    id: 2,
    title: 'Master Chef Assigned',
    subtitle: 'Chef reviewing macro portion specifications',
    icon: ChefHat,
    color: 'teal',
    durationMs: 3000,
    fact: 'Portions are measured according to standardized nutrition tables.',
  },
  {
    id: 3,
    title: 'Prepping & Chopping',
    subtitle: 'Fresh farm vegetables & protein diced',
    icon: UtensilsCrossed,
    color: 'sky',
    durationMs: 3500,
    fact: 'Using high-smoke point oils to preserve essential micronutrients.',
  },
  {
    id: 4,
    title: 'Cooking in Progress',
    subtitle: 'Clay tandoor roasting & aromatic tempering',
    icon: Flame,
    color: 'orange',
    durationMs: 4000,
    fact: 'Slow heat ensures protein denaturation without excessive charring.',
  },
  {
    id: 5,
    title: 'Plating & Garnishing',
    subtitle: 'Nutritional portion check & fresh herb garnish',
    icon: Sparkles,
    color: 'purple',
    durationMs: 3000,
    fact: 'Fresh herbs like coriander and mint provide potent antioxidant polyphenols.',
  },
  {
    id: 6,
    title: 'Ready to Enjoy!',
    subtitle: 'Your meal is prepared and hot',
    icon: PackageCheck,
    color: 'emerald',
    durationMs: 0,
    fact: 'Bon appétit! Enjoy your goal-aligned meal.',
  },
];

export function FoodPrepAnimationModal({
  dish,
  restaurantName = 'NutriDine Partner Kitchen',
  onClose,
}: FoodPrepAnimationModalProps) {
  const [currentStageIdx, setCurrentStageIdx] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);

  useEffect(() => {
    if (!dish) return;

    const timerInterval = setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);

    let stageTimeout: NodeJS.Timeout;

    const runStage = (idx: number) => {
      if (idx >= PREPARATION_STAGES.length - 1) {
        setIsCompleted(true);
        return;
      }

      const stage = PREPARATION_STAGES[idx];
      stageTimeout = setTimeout(() => {
        setCurrentStageIdx(idx + 1);
        runStage(idx + 1);
      }, stage.durationMs);
    };

    runStage(0);

    return () => {
      clearInterval(timerInterval);
      clearTimeout(stageTimeout);
    };
  }, [dish]);

  if (!dish) return null;

  const currentStage = PREPARATION_STAGES[currentStageIdx];
  const progressPercent = Math.round(((currentStageIdx + 1) / PREPARATION_STAGES.length) * 100);

  const handleSkipToEnd = () => {
    setCurrentStageIdx(PREPARATION_STAGES.length - 1);
    setIsCompleted(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-900 via-slate-900 to-teal-950 text-white flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30 mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Live Kitchen Preparation Tracker</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
              <span>{dish.name}</span>
            </h2>
            <p className="text-xs text-slate-300">
              {restaurantName} • ₹{Math.round(dish.price)} • {dish.calories} kcal • {dish.protein}g Protein
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Progress Bar */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-700 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Animated Hero Illustration Stage */}
          <div className="flex flex-col items-center justify-center text-center space-y-4 py-4 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-200/80 dark:border-slate-700/60 p-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border-4 border-emerald-500 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shadow-xl animate-bounce">
                {React.createElement(currentStage.icon, { className: 'w-12 h-12' })}
              </div>
              <div className="absolute -bottom-2 -right-2 px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[11px] font-black shadow">
                Stage {currentStageIdx + 1}/6
              </div>
            </div>

            <div className="space-y-1 max-w-md">
              <h3 className="text-2xl font-black text-slate-900 dark:text-white">{currentStage.title}</h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 font-medium">{currentStage.subtitle}</p>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-800">
              <Timer className="w-3.5 h-3.5 text-emerald-500" />
              <span>Elapsed: {secondsElapsed}s • Status: {isCompleted ? 'Finished' : 'In Progress'}</span>
            </div>
          </div>

          {/* Timeline Steps */}
          <div className="space-y-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Kitchen Timeline</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {PREPARATION_STAGES.map((s, idx) => {
                const isPast = idx < currentStageIdx;
                const isCurrent = idx === currentStageIdx;
                return (
                  <div
                    key={s.id}
                    className={`p-2.5 rounded-xl border text-xs flex items-center gap-2 transition-all ${
                      isCurrent
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold shadow-sm'
                        : isPast
                        ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-500 opacity-80'
                        : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800/40 text-slate-400 opacity-50'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 ${
                        isPast
                          ? 'bg-emerald-500 text-white'
                          : isCurrent
                          ? 'bg-emerald-600 text-white animate-pulse'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {isPast ? <Check className="w-3 h-3" /> : idx + 1}
                    </div>
                    <span className="truncate">{s.title}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Nutritional Culinary Insight Callout */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-0.5">
              <span className="font-extrabold text-amber-900 dark:text-amber-200">Culinary & Nutrition Fact</span>
              <p className="text-amber-800 dark:text-amber-300/90 leading-relaxed">{currentStage.fact}</p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-5 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          {!isCompleted ? (
            <button
              onClick={handleSkipToEnd}
              className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors cursor-pointer"
            >
              Skip Animation ⏩
            </button>
          ) : (
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              <span>Ready for dining!</span>
            </div>
          )}

          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
          >
            {isCompleted ? 'Done & Return to Menu' : 'Minimize / Close'}
          </button>
        </div>
      </div>
    </div>
  );
}
