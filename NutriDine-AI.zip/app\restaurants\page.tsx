'use client';

import { useUser } from '@/context/UserContext';
import {
  ArrowRight,
  ChevronRight,
  Filter,
  MapPin,
  Search,
  Sparkles,
  Star,
  Store,
  UtensilsCrossed,
} from 'lucide-react';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';

interface RestaurantItem {
  id: string;
  slug: string;
  name: string;
  description: string;
  address: string;
  city: string;
  cuisineTypes: string;
  priceRange: number;
  rating: number;
  reviewCount: number;
  bannerUrl?: string;
  logoUrl?: string;
  _count: {
    menuItems: number;
  };
}

export default function RestaurantsPage() {
  const { activePersona } = useUser();
  const [restaurants, setRestaurants] = useState<RestaurantItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('ALL');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadRestaurants() {
      setIsLoading(true);
      try {
        const res = await fetch('/api/restaurants');
        const data = await res.json();
        if (data.success) {
          setRestaurants(data.restaurants);
        }
      } catch (err) {
        console.error('Failed to load restaurants:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadRestaurants();
  }, []);

  const cuisineTabs = [
    'ALL',
    'North Indian',
    'South Indian',
    'Gujarati',
    'Punjabi',
    'Rajasthani',
    'Hyderabadi',
    'Kerala',
    'Italian',
    'Pan-Asian',
    'Healthy Bowls',
  ];

  const filteredRestaurants = restaurants.filter((r) => {
    const q = searchQuery.toLowerCase().trim();

    const matchesSearch =
      !q ||
      r.name.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) ||
      r.cuisineTypes.toLowerCase().includes(q) ||
      r.city.toLowerCase().includes(q) ||
      (q.includes('protein') && (r.description.toLowerCase().includes('protein') || r.cuisineTypes.toLowerCase().includes('grill') || r.cuisineTypes.toLowerCase().includes('bowl'))) ||
      (q.includes('veg') && (r.cuisineTypes.toLowerCase().includes('gujarati') || r.cuisineTypes.toLowerCase().includes('jain') || r.cuisineTypes.toLowerCase().includes('vegetarian'))) ||
      (q.includes('healthy') && (r.cuisineTypes.toLowerCase().includes('healthy') || r.cuisineTypes.toLowerCase().includes('bowl') || r.cuisineTypes.toLowerCase().includes('salad')));

    const matchesCuisine =
      selectedCuisine === 'ALL' || r.cuisineTypes.toLowerCase().includes(selectedCuisine.toLowerCase());

    return matchesSearch && matchesCuisine;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Personalized for {activePersona.name} ({activePersona.profile.goal.replace(/_/g, ' ')})</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight">
            Discover Restaurants & Menus
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Select any partner restaurant to view its full menu automatically ranked and scored for your individual health targets.
          </p>
        </div>

        <div className="relative z-10 shrink-0">
          <Link
            href="/onboarding"
            className="px-5 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-1.5"
          >
            <span>Update My Profile</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Search & Cuisine Filter Bar */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by cuisine, dish, city (e.g. 'high protein', 'Gujarati food', 'Mumbai', 'healthy bowls')..."
              className="w-full pl-11 pr-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm dark:text-white"
            />
          </div>
        </div>

        {/* Cuisine Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {cuisineTabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setSelectedCuisine(tab)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCuisine === tab
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
              }`}
            >
              {tab === 'ALL' ? '🍽️ All Cuisines' : tab}
            </button>
          ))}
        </div>
      </div>

      {/* Restaurant Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-72 rounded-3xl bg-slate-100 dark:bg-slate-800 animate-pulse" />
          ))}
        </div>
      ) : filteredRestaurants.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <Store className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">No Restaurants Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search keywords or clearing the cuisine filter.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCuisine('ALL');
            }}
            className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {filteredRestaurants.map((restaurant) => (
            <Link
              key={restaurant.id}
              href={`/restaurants/${restaurant.slug || restaurant.id}`}
              className="group bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/90 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 flex flex-col"
            >
              {/* Banner Image */}
              <div className="relative h-56 w-full bg-slate-800 overflow-hidden">
                <img
                  src={
                    restaurant.bannerUrl ||
                    'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&auto=format&fit=crop&q=80'
                  }
                  alt={restaurant.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                {/* Rating & Dish count badge */}
                <div className="absolute top-4 right-4 flex items-center gap-2">
                  <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-amber-300 text-xs font-black shadow">
                    <Star className="w-3.5 h-3.5 fill-amber-300" /> {restaurant.rating} ({restaurant.reviewCount})
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <h3 className="text-2xl font-black tracking-tight">{restaurant.name}</h3>
                  <div className="flex items-center gap-2 text-xs text-slate-300 mt-1">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" /> {restaurant.address}, {restaurant.city}
                    </span>
                    <span>•</span>
                    <span className="font-bold text-emerald-300">{'₹'.repeat(restaurant.priceRange)}</span>
                  </div>
                </div>
              </div>

              {/* Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
                  {restaurant.description}
                </p>

                {/* Cuisine Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {restaurant.cuisineTypes.split(',').map((c, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-semibold"
                    >
                      {c.trim()}
                    </span>
                  ))}
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 text-[11px] font-bold">
                    {restaurant._count.menuItems} Dishes Available
                  </span>
                </div>

                {/* Action CTA */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>View AI Personalized Ranking</span>
                  </span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
