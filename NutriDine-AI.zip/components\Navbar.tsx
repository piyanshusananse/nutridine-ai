'use client';

import { FoodPrepAnimationModal } from '@/components/FoodPrepAnimationModal';
import { ThemeToggle } from '@/components/ThemeToggle';
import { WhatShouldIEatModal } from '@/components/WhatShouldIEatModal';
import { PRESET_PERSONAS, useUser } from '@/context/UserContext';
import { MenuItemData } from '@/lib/engine/types';
import { signIn, signOut, useSession } from 'next-auth/react';
import {
  Activity,
  Award,
  Calendar,
  ChevronDown,
  Layers,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  Scale,
  Sparkles,
  Store,
  TrendingUp,
  User,
  UtensilsCrossed,
  X,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import React, { useState } from 'react';

export function Navbar() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const { activePersona, switchPersona, comparisonDishes, toastMessage } = useUser();

  const [personaMenuOpen, setPersonaMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isWhatToEatOpen, setIsWhatToEatOpen] = useState(false);
  const [activePrepDish, setActivePrepDish] = useState<MenuItemData | null>(null);

  const navLinks = [
    { href: '/restaurants', label: 'Restaurants', icon: UtensilsCrossed },
    { href: '/tracker', label: "Today's Tracker", icon: TrendingUp },
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/meal-builder', label: 'Meal Builder', icon: Layers },
    { href: '/restaurant-admin', label: 'For Restaurants', icon: Store },
    { href: '/admin', label: 'Admin', icon: Award },
  ];

  return (
    <>
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-emerald-500/30 flex items-center gap-3 animate-bounce">
          <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-sm font-medium">{toastMessage}</span>
        </div>
      )}

      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-6">
              <Link href="/" className="flex items-center gap-2.5 group">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                  🥗
                </div>
                <div className="flex flex-col">
                  <span className="font-extrabold text-lg tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
                    NutriDine <span className="text-xs px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-black">AI</span>
                  </span>
                  <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400 -mt-1">
                    Smart Restaurant Food Intelligence
                  </span>
                </div>
              </Link>

              {/* Desktop Nav Links */}
              <nav className="hidden lg:flex items-center gap-1">
                {navLinks.map((link) => {
                  const isActive = pathname === link.href || (link.href !== '/' && pathname.startsWith(`${link.href}/`));
                  const Icon = link.icon;
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
                      <span>{link.label}</span>
                    </Link>
                  );
                })}
              </nav>
            </div>

            {/* Right Actions, What-to-eat button & Theme toggle */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Quick "What Should I Eat?" Action */}
              <button
                onClick={() => setIsWhatToEatOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white text-xs font-black shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
                title="Smart dish suggestions based on your remaining daily nutrition targets"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>What to eat?</span>
              </button>

              {/* Theme Toggle (Light / Dark mode) */}
              <ThemeToggle />

              {/* Compare Button if items present */}
              {comparisonDishes.length > 0 && (
                <Link
                  href="/compare"
                  className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 text-xs font-bold hover:bg-sky-100 transition-colors"
                >
                  <Scale className="w-3.5 h-3.5" />
                  <span>Compare</span>
                  <span className="w-4 h-4 rounded-full bg-sky-600 text-white text-[10px] flex items-center justify-center font-bold">
                    {comparisonDishes.length}
                  </span>
                </Link>
              )}

              {/* Persona Switcher Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setPersonaMenuOpen(!personaMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-emerald-300 dark:border-emerald-700/60 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-all text-xs font-semibold text-slate-800 dark:text-slate-100 cursor-pointer shadow-sm"
                  title="Switch Persona to see how recommendations change dynamically"
                >
                  <span className="text-base">{activePersona.avatar}</span>
                  <div className="flex flex-col text-left hidden sm:flex">
                    <span className="font-bold leading-none text-slate-900 dark:text-white">{activePersona.name}</span>
                    <span className="text-[10px] text-emerald-700 dark:text-emerald-400 leading-tight">
                      {activePersona.profile.goal.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {personaMenuOpen && (
                  <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                        Demo Profiles (Live AI Re-ranking)
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Switch profiles to see menus instantly re-score for different goals!
                      </p>
                    </div>

                    <div className="py-1 space-y-1">
                      {PRESET_PERSONAS.map((p) => {
                        const isSelected = activePersona.id === p.id;
                        return (
                          <button
                            key={p.id}
                            onClick={() => {
                              switchPersona(p.id);
                              setPersonaMenuOpen(false);
                            }}
                            className={`w-full flex items-start gap-2.5 p-2.5 rounded-xl text-left transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800'
                                : 'hover:bg-slate-100 dark:hover:bg-slate-800/60'
                            }`}
                          >
                            <span className="text-2xl shrink-0 mt-0.5">{p.avatar}</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-sm text-slate-900 dark:text-white">{p.name}</span>
                                {isSelected && (
                                  <span className="text-[10px] font-extrabold px-1.5 py-0.5 bg-emerald-500 text-white rounded">
                                    ACTIVE
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">{p.tagline}</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between px-2">
                      <Link
                        href="/onboarding"
                        onClick={() => setPersonaMenuOpen(false)}
                        className="text-xs font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Create Custom Profile</span>
                      </Link>
                      <Link
                        href="/profile"
                        onClick={() => setPersonaMenuOpen(false)}
                        className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400"
                      >
                        Edit Stats
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Onboarding / Profile CTA */}
              <Link
                href="/profile"
                className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/60 transition-colors"
                title="My Wellness Profile & Nutrition Targets"
              >
                <User className="w-5 h-5" />
              </Link>

              {/* Mobile menu toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 pt-2 pb-4 space-y-1">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsWhatToEatOpen(true);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md mb-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>What Should I Eat Now?</span>
            </button>

            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Icon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </div>
        )}
      </header>

      {/* Global What Should I Eat Modal */}
      <WhatShouldIEatModal
        isOpen={isWhatToEatOpen}
        onClose={() => setIsWhatToEatOpen(false)}
        onSelectOrderDish={(dish) => setActivePrepDish(dish)}
      />

      {/* Global Food Prep Animation Modal */}
      {activePrepDish && (
        <FoodPrepAnimationModal
          dish={activePrepDish}
          restaurantName={(activePrepDish as any).restaurantName || 'Partner Restaurant Kitchen'}
          onClose={() => setActivePrepDish(null)}
        />
      )}
    </>
  );
}
