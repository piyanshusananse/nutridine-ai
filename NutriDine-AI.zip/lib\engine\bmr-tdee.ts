import { ActivityLevel, EnergyNeeds, Sex, UserGoal } from './types';

const ACTIVITY_MULTIPLIERS: Record<ActivityLevel, number> = {
  SEDENTARY: 1.2,
  LIGHT: 1.375,
  MODERATE: 1.55,
  VERY_ACTIVE: 1.725,
  EXTRA_ACTIVE: 1.9,
};

/**
 * Computes Basal Metabolic Rate (BMR) using the clinically validated Mifflin-St Jeor equation.
 */
export function calculateBMR(weightKg: number, heightCm: number, age: number, sex: Sex): number {
  if (weightKg <= 0 || heightCm <= 0 || age <= 0) return 1500;

  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;

  if (sex === 'MALE') {
    return Math.round(base + 5);
  } else if (sex === 'FEMALE') {
    return Math.round(base - 161);
  } else {
    return Math.round(base - 78);
  }
}

/**
 * Computes Total Daily Energy Expenditure (TDEE) and goal-tailored calorie and macronutrient ranges.
 */
export function calculateEnergyNeeds(
  weightKg: number,
  heightCm: number,
  age: number,
  sex: Sex,
  activityLevel: ActivityLevel,
  goal: UserGoal,
  targetCaloriesOverride?: number | null,
  targetProteinOverride?: number | null
): EnergyNeeds {
  const bmr = calculateBMR(weightKg, heightCm, age, sex);
  const multiplier = ACTIVITY_MULTIPLIERS[activityLevel] || 1.55;
  const tdee = Math.round(bmr * multiplier);

  let targetCalories = tdee;
  let suggestedMin = tdee - 150;
  let suggestedMax = tdee + 150;

  switch (goal) {
    case 'WEIGHT_LOSS':
      targetCalories = Math.max(sex === 'FEMALE' ? 1200 : 1500, tdee - 500);
      suggestedMin = Math.max(1200, targetCalories - 150);
      suggestedMax = targetCalories + 150;
      break;

    case 'WEIGHT_GAIN':
      targetCalories = tdee + 400;
      suggestedMin = targetCalories - 150;
      suggestedMax = targetCalories + 200;
      break;

    case 'MUSCLE_GAIN':
      targetCalories = tdee + 250;
      suggestedMin = targetCalories - 100;
      suggestedMax = targetCalories + 150;
      break;

    case 'IMPROVED_PROTEIN':
    case 'BETTER_ENERGY':
    case 'BETTER_NUTRITION':
    case 'MAINTENANCE':
    case 'NOT_SURE':
    default:
      targetCalories = tdee;
      suggestedMin = tdee - 150;
      suggestedMax = tdee + 150;
      break;
  }

  // Allow manual user override if provided
  if (targetCaloriesOverride && targetCaloriesOverride >= 800) {
    targetCalories = targetCaloriesOverride;
    suggestedMin = targetCalories - 150;
    suggestedMax = targetCalories + 150;
  }

  // Calculate Protein Target (g/day)
  let proteinPerKgMin = 1.2;
  let proteinPerKgMax = 1.6;

  if (goal === 'MUSCLE_GAIN' || goal === 'IMPROVED_PROTEIN') {
    proteinPerKgMin = 1.8;
    proteinPerKgMax = 2.2;
  } else if (goal === 'WEIGHT_LOSS') {
    proteinPerKgMin = 1.6;
    proteinPerKgMax = 2.0;
  }

  let proteinRangeMin = Math.round(weightKg * proteinPerKgMin);
  let proteinRangeMax = Math.round(weightKg * proteinPerKgMax);

  if (targetProteinOverride && targetProteinOverride > 0) {
    proteinRangeMin = Math.round(targetProteinOverride * 0.9);
    proteinRangeMax = Math.round(targetProteinOverride * 1.1);
  }

  // Fats: ~25% of total calories (9 kcal/g)
  const fatCalories = targetCalories * 0.25;
  const fatRangeMin = Math.round((fatCalories * 0.85) / 9);
  const fatRangeMax = Math.round((fatCalories * 1.15) / 9);

  // Carbs: Remaining calories / 4 kcal/g
  const avgProteinCalories = ((proteinRangeMin + proteinRangeMax) / 2) * 4;
  const remainingCarbCalories = Math.max(200, targetCalories - avgProteinCalories - fatCalories);
  const carbsRangeMin = Math.round((remainingCarbCalories * 0.85) / 4);
  const carbsRangeMax = Math.round((remainingCarbCalories * 1.15) / 4);

  // Fiber target: ~14g per 1000 kcal (usually 25-35g)
  const fiberTargetGrams = Math.round(Math.min(38, Math.max(25, (targetCalories / 1000) * 14)));

  // Water target: ~33ml per kg bodyweight
  const waterTargetLiters = Math.round((weightKg * 0.033) * 10) / 10;

  return {
    bmr,
    tdee,
    suggestedCalorieMin: suggestedMin,
    suggestedCalorieMax: suggestedMax,
    targetCalories,
    proteinRangeMin,
    proteinRangeMax,
    carbsRangeMin,
    carbsRangeMax,
    fatRangeMin,
    fatRangeMax,
    fiberTargetGrams,
    waterTargetLiters,
    disclaimer:
      'These energy and macronutrient targets are estimates for general wellness. They should not replace personalized dietary advice from a registered dietitian or physician.',
  };
}
