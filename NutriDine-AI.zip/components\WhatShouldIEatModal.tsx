'use client';

import { useUser } from '@/context/UserContext';
import { MenuItemData } from '@/lib/engine/types';
import {
  Award,
  CheckCircle2,
  ChefHat,
  Flame,
  Plus,
  Scale,
  Sparkles,
  Utensils,
  UtensilsCrossed,
  X,
  Zap,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';

interface WhatShouldIEatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOrderDish?: (dish: MenuItemData) => void;
}

export function WhatShouldIEatModal({
  isOpen,
  onClose,
  onSelectOrderDish,
}: WhatShouldIEatModalProps) {
  const { activePersona, userProfile, addToComparison, showToast } = useUser();

  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const [selectedMealType, setSelectedMealType] = useState<'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK'>('LUNCH');
  const [budgetInput, setBudgetInput] = useState<string>('500');

  const loadRecommendations = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/recommendations?userId=${activePersona.id}&mealType=${selectedMealType}&budget=${budgetInput || ''}`
      );
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (err) {
      console.error('Failed to load smart recommendations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadRecommendations();
    }
  }, [isOpen, activePersona.id, selectedMealType, budgetInput]);

  if (!isOpen) return null;

  const handleQuickLog = async (dish: MenuItemData, mealType: string) => {
    try {
      const res = await fetch('/api/food-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activePersona.id,
          menuItemId: dish.id,
          dishName: dish.name,
          restaurantName: (dish as any).restaurantName || 'Restaurant Dish',
          mealType,
          calories: dish.calories,
          protein: dish.protein,
          carbs: dish.carbohydrates,
          fat: dish.fat,
          fiber: dish.fiber,
          sodium: dish.sodium,
          sugar: dish.sugar,
          quantity: 1,
        }),
      });
      const json = await res.json();
      if (json.success) {
        showToast(`Logged "${dish.name}" to today's ${mealType.toLowerCase()}!`);
        onClose();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-900 via-slate-900 to-teal-950 text-white flex items-start justify-between">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Smart Nutrition Deficit Matcher</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">What should I eat now?</h2>
            <p className="text-xs text-slate-300">
              Personalized for {userProfile.name} • Goal: {userProfile.goal.replace(/_/g, ' ')}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Deficit Filter Controls Bar */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Meal Slot Selector */}
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-500">Meal:</span>
            {(['BREAKFAST', 'LUNCH', 'DINNER', 'SNACK'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setSelectedMealType(m)}
                className={`px-3 py-1.5 rounded-xl font-extrabold transition-all cursor-pointer ${
                  selectedMealType === m
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          {/* Budget Filter */}
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-500">Max Budget:</span>
            <div className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2.5 py-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <span className="font-black text-emerald-600">₹</span>
              <input
                type="number"
                value={budgetInput}
                onChange={(e) => setBudgetInput(e.target.value)}
                className="w-16 bg-transparent text-xs font-bold focus:outline-none dark:text-white"
                placeholder="500"
              />
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* Today's Remaining Target Snapshot */}
          {data?.remainingDeficit && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-emerald-50/60 dark:bg-emerald-950/30 p-4 rounded-2xl border border-emerald-200/80 dark:border-emerald-900/50">
              <div className="space-y-0.5">
                <span className="text-[10px] font-black uppercase text-emerald-800 dark:text-emerald-400">
                  Remaining Calories
                </span>
                <div className="text-xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                  <span>{data.remainingDeficit.remainingCalories}</span>
                  <span className="text-[10px] text-slate-500 font-normal">kcal</span>
                </div>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] font-black uppercase text-emerald-800 dark:text-emerald-400">
                  Remaining Protein
                </span>
                <div className="text-xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                  <span>{data.remainingDeficit.remainingProtein}g</span>
                  <span className="text-[10px] text-slate-500 font-normal">needed</span>
                </div>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] font-black uppercase text-emerald-800 dark:text-emerald-400">
                  Remaining Carbs
                </span>
                <div className="text-xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                  <span>{data.remainingDeficit.remainingCarbs}g</span>
                </div>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] font-black uppercase text-emerald-800 dark:text-emerald-400">
                  Remaining Fibre
                </span>
                <div className="text-xl font-black text-slate-900 dark:text-white flex items-baseline gap-1">
                  <span>{data.remainingDeficit.remainingFiber}g</span>
                </div>
              </div>
            </div>
          )}

          {/* Recommendations List */}
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 rounded-2xl bg-slate-100 dark:bg-slate-800 animate-pulse" />
              ))}
            </div>
          ) : !data?.recommendations || data.recommendations.length === 0 ? (
            <div className="text-center py-12 space-y-2">
              <UtensilsCrossed className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">
                No matching dishes found for your exact deficit and budget.
              </h3>
              <p className="text-xs text-slate-400">Try increasing your budget or changing the meal slot.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
                Top Matches Ranked for Your Remaining Target
              </h3>

              {data.recommendations.map((rec: any, idx: number) => {
                const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`;
                const dish = rec.dish;

                return (
                  <div
                    key={dish.id}
                    className={`p-4 sm:p-5 rounded-3xl border transition-all space-y-3 ${
                      idx === 0
                        ? 'bg-gradient-to-r from-emerald-50/90 to-teal-50/60 dark:from-emerald-950/40 dark:to-teal-950/30 border-emerald-300 dark:border-emerald-700 shadow-md'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      {/* Left: Rank, Image & Details */}
                      <div className="flex items-center gap-3.5">
                        <span className="text-2xl font-black shrink-0">{medal}</span>
                        <img
                          src={
                            dish.imageUrl ||
                            'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80'
                          }
                          alt={dish.name}
                          className="w-16 h-16 rounded-2xl object-cover shrink-0 shadow-sm"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-base font-black text-slate-900 dark:text-white">{dish.name}</h4>
                            {dish.isVegetarian && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                                Veg
                              </span>
                            )}
                            {dish.isGlutenFree && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300">
                                GF
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5">
                            {rec.restaurantName} • <span className="font-bold text-slate-900 dark:text-white">₹{Math.round(dish.price)}</span>
                          </p>
                          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 mt-1">
                            <span>🔥 {dish.calories} kcal</span>
                            <span>•</span>
                            <span>⚡ {dish.protein}g Protein</span>
                            <span>•</span>
                            <span>🌾 {dish.fiber}g Fiber</span>
                          </div>
                        </div>
                      </div>

                      {/* Right: Compatibility Score Badge */}
                      <div className="text-right shrink-0">
                        <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                          {rec.score}%
                        </div>
                        <span className="text-[10px] font-bold uppercase text-slate-400">Deficit Fit</span>
                      </div>
                    </div>

                    {/* Explanatory "Why it fits your day" text */}
                    <div className="p-3 rounded-2xl bg-white/80 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700/60 text-xs text-slate-700 dark:text-slate-300 space-y-1">
                      <div className="font-extrabold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Why NutriDine Recommends This:</span>
                      </div>
                      <p className="leading-relaxed">{rec.detailedWhy}</p>
                    </div>

                    {/* Action buttons */}
                    <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                      <button
                        onClick={() => addToComparison(dish)}
                        className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Scale className="w-3.5 h-3.5 text-sky-500" />
                        <span>Compare</span>
                      </button>

                      <button
                        onClick={() => handleQuickLog(dish, selectedMealType)}
                        className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add to {selectedMealType.toLowerCase()}</span>
                      </button>

                      {onSelectOrderDish && (
                        <button
                          onClick={() => {
                            onSelectOrderDish(dish);
                            onClose();
                          }}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <ChefHat className="w-3.5 h-3.5" />
                          <span>Order & Watch Prep</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
