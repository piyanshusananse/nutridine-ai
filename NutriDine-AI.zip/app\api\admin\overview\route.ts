import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const userCount = await prisma.user.count();
    const restaurantCount = await prisma.restaurant.count();
    const dishCount = await prisma.menuItem.count();
    const aiEstimatedDishCount = await prisma.menuItem.count({
      where: { nutritionSource: 'AI_ESTIMATED' },
    });

    const restaurants = await prisma.restaurant.findMany({
      include: {
        _count: {
          select: { menuItems: true },
        },
      },
    });

    const flaggedDishes = await prisma.menuItem.findMany({
      where: {
        OR: [{ calories: { gt: 1200 } }, { sodium: { gt: 1500 } }, { sugar: { gt: 40 } }],
      },
      include: {
        restaurant: true,
      },
      take: 10,
    });

    return NextResponse.json({
      success: true,
      stats: {
        totalUsers: userCount,
        totalRestaurants: restaurantCount,
        totalDishes: dishCount,
        aiEstimatedDishes: aiEstimatedDishCount,
        exactVerifiedDishes: dishCount - aiEstimatedDishCount,
      },
      restaurants,
      flaggedDishes,
    });
  } catch (error) {
    console.error('Admin overview error:', error);
    return NextResponse.json({ success: false, error: 'Admin error' }, { status: 500 });
  }
}
