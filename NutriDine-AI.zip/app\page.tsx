'use client';

import { PRESET_PERSONAS, useUser } from '@/context/UserContext';
import {
  Activity,
  ArrowRight,
  Award,
  CheckCircle2,
  ChevronRight,
  Compass,
  Flame,
  Layers,
  MapPin,
  Scale,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  UtensilsCrossed,
  Zap,
} from 'lucide-react';
import Link from 'next/link';
import React, { useState } from 'react';

export default function HomePage() {
  const { activePersona, switchPersona } = useUser();
  const [searchQuery, setSearchQuery] = useState('');

  // Sample dishes to illustrate the core principle on the homepage
  const showcaseDishes = [
    {
      id: 'dish-1',
      name: 'Tandoori Chicken Tikka',
      restaurant: 'Mumbai Spice House',
      calories: 380,
      protein: 48,
      carbs: 6,
      fat: 16,
      image: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=600&auto=format&fit=crop&q=80',
      scores: {
        'user-alex': { score: 95, label: 'Best Choice', reason: 'High protein, fits 500 kcal deficit perfectly' },
        'user-priya': { score: 0, label: 'Excluded', reason: 'Non-vegetarian (Dietary conflict)' },
        'user-marcus': { score: 45, label: 'Moderate', reason: 'Gluten-free, but Marcus prefers pescatarian/seafood' },
      },
    },
    {
      id: 'dish-2',
      name: 'Tandoori Paneer Tikka',
      restaurant: 'Mumbai Spice House',
      calories: 420,
      protein: 26,
      carbs: 12,
      fat: 28,
      image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=600&auto=format&fit=crop&q=80',
      scores: {
        'user-alex': { score: 76, label: 'Good Choice', reason: 'Good protein, slightly higher fat' },
        'user-priya': { score: 92, label: 'Best Choice', reason: 'Top vegetarian protein for muscle gain (Peanut-free)' },
        'user-marcus': { score: 72, label: 'Good Choice', reason: 'Gluten-free vegetarian protein' },
      },
    },
    {
      id: 'dish-3',
      name: 'Wild Alaskan Salmon Bowl',
      restaurant: 'Urban Bowl & Kitchen',
      calories: 580,
      protein: 42,
      carbs: 42,
      fat: 26,
      image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=600&auto=format&fit=crop&q=80',
      scores: {
        'user-alex': { score: 84, label: 'Good Choice', reason: 'High protein and clean fats for cutting' },
        'user-priya': { score: 0, label: 'Excluded', reason: 'Contains fish (Not vegetarian)' },
        'user-marcus': { score: 98, label: 'Best Choice', reason: '100% Gluten-free + optimal omega-3 protein' },
      },
    },
  ];

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* 1. HERO SECTION */}
      <section className="relative pt-8 sm:pt-16 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Hero Copy */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-bold tracking-wide shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>🥗 NutriDine AI — Personalized Restaurant Food Intelligence</span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-slate-900 dark:text-white leading-[1.1]">
              <span className="block text-emerald-600 dark:text-emerald-400 text-2xl sm:text-3xl font-black uppercase tracking-wider mb-2">
                NutriDine AI
              </span>
              Know what to order.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-500">
                Eat for your goals.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
              AI-powered restaurant menu recommendations personalized to your body, lifestyle, allergies, and wellness goals.
              Never guess macros or compromise your nutrition when dining out.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
              <Link
                href="/onboarding"
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base shadow-xl shadow-emerald-600/30 hover:scale-105 transition-all"
              >
                <Sparkles className="w-5 h-5" />
                <span>Get My Recommendations</span>
              </Link>

              <Link
                href="/restaurants"
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-4 rounded-2xl bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-white font-bold text-base border border-slate-200 dark:border-slate-800 shadow-sm transition-all"
              >
                <UtensilsCrossed className="w-5 h-5 text-slate-500" />
                <span>Explore Restaurants</span>
              </Link>
            </div>

            {/* Quick trust metrics */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-200 dark:border-slate-800 text-left">
              <div>
                <div className="text-2xl font-black text-slate-900 dark:text-white">100%</div>
                <div className="text-xs text-slate-500 font-medium">Real Menu Dishes</div>
              </div>
              <div>
                <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">0–100</div>
                <div className="text-xs text-slate-500 font-medium">Explainable Score</div>
              </div>
              <div>
                <div className="text-2xl font-black text-slate-900 dark:text-white">Safety-First</div>
                <div className="text-xs text-slate-500 font-medium">Allergen Screening</div>
              </div>
            </div>
          </div>

          {/* Right Hero Live Interactive Demo Card */}
          <div className="lg:col-span-5 bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-950 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                  Live Personalization Engine
                </span>
              </div>
              <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                Interactive
              </span>
            </div>

            {/* Persona Switcher Selector */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                1. Select a profile to test:
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {PRESET_PERSONAS.map((p) => {
                  const isSelected = activePersona.id === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => switchPersona(p.id)}
                      className={`p-2 rounded-xl text-center transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-md scale-102'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-400'
                      }`}
                    >
                      <div className="text-lg">{p.avatar}</div>
                      <div className="text-xs font-extrabold truncate">{p.name.split(' ')[0]}</div>
                      <div className="text-[9px] opacity-80 truncate">{p.profile.goal.replace(/_/g, ' ')}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Live Dynamic Menu Rankings for Active Persona */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>2. AI Matches for {activePersona.name}:</span>
                <span className="text-[11px] text-slate-400 font-normal">Real menu ranking</span>
              </div>

              <div className="space-y-2">
                {showcaseDishes.map((dish) => {
                  const matchData = dish.scores[activePersona.id as keyof typeof dish.scores];
                  const isTop = matchData.score >= 85;
                  const isExcluded = matchData.score === 0;

                  return (
                    <div
                      key={dish.id}
                      className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        isExcluded
                          ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40 opacity-70'
                          : isTop
                          ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 shadow-sm'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <img src={dish.image} alt={dish.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="font-extrabold text-xs text-slate-900 dark:text-white truncate">
                          {dish.name}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {dish.calories} kcal • {dish.protein}g protein
                        </div>
                        <div className="text-[10px] text-slate-600 dark:text-slate-400 truncate mt-0.5">
                          {matchData.reason}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div
                          className={`text-sm font-black ${
                            isExcluded
                              ? 'text-rose-600 dark:text-rose-400'
                              : isTop
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {matchData.score > 0 ? `${matchData.score}%` : '⛔ Excluded'}
                        </div>
                        <div className="text-[9px] font-bold uppercase text-slate-400">{matchData.label}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-400 text-center font-medium">
              💡 <strong>Core Principle:</strong> Same Restaurant + Different Person = Different Recommendations!
            </div>
          </div>
        </div>
      </section>

      {/* 2. HOW IT WORKS SECTION */}
      <section className="py-12 bg-white dark:bg-slate-900/60 border-y border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
              Simple 3-Step Journey
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              How NutriDine AI Guides Every Meal
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400">
              We never recommend generic foods. We evaluate the actual menu of the restaurant you're visiting.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-black text-xl">
                1
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">Set Your Wellness Profile</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Provide your body stats, activity level, dietary lifestyle (veg, vegan, keto, halal), and any allergy restrictions.
                Our engine automatically calculates your BMR, TDEE, and protein ranges.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center font-black text-xl">
                2
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">Browse Real Menus</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Select your favorite local restaurant. NutriDine AI instantly scans every entrée, side, and drink, checking for hard allergen conflicts and goal alignment.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-600 dark:text-sky-400 flex items-center justify-center font-black text-xl">
                3
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">Order with Total Confidence</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                See transparent 0–100 suitability scores, personalized &quot;Why&quot; explanations, actionable &quot;Make It Better&quot; ordering tweaks, or ask the AI assistant directly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURE SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
            Intelligent Features
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
            Built for Smart Eaters & Food Lovers
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center font-bold">
              🎯
            </div>
            <h4 className="font-extrabold text-base text-slate-900 dark:text-white">0–100 Explainable Score</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Every dish receives a transparent weighted score showing goal alignment, protein fit, calorie budget, and cooking method.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-600 flex items-center justify-center font-bold">
              🔄
            </div>
            <h4 className="font-extrabold text-base text-slate-900 dark:text-white">Menu-Aware Smart Swaps</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Craving creamy pasta? NutriDine suggests grilled chicken pasta or side substitutions available at the exact same restaurant.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 flex items-center justify-center font-bold">
              🍱
            </div>
            <h4 className="font-extrabold text-base text-slate-900 dark:text-white">Smart Meal Builder</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Auto-generate balanced multi-course meals (Starter + Entrée + Drink) that perfectly fit your per-meal calorie and macro targets.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-600 flex items-center justify-center font-bold">
              🛡️
            </div>
            <h4 className="font-extrabold text-base text-slate-900 dark:text-white">Strict Allergen Safety</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Hard constraint engine excludes dishes with declared allergens (peanuts, tree nuts, dairy, gluten, soy, shellfish) instantly.
            </p>
          </div>
        </div>
      </section>

      {/* 4. FEATURED RESTAURANTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
              Demo Menus
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Explore Seed Restaurants
            </h2>
          </div>
          <Link
            href="/restaurants"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline"
          >
            <span>View all restaurants</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Mumbai Spice House */}
          <Link
            href="/restaurants/mumbai-spice-house"
            className="group bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 flex flex-col"
          >
            <div className="relative h-52 w-full bg-slate-800 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&auto=format&fit=crop&q=80"
                alt="Mumbai Spice House"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 rounded-full bg-emerald-600 text-white font-black text-xs shadow">
                  🔥 Clay Tandoor & Curries
                </span>
              </div>
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <h3 className="text-2xl font-black">Mumbai Spice House</h3>
                <div className="flex items-center gap-3 text-xs text-slate-300 mt-1">
                  <span className="flex items-center gap-1 text-amber-300 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-300" /> 4.8 (284 reviews)
                  </span>
                  <span>•</span>
                  <span>₹₹ • Indian, Tandoori</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" /> Mumbai
                  </span>
                </div>
              </div>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
                Authentic Indian clay-oven tandoor, rich traditional curries, aromatic biryanis, and wholesome vegetarian & protein-packed grilled specialties.
              </p>
              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <span>Browse Menu & Personalized Scores</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>

          {/* Urban Bowl & Kitchen */}
          <Link
            href="/restaurants/urban-bowl-kitchen"
            className="group bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 flex flex-col"
          >
            <div className="relative h-52 w-full bg-slate-800 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=1200&auto=format&fit=crop&q=80"
                alt="Urban Bowl & Kitchen"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 rounded-full bg-teal-600 text-white font-black text-xs shadow">
                  🥑 Healthy Bowls & Smoothies
                </span>
              </div>
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <h3 className="text-2xl font-black">Urban Bowl & Kitchen</h3>
                <div className="flex items-center gap-3 text-xs text-slate-300 mt-1">
                  <span className="flex items-center gap-1 text-amber-300 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-300" /> 4.9 (412 reviews)
                  </span>
                  <span>•</span>
                  <span>₹₹ • Mediterranean, Salads</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" /> Mumbai
                  </span>
                </div>
              </div>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
                Nutrient-dense grain bowls, vibrant antioxidant salads, wild-caught seafood, free-range chicken, and clean protein smoothies.
              </p>
              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-bold text-teal-600 dark:text-teal-400">
                <span>Browse Menu & Personalized Scores</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* 5. TRANSPARENCY & DISCLAIMER CALLOUT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-8 sm:p-10 rounded-3xl border border-slate-700 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Scientific, Responsible & Non-Judgmental</span>
            </div>
            <h3 className="text-2xl font-black">Food Is To Be Enjoyed.</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              We never use shaming terms like &quot;bad food&quot; or &quot;cheat meals&quot;. Our recommendation engine simply matches dishes with your declared physiological and wellness targets, helping you dine out with clarity.
            </p>
          </div>
          <Link
            href="/onboarding"
            className="px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm shrink-0 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
          >
            Create My Free Profile
          </Link>
        </div>
      </section>
    </div>
  );
}
