import { estimateNutritionFromIngredients } from '@/lib/ai/estimate-nutrition';
import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { restaurantId, rawData, format = 'json' } = body;

    if (!restaurantId || !rawData) {
      return NextResponse.json(
        { success: false, error: 'restaurantId and rawData are required' },
        { status: 400 }
      );
    }

    let itemsToImport: any[] = [];

    if (format === 'json') {
      try {
        itemsToImport = typeof rawData === 'string' ? JSON.parse(rawData) : rawData;
      } catch (err) {
        return NextResponse.json({ success: false, error: 'Invalid JSON format' }, { status: 400 });
      }
    } else if (format === 'csv') {
      // Parse CSV line by line: Name, Category, Price, Ingredients, Calories, Protein
      const lines = (rawData as string).split('\n').map((l) => l.trim()).filter(Boolean);
      if (lines.length <= 1) {
        return NextResponse.json({ success: false, error: 'CSV is empty or missing rows' }, { status: 400 });
      }

      const headers = lines[0].toLowerCase().split(',').map((h) => h.trim());
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',').map((p) => p.trim());
        if (parts.length < 2) continue;

        const row: any = {};
        headers.forEach((h, idx) => {
          row[h] = parts[idx];
        });

        itemsToImport.push({
          name: row.name || row.dish || parts[0],
          category: row.category || row.categoryname || 'Mains',
          price: parseFloat(row.price || '240') || 240,
          ingredients: row.ingredients || '',
          calories: row.calories ? parseInt(row.calories, 10) : undefined,
          protein: row.protein ? parseFloat(row.protein) : undefined,
        });
      }
    }

    let importedCount = 0;

    for (const item of itemsToImport) {
      if (!item.name) continue;

      const categoryName = item.category || 'Mains';
      let cat = await prisma.menuCategory.findFirst({
        where: { restaurantId, name: categoryName },
      });
      if (!cat) {
        cat = await prisma.menuCategory.create({
          data: { restaurantId, name: categoryName, sortOrder: 99 },
        });
      }

      // If calories or macros are missing, automatically estimate via AI nutrition estimation
      let calories = item.calories;
      let protein = item.protein;
      let carbohydrates = item.carbohydrates;
      let fat = item.fat;
      let fiber = item.fiber || 0;
      let sodium = item.sodium || 0;
      let allergens = item.allergens || '';
      let isVegetarian = item.isVegetarian || false;
      let isVegan = item.isVegan || false;
      let isGlutenFree = item.isGlutenFree || false;
      let isDairyFree = item.isDairyFree || false;
      let nutritionSource = 'RESTAURANT_PROVIDED';

      if (!calories && item.ingredients) {
        const estimate = estimateNutritionFromIngredients(item.name, item.ingredients, 350);
        calories = estimate.calories;
        protein = estimate.protein;
        carbohydrates = estimate.carbohydrates;
        fat = estimate.fat;
        fiber = estimate.fiber;
        sodium = estimate.sodium;
        allergens = estimate.allergensDetected.join(', ');
        isVegetarian = estimate.isVegetarian;
        isVegan = estimate.isVegan;
        isGlutenFree = estimate.isGlutenFree;
        isDairyFree = estimate.isDairyFree;
        nutritionSource = 'AI_ESTIMATED';
      }

      await prisma.menuItem.create({
        data: {
          restaurantId,
          categoryId: cat.id,
          name: item.name,
          description: item.description || `Freshly prepared ${item.name}`,
          price: Number(item.price) || 240,
          servingSize: item.servingSize || '1 serving',
          calories: Number(calories) || 450,
          protein: Number(protein) || 20,
          carbohydrates: Number(carbohydrates) || 40,
          fat: Number(fat) || 15,
          fiber: Number(fiber) || 4,
          sodium: Number(sodium) || 500,
          ingredients: item.ingredients || '',
          allergens: allergens || '',
          isVegetarian,
          isVegan,
          isGlutenFree,
          isDairyFree,
          nutritionSource,
          imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
        },
      });

      importedCount++;
    }

    return NextResponse.json({
      success: true,
      importedCount,
      message: `Successfully imported ${importedCount} menu items.`,
    });
  } catch (error) {
    console.error('Error importing menu:', error);
    return NextResponse.json({ success: false, error: 'Failed to import menu' }, { status: 500 });
  }
}
