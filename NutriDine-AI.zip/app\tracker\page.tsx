'use client';

import { DishModal } from '@/components/DishModal';
import { FoodPrepAnimationModal } from '@/components/FoodPrepAnimationModal';
import { WhatShouldIEatModal } from '@/components/WhatShouldIEatModal';
import { useUser } from '@/context/UserContext';
import { MenuItemData } from '@/lib/engine/types';
import {
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Flame,
  Layers,
  Plus,
  Scale,
  Sparkles,
  Trash2,
  TrendingUp,
  Utensils,
  UtensilsCrossed,
  Zap,
} from 'lucide-react';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';

const MEAL_SLOTS = [
  { id: 'BREAKFAST', label: 'Breakfast', icon: '🌅', color: 'amber' },
  { id: 'LUNCH', label: 'Lunch', icon: '☀️', color: 'emerald' },
  { id: 'DINNER', label: 'Dinner', icon: '🌙', color: 'indigo' },
  { id: 'SNACK', label: 'Snacks & Drinks', icon: '🍎', color: 'purple' },
];

export default function TrackerPage() {
  const { activePersona, userProfile, energyNeeds, showToast } = useUser();

  const [currentDate, setCurrentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [logs, setLogs] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0,
    sodium: 0,
    sugar: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  // Modals state
  const [isWhatToEatOpen, setIsWhatToEatOpen] = useState(false);
  const [isCustomLogModalOpen, setIsCustomLogModalOpen] = useState(false);
  const [selectedMealSlotForLog, setSelectedMealSlotForLog] = useState('LUNCH');
  const [activePrepDish, setActivePrepDish] = useState<MenuItemData | null>(null);

  // Custom Log Form State
  const [customDishName, setCustomDishName] = useState('');
  const [customCalories, setCustomCalories] = useState('350');
  const [customProtein, setCustomProtein] = useState('25');
  const [customCarbs, setCustomCarbs] = useState('35');
  const [customFat, setCustomFat] = useState('12');
  const [customFiber, setCustomFiber] = useState('4');

  const loadLogs = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/food-log?userId=${activePersona.id}&date=${currentDate}`);
      const data = await res.json();
      if (data.success) {
        setLogs(data.logs);
        setSummary(data.summary);
      }
    } catch (err) {
      console.error('Failed to load food logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [activePersona.id, currentDate]);

  const handleDeleteLog = async (id: string) => {
    try {
      const res = await fetch(`/api/food-log?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setLogs((prev) => prev.filter((l) => l.id !== id));
        loadLogs();
        showToast('Item removed from today\'s tracker');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveCustomLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customDishName.trim()) {
      showToast('Please enter a dish name.');
      return;
    }

    try {
      const res = await fetch('/api/food-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activePersona.id,
          dishName: customDishName,
          restaurantName: 'Custom Entry',
          mealType: selectedMealSlotForLog,
          calories: parseInt(customCalories, 10),
          protein: parseFloat(customProtein),
          carbs: parseFloat(customCarbs),
          fat: parseFloat(customFat),
          fiber: parseFloat(customFiber),
          date: currentDate,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Logged "${customDishName}" to ${selectedMealSlotForLog.toLowerCase()}`);
        setCustomDishName('');
        setIsCustomLogModalOpen(false);
        loadLogs();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Target values
  const targetCalories = energyNeeds.targetCalories;
  const targetProtein = Math.round((energyNeeds.proteinRangeMin + energyNeeds.proteinRangeMax) / 2);
  const targetCarbs = Math.round((energyNeeds.carbsRangeMin + energyNeeds.carbsRangeMax) / 2);
  const targetFat = Math.round((energyNeeds.fatRangeMin + energyNeeds.fatRangeMax) / 2);
  const targetFiber = energyNeeds.fiberTargetGrams;

  // Remaining values
  const remainingCalories = Math.max(0, targetCalories - summary.calories);
  const remainingProtein = Math.max(0, targetProtein - summary.protein);
  const remainingCarbs = Math.max(0, targetCarbs - summary.carbs);
  const remainingFat = Math.max(0, targetFat - summary.fat);
  const remainingFiber = Math.max(0, targetFiber - summary.fiber);

  const calPercent = Math.min(100, Math.round((summary.calories / targetCalories) * 100));
  const protPercent = Math.min(100, Math.round((summary.protein / targetProtein) * 100));
  const carbPercent = Math.min(100, Math.round((summary.carbs / targetCarbs) * 100));
  const fatPercent = Math.min(100, Math.round((summary.fat / targetFat) * 100));
  const fibPercent = Math.min(100, Math.round((summary.fiber / targetFiber) * 100));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner & Date Picker */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Active Goal: {userProfile.goal.replace(/_/g, ' ')}</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black">Today&apos;s Nutrition Tracker</h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Track exact calories, protein, and macros from restaurant meals against your daily targets.
          </p>
        </div>

        {/* Date and Actions */}
        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-2 rounded-2xl border border-white/20 text-xs font-bold">
            <Calendar className="w-4 h-4 text-emerald-400" />
            <input
              type="date"
              value={currentDate}
              onChange={(e) => setCurrentDate(e.target.value)}
              className="bg-transparent text-white focus:outline-none cursor-pointer"
            />
          </div>

          <button
            onClick={() => setIsWhatToEatOpen(true)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>What should I eat now?</span>
          </button>
        </div>
      </div>

      {/* 1. DAILY MACRO TARGET PROGRESS METERS */}
      <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              <span>Today&apos;s Macro & Calorie Balance</span>
            </h2>
            <p className="text-xs text-slate-500">Real-time consumed vs remaining breakdown for {userProfile.name}</p>
          </div>

          <div className="text-right">
            <span className="text-xs font-bold text-slate-400 uppercase">Target Calories</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white">{targetCalories} kcal</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {/* Calories Bar */}
          <div className="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-orange-500" />
                <span>Calories</span>
              </span>
              <span className="text-slate-500">{calPercent}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
              <div
                className="h-full bg-orange-500 transition-all duration-500"
                style={{ width: `${calPercent}%` }}
              />
            </div>
            <div className="flex items-baseline justify-between text-xs pt-1">
              <span className="font-extrabold text-slate-900 dark:text-white">{summary.calories} kcal</span>
              <span className="text-[11px] text-slate-400">{remainingCalories} kcal left</span>
            </div>
          </div>

          {/* Protein Bar */}
          <div className="space-y-2 p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Protein</span>
              </span>
              <span className="text-emerald-600 dark:text-emerald-400">{protPercent}%</span>
            </div>
            <div className="w-full bg-emerald-200 dark:bg-emerald-900 h-3 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 transition-all duration-500"
                style={{ width: `${protPercent}%` }}
              />
            </div>
            <div className="flex items-baseline justify-between text-xs pt-1">
              <span className="font-extrabold text-emerald-950 dark:text-emerald-100">{summary.protein}g / {targetProtein}g</span>
              <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-bold">{remainingProtein}g left</span>
            </div>
          </div>

          {/* Carbohydrates Bar */}
          <div className="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-200">Carbohydrates</span>
              <span className="text-slate-500">{carbPercent}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
              <div
                className="h-full bg-sky-500 transition-all duration-500"
                style={{ width: `${carbPercent}%` }}
              />
            </div>
            <div className="flex items-baseline justify-between text-xs pt-1">
              <span className="font-extrabold text-slate-900 dark:text-white">{summary.carbs}g / {targetCarbs}g</span>
              <span className="text-[11px] text-slate-400">{remainingCarbs}g left</span>
            </div>
          </div>

          {/* Fat Bar */}
          <div className="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-200">Fats</span>
              <span className="text-slate-500">{fatPercent}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-500"
                style={{ width: `${fatPercent}%` }}
              />
            </div>
            <div className="flex items-baseline justify-between text-xs pt-1">
              <span className="font-extrabold text-slate-900 dark:text-white">{summary.fat}g / {targetFat}g</span>
              <span className="text-[11px] text-slate-400">{remainingFat}g left</span>
            </div>
          </div>

          {/* Fibre Bar */}
          <div className="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-200">Dietary Fibre</span>
              <span className="text-slate-500">{fibPercent}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
              <div
                className="h-full bg-teal-500 transition-all duration-500"
                style={{ width: `${fibPercent}%` }}
              />
            </div>
            <div className="flex items-baseline justify-between text-xs pt-1">
              <span className="font-extrabold text-slate-900 dark:text-white">{summary.fiber}g / {targetFiber}g</span>
              <span className="text-[11px] text-slate-400">{remainingFiber}g left</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. MEAL SLOTS SECTION (BREAKFAST, LUNCH, DINNER, SNACKS) */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Utensils className="w-5 h-5 text-emerald-600" />
            <span>Today&apos;s Meal Logs</span>
          </h2>

          <div className="flex items-center gap-2">
            <Link
              href="/restaurants"
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
            >
              <span>Browse Restaurant Menus</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MEAL_SLOTS.map((slot) => {
            const slotLogs = logs.filter((l) => l.mealType === slot.id);
            const slotCalories = slotLogs.reduce((sum, item) => sum + item.calories * item.quantity, 0);
            const slotProtein = slotLogs.reduce((sum, item) => sum + item.protein * item.quantity, 0);

            return (
              <div
                key={slot.id}
                className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 flex flex-col justify-between"
              >
                <div>
                  {/* Slot Header */}
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{slot.icon}</span>
                      <div>
                        <h3 className="font-extrabold text-base text-slate-900 dark:text-white">{slot.label}</h3>
                        <span className="text-[11px] text-slate-400 font-medium">
                          {slotCalories} kcal • {slotProtein.toFixed(1)}g Protein
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedMealSlotForLog(slot.id);
                        setIsCustomLogModalOpen(true);
                      }}
                      className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950 text-slate-700 dark:text-slate-300 hover:text-emerald-600 transition-colors text-xs font-bold flex items-center gap-1 cursor-pointer"
                      title={`Add item to ${slot.label}`}
                    >
                      <Plus className="w-4 h-4" />
                      <span className="hidden sm:inline">Add Item</span>
                    </button>
                  </div>

                  {/* Slot Items List */}
                  <div className="pt-3 space-y-2">
                    {slotLogs.length === 0 ? (
                      <div className="text-center py-6 text-xs text-slate-400 space-y-1">
                        <p>No meals logged for {slot.label.toLowerCase()} yet.</p>
                        <button
                          onClick={() => {
                            setSelectedMealSlotForLog(slot.id);
                            setIsWhatToEatOpen(true);
                          }}
                          className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                        >
                          Find a recommendation ➔
                        </button>
                      </div>
                    ) : (
                      slotLogs.map((item) => (
                        <div
                          key={item.id}
                          className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between gap-3 text-xs"
                        >
                          <div className="flex-1 min-w-0">
                            <div className="font-extrabold text-slate-900 dark:text-white truncate">
                              {item.dishName}
                            </div>
                            <div className="text-[11px] text-slate-500 truncate mt-0.5">
                              {item.restaurantName} • {item.calories} kcal • {item.protein}g Protein • {item.carbs}g Carbs
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => handleDeleteLog(item.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                              title="Delete log"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Quick Add CTA */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                  <span>{slotLogs.length} items logged</span>
                  <button
                    onClick={() => {
                      setSelectedMealSlotForLog(slot.id);
                      setIsWhatToEatOpen(true);
                    }}
                    className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Smart suggestion</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* CUSTOM LOG MODAL */}
      {isCustomLogModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                Log Food to {selectedMealSlotForLog}
              </h3>
              <button
                onClick={() => setIsCustomLogModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCustomLog} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Dish or Food Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Grilled Paneer Sandwich"
                  value={customDishName}
                  onChange={(e) => setCustomDishName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Calories (kcal)
                  </label>
                  <input
                    type="number"
                    required
                    value={customCalories}
                    onChange={(e) => setCustomCalories(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Protein (g)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={customProtein}
                    onChange={(e) => setCustomProtein(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Carbs (g)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={customCarbs}
                    onChange={(e) => setCustomCarbs(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Fat (g)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={customFat}
                    onChange={(e) => setCustomFat(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Fibre (g)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={customFiber}
                    onChange={(e) => setCustomFiber(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCustomLogModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow"
                >
                  Log Food
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SMART "WHAT SHOULD I EAT NOW?" MODAL */}
      <WhatShouldIEatModal
        isOpen={isWhatToEatOpen}
        onClose={() => {
          setIsWhatToEatOpen(false);
          loadLogs();
        }}
        onSelectOrderDish={(dish) => setActivePrepDish(dish)}
      />

      {/* FOOD PREPARATION ANIMATION MODAL */}
      {activePrepDish && (
        <FoodPrepAnimationModal
          dish={activePrepDish}
          restaurantName={(activePrepDish as any).restaurantName || 'Restaurant Kitchen'}
          onClose={() => setActivePrepDish(null)}
        />
      )}
    </div>
  );
}
