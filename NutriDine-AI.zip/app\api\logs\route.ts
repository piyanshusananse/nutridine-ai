import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId') || 'user-alex';

    const logs = await prisma.trackingLog.findMany({
      where: { userId },
      orderBy: { date: 'asc' },
      take: 30,
    });

    return NextResponse.json({ success: true, logs });
  } catch (error) {
    console.error('Error fetching logs:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch logs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      userId = 'user-alex',
      date = new Date().toISOString().split('T')[0],
      weightKg,
      caloriesConsumed,
      proteinGrams,
      waterMl,
      steps,
      mealDetails,
    } = body;

    const log = await prisma.trackingLog.upsert({
      where: {
        userId_date: { userId, date },
      },
      update: {
        weightKg: weightKg !== undefined ? Number(weightKg) : undefined,
        caloriesConsumed: caloriesConsumed !== undefined ? Number(caloriesConsumed) : undefined,
        proteinGrams: proteinGrams !== undefined ? Number(proteinGrams) : undefined,
        waterMl: waterMl !== undefined ? Number(waterMl) : undefined,
        steps: steps !== undefined ? Number(steps) : undefined,
        mealDetailsJson: mealDetails ? JSON.stringify(mealDetails) : undefined,
      },
      create: {
        userId,
        date,
        weightKg: weightKg !== undefined ? Number(weightKg) : null,
        caloriesConsumed: caloriesConsumed !== undefined ? Number(caloriesConsumed) : 0,
        proteinGrams: proteinGrams !== undefined ? Number(proteinGrams) : 0,
        waterMl: waterMl !== undefined ? Number(waterMl) : 2000,
        steps: steps !== undefined ? Number(steps) : 0,
        mealDetailsJson: mealDetails ? JSON.stringify(mealDetails) : null,
      },
    });

    return NextResponse.json({ success: true, log });
  } catch (error) {
    console.error('Error saving tracking log:', error);
    return NextResponse.json({ success: false, error: 'Failed to save log' }, { status: 500 });
  }
}
