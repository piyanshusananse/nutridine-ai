'use client';

import { ScoreRing } from '@/components/ui/ScoreRing';
import { useUser } from '@/context/UserContext';
import { MenuItemData, RecommendationResult, SmartSwapRecommendation } from '@/lib/engine/types';
import { AlertCircle, CheckCircle2, ChevronRight, Flame, Plus, Scale, Sparkles } from 'lucide-react';
import React from 'react';

interface DishCardProps {
  dish: MenuItemData;
  recommendation: RecommendationResult;
  smartSwap?: SmartSwapRecommendation | null;
  onSelect?: () => void;
  onAddMeal?: () => void;
}

export function DishCard({ dish, recommendation, smartSwap, onSelect, onAddMeal }: DishCardProps) {
  const { comparisonDishes, addToComparison, removeFromComparison, openDishModal } = useUser();

  const isCompared = comparisonDishes.some((d) => d.id === dish.id);

  const handleCardClick = () => {
    if (onSelect) {
      onSelect();
    } else {
      openDishModal(dish);
    }
  };

  return (
    <div className="group relative bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden">
      {/* Top Image & Score Header */}
      <div className="relative h-44 w-full bg-slate-100 dark:bg-slate-800 overflow-hidden cursor-pointer" onClick={handleCardClick}>
        {dish.imageUrl ? (
          <img
            src={dish.imageUrl}
            alt={dish.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl">🍽️</div>
        )}

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1.5 z-10">
          {dish.isVegetarian && (
            <span className="px-2 py-0.5 rounded-full bg-emerald-600/90 text-white text-[10px] font-bold backdrop-blur-sm shadow">
              🌱 VEG
            </span>
          )}
          {dish.isVegan && (
            <span className="px-2 py-0.5 rounded-full bg-green-600/90 text-white text-[10px] font-bold backdrop-blur-sm shadow">
              🌿 VEGAN
            </span>
          )}
          {dish.isGlutenFree && (
            <span className="px-2 py-0.5 rounded-full bg-sky-600/90 text-white text-[10px] font-bold backdrop-blur-sm shadow">
              🌾 GLUTEN-FREE
            </span>
          )}
          {dish.nutritionSource === 'AI_ESTIMATED' && (
            <span className="px-2 py-0.5 rounded-full bg-purple-600/90 text-white text-[10px] font-bold backdrop-blur-sm shadow flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" /> AI Est.
            </span>
          )}
        </div>

        {/* Floating Recommendation Score Ring */}
        <div className="absolute top-2.5 right-2.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-1 shadow-xl border border-white/40">
          <ScoreRing score={recommendation.score} size={48} strokeWidth={4} />
        </div>

        {/* Bottom overlay text */}
        <div className="absolute bottom-2.5 left-3 right-3 text-white">
          <div className="flex items-center justify-between">
            <span className="text-base font-extrabold tracking-tight drop-shadow line-clamp-1">{dish.name}</span>
            <span className="text-sm font-black text-emerald-300 drop-shadow ml-2">₹{Math.round(dish.price)}</span>
          </div>
        </div>
      </div>

      {/* Body Content */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        {/* Allergen or restriction alert */}
        {recommendation.hasAllergenConflict && (
          <div className="bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 rounded-xl p-2 flex items-start gap-2 text-rose-800 dark:text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
            <span className="font-semibold">{recommendation.allergenWarning}</span>
          </div>
        )}

        {recommendation.hasDietaryConflict && !recommendation.hasAllergenConflict && (
          <div className="bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 rounded-xl p-2 flex items-start gap-2 text-amber-800 dark:text-amber-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
            <span className="font-semibold">{recommendation.dietaryWarning}</span>
          </div>
        )}

        {/* Headline personalized reason */}
        {!recommendation.hasAllergenConflict && !recommendation.hasDietaryConflict && (
          <div className="flex items-start gap-2 text-xs">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <p className="text-slate-700 dark:text-slate-300 font-medium line-clamp-2 leading-relaxed">
              <strong className="font-bold text-slate-900 dark:text-white">Why:</strong> {recommendation.headlineReason}
            </p>
          </div>
        )}

        {/* Macros Bar */}
        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-2.5 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold">
          <div className="flex items-center gap-1 text-slate-900 dark:text-white">
            <Flame className="w-3.5 h-3.5 text-orange-500" />
            <span>{dish.calories} kcal</span>
          </div>
          <div className="text-emerald-700 dark:text-emerald-400">
            {dish.protein}g <span className="text-[10px] text-slate-400">Prot</span>
          </div>
          <div className="text-sky-700 dark:text-sky-400">
            {dish.carbohydrates}g <span className="text-[10px] text-slate-400">Carb</span>
          </div>
          <div className="text-amber-700 dark:text-amber-400">
            {dish.fat}g <span className="text-[10px] text-slate-400">Fat</span>
          </div>
        </div>

        {/* Smart Swap Callout if available */}
        {smartSwap && smartSwap.betterDish.id !== dish.id && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-2 flex items-center justify-between text-[11px] text-emerald-800 dark:text-emerald-300">
            <div className="flex items-center gap-1.5 line-clamp-1">
              <span className="font-bold">✨ Better Match:</span>
              <span className="font-semibold text-slate-900 dark:text-white">{smartSwap.betterDish.name}</span>
            </div>
            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 shrink-0 ml-1">
              {smartSwap.calorieDiff < 0 ? `${smartSwap.calorieDiff} kcal` : ''}
            </span>
          </div>
        )}

        {/* Card Footer Actions */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
          {/* Compare toggle */}
          <button
            onClick={() => {
              if (isCompared) {
                removeFromComparison(dish.id);
              } else {
                addToComparison(dish);
              }
            }}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              isCompared
                ? 'bg-sky-600 text-white'
                : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
            }`}
            title="Compare up to 3 dishes"
          >
            <Scale className="w-3.5 h-3.5" />
            <span>{isCompared ? 'Comparing' : 'Compare'}</span>
          </button>

          {/* View Details / Why */}
          <button
            onClick={handleCardClick}
            className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white dark:bg-emerald-600 dark:hover:bg-emerald-700 text-xs font-bold transition-all shadow-sm cursor-pointer"
          >
            <span>Why this match?</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
