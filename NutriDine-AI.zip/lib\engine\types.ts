export type Sex = 'MALE' | 'FEMALE' | 'OTHER';

export type ActivityLevel =
  | 'SEDENTARY'
  | 'LIGHT'
  | 'MODERATE'
  | 'VERY_ACTIVE'
  | 'EXTRA_ACTIVE';

export type UserGoal =
  | 'WEIGHT_LOSS'
  | 'WEIGHT_GAIN'
  | 'MUSCLE_GAIN'
  | 'MAINTENANCE'
  | 'BETTER_NUTRITION'
  | 'IMPROVED_PROTEIN'
  | 'BETTER_ENERGY'
  | 'CUSTOM'
  | 'NOT_SURE';

export type DietaryPreferenceType =
  | 'VEGETARIAN'
  | 'VEGAN'
  | 'EGGETARIAN'
  | 'NON_VEGETARIAN'
  | 'PESCATARIAN'
  | 'JAIN'
  | 'HALAL'
  | 'GLUTEN_FREE'
  | 'LACTOSE_FREE'
  | 'KETO'
  | 'LOW_CARB'
  | 'LOW_SODIUM';

export type AllergenType =
  | 'PEANUTS'
  | 'TREE_NUTS'
  | 'DAIRY'
  | 'EGGS'
  | 'SOY'
  | 'GLUTEN'
  | 'SHELLFISH'
  | 'FISH'
  | 'SESAME'
  | 'MUSTARD'
  | 'SULFITES';

export type SpicyPreference = 'MILD' | 'MEDIUM' | 'SPICY' | 'VERY_SPICY';
export type SweetPreference = 'LOW' | 'MODERATE' | 'HIGH';

export interface UserProfileData {
  id?: string;
  name: string;
  age: number;
  sex: Sex;
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: UserGoal;
  customGoalDesc?: string;
  targetCaloriesOverride?: number | null;
  targetProteinOverride?: number | null;
  spicyPreference?: SpicyPreference;
  sweetPreference?: SweetPreference;
  dietaryPreferences: DietaryPreferenceType[];
  allergies: AllergenType[];
  // Optional wellness inputs
  healthMarkers?: {
    restingHeartRate?: number;
    bloodPressureSys?: number;
    bloodPressureDia?: number;
    dailyWaterIntakeMl?: number;
    sleepDurationHours?: number;
    dailySteps?: number;
    waistCircumferenceCm?: number;
    bodyFatPercentage?: number;
    mealCountPerDay?: number;
  };
}

export interface BMICalculation {
  bmi: number;
  category: 'Underweight' | 'Healthy range' | 'Overweight' | 'Obesity class I' | 'Obesity class II+';
  color: string;
  disclaimer: string;
}

export interface EnergyNeeds {
  bmr: number;
  tdee: number;
  suggestedCalorieMin: number;
  suggestedCalorieMax: number;
  targetCalories: number;
  proteinRangeMin: number;
  proteinRangeMax: number;
  carbsRangeMin: number;
  carbsRangeMax: number;
  fatRangeMin: number;
  fatRangeMax: number;
  fiberTargetGrams: number;
  waterTargetLiters: number;
  disclaimer: string;
}

export interface MenuItemData {
  id: string;
  restaurantId: string;
  categoryId: string;
  categoryName?: string;
  name: string;
  description: string;
  price: number;
  servingSize: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number; // in mg
  saturatedFat: number;
  ingredients: string; // comma-separated or json
  allergens: string; // comma-separated or json
  preparationMethod?: string;
  isVegetarian: boolean;
  isVegan: boolean;
  isGlutenFree: boolean;
  isDairyFree: boolean;
  spicyLevel: number; // 0-3
  cuisine?: string;
  tags?: string;
  imageUrl?: string;
  isAvailable: boolean;
  nutritionSource: 'EXACT' | 'RESTAURANT_PROVIDED' | 'ESTIMATED' | 'AI_ESTIMATED';
}

export type RecommendationCategory =
  | 'BEST_CHOICE'
  | 'GOOD_CHOICE'
  | 'MODERATE'
  | 'OCCASIONAL'
  | 'NOT_RECOMMENDED';

export interface ScoreBreakdown {
  goalAlignment: { score: number; max: 30; reason: string };
  proteinSuitability: { score: number; max: 20; reason: string };
  calorieSuitability: { score: number; max: 20; reason: string };
  dietaryCompatibility: { score: number; max: 20; reason: string };
  nutritionalQuality: { score: number; max: 10; reason: string };
}

export interface RecommendationResult {
  menuItem: MenuItemData;
  score: number; // 0 - 100
  category: RecommendationCategory;
  categoryLabel: string;
  badgeColor: string;
  headlineReason: string;
  detailedExplanation: string[];
  suggestedModifications: string[];
  scoreBreakdown: ScoreBreakdown;
  allergenWarning?: string;
  dietaryWarning?: string;
  hasAllergenConflict: boolean;
  hasDietaryConflict: boolean;
}

export interface SmartSwapRecommendation {
  originalDish: MenuItemData;
  betterDish: MenuItemData;
  reason: string;
  calorieDiff: number; // e.g. -180
  proteinDiff: number; // e.g. +14g
  actionableTips: string[];
}

export interface MealCombination {
  mealType: 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK';
  restaurantId: string;
  restaurantName: string;
  items: {
    menuItem: MenuItemData;
    role: 'STARTER' | 'MAIN' | 'SIDE' | 'BEVERAGE' | 'DESSERT';
  }[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  totalSodium: number;
  combinedScore: number;
  goalFitVerdict: string;
  explanation: string;
}
