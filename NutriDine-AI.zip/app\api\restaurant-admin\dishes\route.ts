import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      restaurantId,
      categoryId,
      categoryName,
      name,
      description = '',
      price,
      servingSize = '1 serving',
      calories,
      protein,
      carbohydrates,
      fat,
      fiber = 0,
      sugar = 0,
      sodium = 0,
      saturatedFat = 0,
      ingredients = '',
      allergens = '',
      preparationMethod = 'Grilled',
      isVegetarian = false,
      isVegan = false,
      isGlutenFree = false,
      isDairyFree = false,
      spicyLevel = 1,
      cuisine = 'Fusion',
      imageUrl = '',
      nutritionSource = 'AI_ESTIMATED',
    } = body;

    let targetCatId = categoryId;

    // If categoryId not provided, find or create category by name
    if (!targetCatId && categoryName && restaurantId) {
      let cat = await prisma.menuCategory.findFirst({
        where: { restaurantId, name: categoryName },
      });
      if (!cat) {
        cat = await prisma.menuCategory.create({
          data: { restaurantId, name: categoryName, sortOrder: 99 },
        });
      }
      targetCatId = cat.id;
    }

    if (!restaurantId || !targetCatId || !name || price === undefined || calories === undefined) {
      return NextResponse.json(
        { success: false, error: 'Missing required dish fields (name, price, calories, restaurantId, categoryId)' },
        { status: 400 }
      );
    }

    const dish = await prisma.menuItem.create({
      data: {
        restaurantId,
        categoryId: targetCatId,
        name,
        description,
        price: Number(price),
        servingSize,
        calories: Number(calories),
        protein: Number(protein) || 0,
        carbohydrates: Number(carbohydrates) || 0,
        fat: Number(fat) || 0,
        fiber: Number(fiber) || 0,
        sugar: Number(sugar) || 0,
        sodium: Number(sodium) || 0,
        saturatedFat: Number(saturatedFat) || 0,
        ingredients,
        allergens,
        preparationMethod,
        isVegetarian: Boolean(isVegetarian),
        isVegan: Boolean(isVegan),
        isGlutenFree: Boolean(isGlutenFree),
        isDairyFree: Boolean(isDairyFree),
        spicyLevel: Number(spicyLevel) || 0,
        cuisine,
        imageUrl: imageUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
        nutritionSource,
      },
    });

    return NextResponse.json({ success: true, dish });
  } catch (error) {
    console.error('Error creating dish:', error);
    return NextResponse.json({ success: false, error: 'Failed to create dish' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const dishId = searchParams.get('id');

    if (!dishId) {
      return NextResponse.json({ success: false, error: 'Dish ID is required' }, { status: 400 });
    }

    await prisma.menuItem.delete({
      where: { id: dishId },
    });

    return NextResponse.json({ success: true, message: 'Dish deleted successfully' });
  } catch (error) {
    console.error('Error deleting dish:', error);
    return NextResponse.json({ success: false, error: 'Failed to delete dish' }, { status: 500 });
  }
}
