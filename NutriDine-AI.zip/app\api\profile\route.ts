import { calculateBMI } from '@/lib/engine/bmi';
import { calculateEnergyNeeds } from '@/lib/engine/bmr-tdee';
import { ActivityLevel, AllergenType, DietaryPreferenceType, Sex, UserGoal } from '@/lib/engine/types';
import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId') || 'user-alex';

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        profile: true,
        healthMarkers: true,
        dietaryPrefs: true,
        allergies: true,
      },
    });

    if (!user || !user.profile) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    const bmi = calculateBMI(user.profile.weightKg, user.profile.heightCm);
    const energy = calculateEnergyNeeds(
      user.profile.weightKg,
      user.profile.heightCm,
      user.profile.age,
      user.profile.sex as Sex,
      user.profile.activityLevel as ActivityLevel,
      user.profile.goal as UserGoal,
      user.profile.targetCaloriesOverride,
      user.profile.targetProteinOverride
    );

    return NextResponse.json({
      success: true,
      user,
      bmi,
      energy,
    });
  } catch (error) {
    console.error('Error fetching profile:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch profile' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      name,
      email,
      age,
      sex,
      heightCm,
      weightKg,
      activityLevel,
      goal,
      customGoalDesc,
      targetCaloriesOverride,
      targetProteinOverride,
      spicyPreference,
      sweetPreference,
      dietaryPreferences = [],
      allergies = [],
      healthMarkers = {},
    } = body;

    // Create or update custom user
    const userEmail = email || `user-${Date.now()}@nutridine.ai`;
    const userName = name || 'Healthy Diner';

    const user = await prisma.user.create({
      data: {
        name: userName,
        email: userEmail,
        role: 'USER',
        profile: {
          create: {
            age: Number(age) || 28,
            sex: sex || 'MALE',
            heightCm: Number(heightCm) || 175,
            weightKg: Number(weightKg) || 75,
            activityLevel: activityLevel || 'MODERATE',
            goal: goal || 'BETTER_NUTRITION',
            customGoalDesc,
            targetCaloriesOverride: targetCaloriesOverride ? Number(targetCaloriesOverride) : null,
            targetProteinOverride: targetProteinOverride ? Number(targetProteinOverride) : null,
            spicyPreference: spicyPreference || 'MEDIUM',
            sweetPreference: sweetPreference || 'MODERATE',
          },
        },
        healthMarkers: {
          create: {
            restingHeartRate: healthMarkers.restingHeartRate ? Number(healthMarkers.restingHeartRate) : null,
            bloodPressureSys: healthMarkers.bloodPressureSys ? Number(healthMarkers.bloodPressureSys) : null,
            bloodPressureDia: healthMarkers.bloodPressureDia ? Number(healthMarkers.bloodPressureDia) : null,
            dailyWaterIntakeMl: Number(healthMarkers.dailyWaterIntakeMl) || 2500,
            sleepDurationHours: Number(healthMarkers.sleepDurationHours) || 7.5,
            dailySteps: Number(healthMarkers.dailySteps) || 8000,
            waistCircumferenceCm: healthMarkers.waistCircumferenceCm ? Number(healthMarkers.waistCircumferenceCm) : null,
            bodyFatPercentage: healthMarkers.bodyFatPercentage ? Number(healthMarkers.bodyFatPercentage) : null,
          },
        },
        dietaryPrefs: {
          create: (dietaryPreferences as DietaryPreferenceType[]).map((pref) => ({ preference: pref })),
        },
        allergies: {
          create: (allergies as AllergenType[]).map((allergen) => ({ allergen, severity: 'HIGH' })),
        },
      },
      include: {
        profile: true,
        healthMarkers: true,
        dietaryPrefs: true,
        allergies: true,
      },
    });

    const bmi = calculateBMI(user.profile!.weightKg, user.profile!.heightCm);
    const energy = calculateEnergyNeeds(
      user.profile!.weightKg,
      user.profile!.heightCm,
      user.profile!.age,
      user.profile!.sex as Sex,
      user.profile!.activityLevel as ActivityLevel,
      user.profile!.goal as UserGoal,
      user.profile!.targetCaloriesOverride,
      user.profile!.targetProteinOverride
    );

    return NextResponse.json({ success: true, user, bmi, energy });
  } catch (error) {
    console.error('Error saving profile:', error);
    return NextResponse.json({ success: false, error: 'Failed to create profile' }, { status: 500 });
  }
}
