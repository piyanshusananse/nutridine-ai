import { evaluateDishRecommendation } from '@/lib/engine/scoring';
import { findSmartSwaps } from '@/lib/engine/smart-swaps';
import {
  ActivityLevel,
  AllergenType,
  DietaryPreferenceType,
  MenuItemData,
  Sex,
  UserGoal,
  UserProfileData,
} from '@/lib/engine/types';
import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId') || 'user-alex';

    const restaurant = await prisma.restaurant.findFirst({
      where: {
        OR: [{ id }, { slug: id }],
      },
      include: {
        categories: {
          orderBy: { sortOrder: 'asc' },
        },
        menuItems: {
          include: {
            category: true,
          },
        },
      },
    });

    if (!restaurant) {
      return NextResponse.json({ success: false, error: 'Restaurant not found' }, { status: 404 });
    }

    // Load active user profile for live personalization
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        profile: true,
        dietaryPrefs: true,
        allergies: true,
      },
    });

    let profileData: UserProfileData = {
      name: 'Guest',
      age: 28,
      sex: 'MALE',
      heightCm: 175,
      weightKg: 80,
      activityLevel: 'MODERATE',
      goal: 'WEIGHT_LOSS',
      dietaryPreferences: [],
      allergies: [],
    };

    if (user && user.profile) {
      profileData = {
        name: user.name,
        age: user.profile.age,
        sex: user.profile.sex as Sex,
        heightCm: user.profile.heightCm,
        weightKg: user.profile.weightKg,
        activityLevel: user.profile.activityLevel as ActivityLevel,
        goal: user.profile.goal as UserGoal,
        targetCaloriesOverride: user.profile.targetCaloriesOverride,
        targetProteinOverride: user.profile.targetProteinOverride,
        spicyPreference: user.profile.spicyPreference as any,
        sweetPreference: user.profile.sweetPreference as any,
        dietaryPreferences: user.dietaryPrefs.map((d) => d.preference as DietaryPreferenceType),
        allergies: user.allergies.map((a) => a.allergen as AllergenType),
      };
    }

    // Convert items and evaluate personalized scores
    const itemsData: MenuItemData[] = restaurant.menuItems.map((item) => ({
      id: item.id,
      restaurantId: item.restaurantId,
      categoryId: item.categoryId,
      categoryName: item.category.name,
      name: item.name,
      description: item.description,
      price: item.price,
      servingSize: item.servingSize,
      calories: item.calories,
      protein: item.protein,
      carbohydrates: item.carbohydrates,
      fat: item.fat,
      fiber: item.fiber,
      sugar: item.sugar,
      sodium: item.sodium,
      saturatedFat: item.saturatedFat,
      ingredients: item.ingredients,
      allergens: item.allergens,
      preparationMethod: item.preparationMethod || undefined,
      isVegetarian: item.isVegetarian,
      isVegan: item.isVegan,
      isGlutenFree: item.isGlutenFree,
      isDairyFree: item.isDairyFree,
      spicyLevel: item.spicyLevel,
      cuisine: item.cuisine || undefined,
      tags: item.tags || undefined,
      imageUrl: item.imageUrl || undefined,
      isAvailable: item.isAvailable,
      nutritionSource: item.nutritionSource as any,
    }));

    const personalizedItems = itemsData.map((item) => {
      const recommendation = evaluateDishRecommendation(item, profileData);
      const smartSwap = findSmartSwaps(item, itemsData, profileData);

      return {
        ...item,
        recommendation,
        smartSwap,
      };
    });

    return NextResponse.json({
      success: true,
      restaurant: {
        ...restaurant,
        menuItems: personalizedItems,
      },
      userProfile: profileData,
    });
  } catch (error) {
    console.error('Error fetching restaurant details:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch restaurant' }, { status: 500 });
  }
}
