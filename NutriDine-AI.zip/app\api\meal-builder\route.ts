import { buildSmartMealCombinations } from '@/lib/engine/meal-builder';
import {
  ActivityLevel,
  AllergenType,
  DietaryPreferenceType,
  MenuItemData,
  Sex,
  UserGoal,
  UserProfileData,
} from '@/lib/engine/types';
import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { restaurantId, userId = 'user-alex', mealType = 'DINNER', targetCalories } = body;

    if (!restaurantId) {
      return NextResponse.json({ success: false, error: 'restaurantId is required' }, { status: 400 });
    }

    const restaurant = await prisma.restaurant.findUnique({
      where: { id: restaurantId },
      include: {
        categories: true,
        menuItems: {
          include: { category: true },
        },
      },
    });

    if (!restaurant) {
      return NextResponse.json({ success: false, error: 'Restaurant not found' }, { status: 404 });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        profile: true,
        dietaryPrefs: true,
        allergies: true,
      },
    });

    let profileData: UserProfileData = {
      name: 'Alex',
      age: 28,
      sex: 'MALE',
      heightCm: 175,
      weightKg: 82,
      activityLevel: 'MODERATE',
      goal: 'WEIGHT_LOSS',
      dietaryPreferences: ['NON_VEGETARIAN'],
      allergies: [],
    };

    if (user && user.profile) {
      profileData = {
        name: user.name,
        age: user.profile.age,
        sex: user.profile.sex as Sex,
        heightCm: user.profile.heightCm,
        weightKg: user.profile.weightKg,
        activityLevel: user.profile.activityLevel as ActivityLevel,
        goal: user.profile.goal as UserGoal,
        targetCaloriesOverride: user.profile.targetCaloriesOverride,
        targetProteinOverride: user.profile.targetProteinOverride,
        spicyPreference: user.profile.spicyPreference as any,
        sweetPreference: user.profile.sweetPreference as any,
        dietaryPreferences: user.dietaryPrefs.map((d) => d.preference as DietaryPreferenceType),
        allergies: user.allergies.map((a) => a.allergen as AllergenType),
      };
    }

    const itemsData: MenuItemData[] = restaurant.menuItems.map((item) => ({
      id: item.id,
      restaurantId: item.restaurantId,
      categoryId: item.categoryId,
      categoryName: item.category.name,
      name: item.name,
      description: item.description,
      price: item.price,
      servingSize: item.servingSize,
      calories: item.calories,
      protein: item.protein,
      carbohydrates: item.carbohydrates,
      fat: item.fat,
      fiber: item.fiber,
      sugar: item.sugar,
      sodium: item.sodium,
      saturatedFat: item.saturatedFat,
      ingredients: item.ingredients,
      allergens: item.allergens,
      preparationMethod: item.preparationMethod || undefined,
      isVegetarian: item.isVegetarian,
      isVegan: item.isVegan,
      isGlutenFree: item.isGlutenFree,
      isDairyFree: item.isDairyFree,
      spicyLevel: item.spicyLevel,
      cuisine: item.cuisine || undefined,
      tags: item.tags || undefined,
      imageUrl: item.imageUrl || undefined,
      isAvailable: item.isAvailable,
      nutritionSource: item.nutritionSource as any,
    }));

    const combinations = buildSmartMealCombinations(
      restaurant.id,
      restaurant.name,
      itemsData,
      profileData,
      mealType,
      targetCalories ? Number(targetCalories) : undefined
    );

    return NextResponse.json({
      success: true,
      restaurantName: restaurant.name,
      combinations,
      userProfile: profileData,
    });
  } catch (error) {
    console.error('Error generating meal combinations:', error);
    return NextResponse.json({ success: false, error: 'Failed to build meal' }, { status: 500 });
  }
}
