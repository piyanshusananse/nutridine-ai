'use client';

import { MacroBar } from '@/components/ui/MacroBar';
import { ScoreRing } from '@/components/ui/ScoreRing';
import { useUser } from '@/context/UserContext';
import { evaluateDishRecommendation } from '@/lib/engine/scoring';
import { MenuItemData } from '@/lib/engine/types';
import {
  ArrowLeft,
  Award,
  CheckCircle2,
  ChefHat,
  Flame,
  Plus,
  Scale,
  Search,
  Sparkles,
  Trash2,
  UtensilsCrossed,
  X,
  Zap,
} from 'lucide-react';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

export default function ComparePage() {
  const { comparisonDishes, addToComparison, removeFromComparison, clearComparison, userProfile, openDishModal } =
    useUser();

  const [availableDishes, setAvailableDishes] = useState<MenuItemData[]>([]);
  const [dishSearch, setDishSearch] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    async function fetchAllDishes() {
      try {
        const res = await fetch('/api/restaurants');
        const data = await res.json();
        if (data.success && data.restaurants) {
          const all: MenuItemData[] = [];
          for (const r of data.restaurants) {
            const detailRes = await fetch(`/api/restaurants/${r.id}`);
            const detailJson = await detailRes.json();
            if (detailJson.success && detailJson.restaurant.menuItems) {
              all.push(...detailJson.restaurant.menuItems);
            }
          }
          setAvailableDishes(all);
        }
      } catch (err) {
        console.error(err);
      }
    }
    fetchAllDishes();
  }, []);

  const scoredDishes = comparisonDishes.map((dish) => ({
    dish,
    rec: evaluateDishRecommendation(dish, userProfile),
  }));

  // Determine top winner dish
  const winnerEntry = [...scoredDishes].sort((a, b) => b.rec.score - a.rec.score)[0];

  const filteredSearchDishes = availableDishes.filter(
    (d) =>
      d.name.toLowerCase().includes(dishSearch.toLowerCase()) &&
      !comparisonDishes.some((cd) => cd.id === d.id)
  );

  // Chart data formatting
  const chartData = [
    {
      metric: 'Calories (kcal)',
      ...comparisonDishes.reduce((acc, d) => ({ ...acc, [d.name]: d.calories }), {}),
    },
    {
      metric: 'Protein (g)',
      ...comparisonDishes.reduce((acc, d) => ({ ...acc, [d.name]: d.protein }), {}),
    },
    {
      metric: 'Carbs (g)',
      ...comparisonDishes.reduce((acc, d) => ({ ...acc, [d.name]: d.carbohydrates }), {}),
    },
    {
      metric: 'Fat (g)',
      ...comparisonDishes.reduce((acc, d) => ({ ...acc, [d.name]: d.fat }), {}),
    },
    {
      metric: 'Fiber (g)',
      ...comparisonDishes.reduce((acc, d) => ({ ...acc, [d.name]: d.fiber }), {}),
    },
  ];

  const colors = ['#10b981', '#0ea5e9', '#f59e0b', '#8b5cf6'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <Link
            href="/restaurants"
            className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white mb-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to restaurant menus</span>
          </Link>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Scale className="w-8 h-8 text-sky-500" />
            <span>Side-by-Side Food Comparison</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Compare nutrition, prices in ₹ INR, and personalized goal compatibility for{' '}
            <strong className="text-slate-900 dark:text-white">{userProfile.name}</strong> ({userProfile.goal.replace(/_/g, ' ')})
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Add Dish Button */}
          <div className="relative">
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Dish to Compare</span>
            </button>

            {isSearchOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-3 z-50 space-y-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={dishSearch}
                    onChange={(e) => setDishSearch(e.target.value)}
                    placeholder="Search dishes..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs focus:outline-none dark:text-white"
                  />
                </div>

                <div className="max-h-56 overflow-y-auto space-y-1">
                  {filteredSearchDishes.slice(0, 8).map((d) => (
                    <button
                      key={d.id}
                      onClick={() => {
                        addToComparison(d);
                        setIsSearchOpen(false);
                      }}
                      className="w-full p-2 rounded-xl text-left hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-xs cursor-pointer"
                    >
                      <div className="truncate">
                        <div className="font-bold text-slate-900 dark:text-white truncate">{d.name}</div>
                        <div className="text-[10px] text-slate-400">
                          ₹{Math.round(d.price)} • {d.calories} kcal • {d.protein}g protein
                        </div>
                      </div>
                      <Plus className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {comparisonDishes.length > 0 && (
            <button
              onClick={clearComparison}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-rose-600 dark:text-rose-400 text-xs font-bold hover:bg-rose-50 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear</span>
            </button>
          )}
        </div>
      </div>

      {comparisonDishes.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-4 max-w-md mx-auto">
          <Scale className="w-12 h-12 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">No Dishes in Comparison Matrix</h3>
          <p className="text-xs text-slate-500">
            Click &quot;Add Dish to Compare&quot; or browse restaurant menus and select &quot;Compare&quot; on any dish.
          </p>
          <Link
            href="/restaurants"
            className="px-5 py-2.5 rounded-2xl bg-emerald-600 text-white font-bold text-xs inline-flex items-center gap-2 shadow"
          >
            <UtensilsCrossed className="w-4 h-4" />
            <span>Discover Restaurant Menus</span>
          </Link>
        </div>
      ) : (
        <div className="space-y-8">
          {/* AI Winner Badge */}
          {winnerEntry && (
            <div className="bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-sky-500/10 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-xl shrink-0 shadow-lg shadow-emerald-600/30">
                  🏆
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                    Goal Winner Analysis
                  </span>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                    {winnerEntry.dish.name} is your top choice ({winnerEntry.rec.score}/100 Match)
                  </h3>
                  <p className="text-xs text-slate-700 dark:text-slate-300 mt-1 leading-relaxed max-w-2xl">
                    For your current <strong className="text-slate-900 dark:text-white">{userProfile.goal.replace(/_/g, ' ').toLowerCase()}</strong> goal,{' '}
                    <strong>{winnerEntry.dish.name}</strong> offers the best nutritional density ({winnerEntry.dish.protein}g protein at {winnerEntry.dish.calories} kcal for ₹{Math.round(winnerEntry.dish.price)}).
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* SIDE-BY-SIDE NUTRITION TABLE */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-black text-base text-slate-900 dark:text-white">
                Detailed Side-by-Side Nutrition Matrix
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="p-4 w-40">Metric</th>
                    {scoredDishes.map(({ dish, rec }) => (
                      <th key={dish.id} className="p-4 min-w-[200px]">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-900 dark:text-white font-black text-sm">{dish.name}</span>
                          <button
                            onClick={() => removeFromComparison(dish.id)}
                            className="p-1 rounded text-slate-400 hover:text-rose-600"
                            title="Remove"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <span className="text-[10px] text-slate-400 font-normal">
                          {(dish as any).restaurantName || 'Restaurant Dish'}
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {/* Match Score */}
                  <tr className="bg-emerald-50/40 dark:bg-emerald-950/20">
                    <td className="p-4 font-black text-emerald-800 dark:text-emerald-300">Goal Match Score</td>
                    {scoredDishes.map(({ dish, rec }) => (
                      <td key={dish.id} className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                            {rec.score}%
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200">
                            {rec.categoryLabel}
                          </span>
                        </div>
                      </td>
                    ))}
                  </tr>

                  {/* Price */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Price (INR)</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 font-black text-slate-900 dark:text-white">
                        ₹{Math.round(dish.price)}
                      </td>
                    ))}
                  </tr>

                  {/* Calories */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Calories</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 font-extrabold text-orange-600">
                        {dish.calories} kcal
                      </td>
                    ))}
                  </tr>

                  {/* Protein */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Protein</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 font-extrabold text-emerald-600">
                        {dish.protein}g
                      </td>
                    ))}
                  </tr>

                  {/* Carbohydrates */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Carbohydrates</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 text-slate-700 dark:text-slate-300">
                        {dish.carbohydrates}g
                      </td>
                    ))}
                  </tr>

                  {/* Fats */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Fat</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 text-slate-700 dark:text-slate-300">
                        {dish.fat}g
                      </td>
                    ))}
                  </tr>

                  {/* Fiber */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Dietary Fibre</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 text-slate-700 dark:text-slate-300">
                        {dish.fiber}g
                      </td>
                    ))}
                  </tr>

                  {/* Sodium */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Sodium</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4 text-slate-500">
                        {dish.sodium}mg
                      </td>
                    ))}
                  </tr>

                  {/* Dietary tags */}
                  <tr>
                    <td className="p-4 font-bold text-slate-600 dark:text-slate-400">Dietary Classification</td>
                    {scoredDishes.map(({ dish }) => (
                      <td key={dish.id} className="p-4">
                        <div className="flex flex-wrap gap-1">
                          {dish.isVegetarian && (
                            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              Vegetarian
                            </span>
                          )}
                          {dish.isGlutenFree && (
                            <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-800 text-[10px] font-bold">
                              Gluten-Free
                            </span>
                          )}
                          {!dish.isVegetarian && (
                            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
                              Non-Veg
                            </span>
                          )}
                        </div>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Visual Bar Chart */}
          <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              Visual Macro & Calorie Distribution
            </h3>
            <div className="h-72 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="metric" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderRadius: '12px',
                      color: '#fff',
                      border: 'none',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                  {comparisonDishes.map((dish, i) => (
                    <Bar key={dish.id} dataKey={dish.name} fill={colors[i % colors.length]} radius={[6, 6, 0, 0]} />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
