import { prisma } from '../lib/prisma';
import { calculateBMI } from '../lib/engine/bmi';
import { calculateEnergyNeeds } from '../lib/engine/bmr-tdee';
import { evaluateHardConstraints } from '../lib/engine/hard-constraints';
import { evaluateDishRecommendation, rankDishesForRemainingDeficit } from '../lib/engine/scoring';
import { MenuItemData, UserProfileData } from '../lib/engine/types';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ Integration Test Assertion Failed: ${message}`);
    process.exit(1);
  } else {
    console.log(`✔ Passed: ${message}`);
  }
}

async function runIntegrationTests() {
  console.log('=== Running NutriDine AI Full Integration Test Suite ===\n');

  // 1. Verify Database Seed Integrity
  console.log('--- 1. Testing Database Seed Integrity (10 Restaurants & Catalog) ---');
  const restaurants = await prisma.restaurant.findMany({
    include: {
      menuItems: true,
      categories: true,
    },
  });

  assert(restaurants.length >= 10, `Expected at least 10 restaurants, found ${restaurants.length}`);
  console.log(`Verified ${restaurants.length} partner restaurants.`);

  const totalDishes = restaurants.reduce((sum, r) => sum + r.menuItems.length, 0);
  assert(totalDishes >= 20, `Expected at least 20 dishes, found ${totalDishes}`);
  console.log(`Verified ${totalDishes} total menu dishes in database.`);

  // Verify all dishes have price in INR, valid calories, and protein
  for (const r of restaurants) {
    for (const item of r.menuItems) {
      assert(item.price > 0, `Dish "${item.name}" at "${r.name}" must have valid INR price (got ₹${item.price})`);
      assert(item.calories > 0, `Dish "${item.name}" must have positive calorie value`);
      assert(item.protein >= 0, `Dish "${item.name}" must have valid protein value`);
    }
  }
  console.log('All menu dishes verified with valid INR pricing and macro profiles.');

  // 2. Verify User Profiles & Personas
  console.log('\n--- 2. Testing User Profiles & Persona Database Loading ---');
  const alexUser = await prisma.user.findUnique({
    where: { id: 'user-alex' },
    include: { profile: true, dietaryPrefs: true, allergies: true },
  });
  assert(alexUser !== null, 'Alex Chen user record must exist');
  assert(alexUser!.profile?.goal === 'WEIGHT_LOSS', 'Alex goal must be WEIGHT_LOSS');

  const priyaUser = await prisma.user.findUnique({
    where: { id: 'user-priya' },
    include: { profile: true, dietaryPrefs: true, allergies: true },
  });
  assert(priyaUser !== null, 'Priya Patel user record must exist');
  assert(
    priyaUser!.allergies.some((a) => a.allergen === 'PEANUTS' || a.allergen === 'TREE_NUTS'),
    'Priya must have peanut/tree nut allergy records'
  );

  // 3. Test Food Logging & Daily Aggregation
  console.log('\n--- 3. Testing Food Logging & Daily Aggregation ---');
  const testDate = '2026-08-30';
  
  // Log a test meal
  const newLog = await prisma.foodLog.create({
    data: {
      userId: 'user-alex',
      dishName: 'Tandoori Chicken Tikka (Test)',
      restaurantName: 'Mumbai Spice House',
      mealType: 'DINNER',
      calories: 380,
      protein: 48,
      carbs: 6,
      fat: 16,
      fiber: 2,
      date: testDate,
    },
  });

  assert(newLog.id !== undefined, 'Food log entry must be created with valid ID');

  const logsToday = await prisma.foodLog.findMany({
    where: { userId: 'user-alex', date: testDate },
  });
  assert(logsToday.length >= 1, 'Today logs must contain at least 1 logged item');

  // Clean up test log
  await prisma.foodLog.delete({ where: { id: newLog.id } });
  console.log('Food log lifecycle (create, fetch, delete) verified.');

  // 4. Test Cross-Restaurant Deficit Recommendations
  console.log('\n--- 4. Testing Multi-Restaurant Deficit Match Ranking ---');
  const allDishes = await prisma.menuItem.findMany({
    include: { restaurant: true },
  });

  const formattedDishes: (MenuItemData & { restaurantName: string })[] = allDishes.map((item) => ({
    id: item.id,
    restaurantId: item.restaurantId,
    restaurantName: item.restaurant.name,
    categoryId: item.categoryId,
    name: item.name,
    description: item.description,
    price: item.price,
    servingSize: item.servingSize,
    calories: item.calories,
    protein: item.protein,
    carbohydrates: item.carbohydrates,
    fat: item.fat,
    fiber: item.fiber,
    sugar: item.sugar,
    sodium: item.sodium,
    saturatedFat: item.saturatedFat,
    ingredients: item.ingredients,
    allergens: item.allergens,
    isVegetarian: item.isVegetarian,
    isVegan: item.isVegan,
    isGlutenFree: item.isGlutenFree,
    isDairyFree: item.isDairyFree,
    spicyLevel: item.spicyLevel,
    cuisine: item.cuisine || undefined,
    isAvailable: item.isAvailable,
    nutritionSource: item.nutritionSource as any,
  }));

  const alexProfileData: UserProfileData = {
    name: 'Alex Chen',
    age: 28,
    sex: 'MALE',
    heightCm: 175,
    weightKg: 82,
    activityLevel: 'MODERATE',
    goal: 'WEIGHT_LOSS',
    dietaryPreferences: ['NON_VEGETARIAN'],
    allergies: [],
  };

  const remainingDeficit = {
    remainingCalories: 600,
    remainingProtein: 45,
    remainingCarbs: 40,
    remainingFat: 20,
    remainingFiber: 8,
    maxBudgetRupees: 500,
  };

  const recs = rankDishesForRemainingDeficit(formattedDishes, alexProfileData, remainingDeficit);
  assert(recs.length > 0, 'Must generate ranked deficit recommendations');
  assert(recs[0].score >= 80, `Top ranked dish must have high compatibility score, got ${recs[0].score}`);
  assert(recs[0].price <= 500, `Top ranked dish must be within ₹500 budget (got ₹${recs[0].price})`);

  console.log(`Top Deficit Recommendation: "${recs[0].dish.name}" from "${recs[0].restaurantName}" (Score: ${recs[0].score}%)`);

  // 5. Test Allergen Safety Exclusion in Multi-Restaurant Catalog
  console.log('\n--- 5. Testing Allergen Safety Exclusion Across Catalog ---');
  const priyaProfileData: UserProfileData = {
    name: 'Priya Patel',
    age: 26,
    sex: 'FEMALE',
    heightCm: 163,
    weightKg: 56,
    activityLevel: 'LIGHT',
    goal: 'MUSCLE_GAIN',
    dietaryPreferences: ['VEGETARIAN'],
    allergies: ['PEANUTS', 'TREE_NUTS'],
  };

  const priyaRecs = rankDishesForRemainingDeficit(formattedDishes, priyaProfileData, {
    remainingCalories: 700,
    remainingProtein: 35,
    remainingCarbs: 60,
    remainingFat: 25,
    remainingFiber: 10,
  });

  for (const r of priyaRecs) {
    assert(r.dish.isVegetarian === true, `Priya recommendation "${r.dish.name}" must be vegetarian`);
    const allergens = r.dish.allergens.toUpperCase();
    assert(
      !allergens.includes('PEANUT') && !allergens.includes('TREE_NUT'),
      `Priya recommendation "${r.dish.name}" must NOT contain peanuts or tree nuts (got ${r.dish.allergens})`
    );
  }
  console.log(`Verified all ${priyaRecs.length} recommendations for Priya are 100% vegetarian and peanut/tree-nut free.`);

  console.log('\n======================================================');
  console.log('🎉 ALL NUTRIDINE AI INTEGRATION TESTS PASSED! 🎉');
  console.log('======================================================\n');
}

runIntegrationTests()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
