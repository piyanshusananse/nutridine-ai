import prisma from '@/lib/prisma';
import type { NextAuthOptions } from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
    }),
  ],
  callbacks: {
    async session({ session, token }) {
      if (session.user && token.sub) {
        (session.user as any).id = token.sub;
      }
      return session;
    },
    async signIn({ user, account, profile }) {
      if (!user.email) return true;
      try {
        // Upsert user in database if not exists
        const existingUser = await prisma.user.findUnique({
          where: { email: user.email },
        });

        if (!existingUser) {
          await prisma.user.create({
            data: {
              email: user.email,
              name: user.name || 'NutriDine User',
              image: user.image || null,
              role: 'USER',
              profile: {
                create: {
                  age: 28,
                  sex: 'MALE',
                  heightCm: 172,
                  weightKg: 70,
                  activityLevel: 'MODERATE',
                  goal: 'BETTER_NUTRITION',
                  spicyPreference: 'MEDIUM',
                  sweetPreference: 'MODERATE',
                },
              },
            },
          });
        }
      } catch (err) {
        console.error('Error syncing user on sign in:', err);
      }
      return true;
    },
  },
  secret: process.env.NEXTAUTH_SECRET || 'nutridine_super_secret_ai_key_2026',
};
