import { estimateNutritionFromIngredients } from '@/lib/ai/estimate-nutrition';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dishName = 'Dish', ingredients = '', servingWeightGrams = 350 } = body;

    if (!ingredients.trim()) {
      return NextResponse.json(
        { success: false, error: 'Please provide at least 1 ingredient' },
        { status: 400 }
      );
    }

    const estimated = estimateNutritionFromIngredients(
      dishName,
      ingredients,
      Number(servingWeightGrams) || 350
    );

    return NextResponse.json({ success: true, estimation: estimated });
  } catch (error) {
    console.error('Error estimating nutrition:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to estimate nutrition' },
      { status: 500 }
    );
  }
}
