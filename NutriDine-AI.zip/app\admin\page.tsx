'use client';

import { MASTER_INGREDIENTS } from '@/lib/engine/ingredient-calculator';
import {
  AlertTriangle,
  Award,
  BarChart3,
  CheckCircle2,
  Database,
  Layers,
  Power,
  Scale,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Store,
  Users,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';

export default function AdminPage() {
  const [stats, setStats] = useState<any>(null);
  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [flaggedDishes, setFlaggedDishes] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'INGREDIENTS' | 'AUDIT' | 'RULES'>('OVERVIEW');
  const [ingredientSearch, setIngredientSearch] = useState('');

  // Configurable scoring weights state
  const [goalWeight, setGoalWeight] = useState(30);
  const [proteinWeight, setProteinWeight] = useState(20);
  const [calorieWeight, setCalorieWeight] = useState(20);
  const [dietaryWeight, setDietaryWeight] = useState(20);
  const [qualityWeight, setQualityWeight] = useState(10);

  useEffect(() => {
    async function loadAdminData() {
      try {
        const res = await fetch('/api/admin/overview');
        const data = await res.json();
        if (data.success) {
          setStats(data.stats);
          setRestaurants(data.restaurants);
          setFlaggedDishes(data.flaggedDishes);
        }
      } catch (err) {
        console.error(err);
      }
    }
    loadAdminData();
  }, []);

  const masterIngredientsList = Object.values(MASTER_INGREDIENTS).filter(
    (item) =>
      !ingredientSearch ||
      item.name.toLowerCase().includes(ingredientSearch.toLowerCase()) ||
      item.category.toLowerCase().includes(ingredientSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-10 rounded-3xl border border-slate-800 shadow-2xl space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-400 text-xs font-bold border border-indigo-500/30">
          <Award className="w-3.5 h-3.5" />
          <span>Super Admin & Platform Governance</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black">NutriDine Platform Governance</h1>
        <p className="text-xs sm:text-sm text-slate-300">
          Platform-wide oversight, restaurant verification, master ingredient database, and recommendation scoring weights.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Total Users</span>
            <Users className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white">
            {stats?.totalUsers || 5}
          </div>
          <div className="text-[10px] text-slate-500">Active dining profiles</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Restaurants</span>
            <Store className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white">
            {stats?.totalRestaurants || restaurants.length || 10}
          </div>
          <div className="text-[10px] text-slate-500">Verified restaurant partners</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Total Dishes</span>
            <Layers className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white">
            {stats?.totalDishes || 107}
          </div>
          <div className="text-[10px] text-slate-500">Menu items in database</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Verified Nutrition</span>
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-3xl font-black text-emerald-600 dark:text-emerald-400">
            100%
          </div>
          <div className="text-[10px] text-slate-500">Safety & Allergen verified</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto scrollbar-none">
        {[
          { id: 'OVERVIEW', label: 'Restaurant Partners' },
          { id: 'INGREDIENTS', label: 'Master Nutrition Database' },
          { id: 'AUDIT', label: 'Nutrition & Flagged Audit' },
          { id: 'RULES', label: 'Scoring Weight Engine' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-slate-900 text-white dark:bg-emerald-600 shadow'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: RESTAURANT MANAGEMENT */}
      {activeTab === 'OVERVIEW' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 font-bold text-sm">
            Restaurant Partners & Status
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold uppercase">
                <tr>
                  <th className="p-4">Restaurant</th>
                  <th className="p-4">Location</th>
                  <th className="p-4">Cuisines</th>
                  <th className="p-4">Dishes</th>
                  <th className="p-4">Rating</th>
                  <th className="p-4">Verification</th>
                  <th className="p-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {restaurants.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="p-4 font-bold text-slate-900 dark:text-white">{r.name}</td>
                    <td className="p-4 text-slate-500">{r.city}, {r.state}</td>
                    <td className="p-4 text-slate-600 dark:text-slate-300">{r.cuisineTypes}</td>
                    <td className="p-4 font-bold text-emerald-600">{r._count?.menuItems || 10} items</td>
                    <td className="p-4 font-bold">⭐ {r.rating} ({r.reviewCount})</td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                        ✓ Verified Partner
                      </span>
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black">
                        Active
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: MASTER INGREDIENTS DATABASE */}
      {activeTab === 'INGREDIENTS' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm space-y-4 p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-600" />
                <span>Master Ingredient Nutrition Catalog</span>
              </h3>
              <p className="text-xs text-slate-500">
                Reference nutritional profiles per 100g used by the automatic recipe calculation engine.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={ingredientSearch}
                onChange={(e) => setIngredientSearch(e.target.value)}
                placeholder="Search ingredients..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs border border-slate-200 dark:border-slate-700 dark:text-white"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold uppercase">
                <tr>
                  <th className="p-3">Ingredient</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Calories / 100g</th>
                  <th className="p-3">Protein</th>
                  <th className="p-3">Carbs</th>
                  <th className="p-3">Fat</th>
                  <th className="p-3">Fiber</th>
                  <th className="p-3">Sodium</th>
                  <th className="p-3">Allergens</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {masterIngredientsList.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="p-3 font-bold text-slate-900 dark:text-white">{item.name}</td>
                    <td className="p-3 text-slate-500">{item.category}</td>
                    <td className="p-3 font-extrabold text-orange-600">{item.caloriesPer100g} kcal</td>
                    <td className="p-3 font-bold text-emerald-600">{item.proteinPer100g}g</td>
                    <td className="p-3 text-slate-700 dark:text-slate-300">{item.carbsPer100g}g</td>
                    <td className="p-3 text-slate-700 dark:text-slate-300">{item.fatPer100g}g</td>
                    <td className="p-3 text-slate-700 dark:text-slate-300">{item.fiberPer100g}g</td>
                    <td className="p-3 text-slate-500">{item.sodiumMgPer100g}mg</td>
                    <td className="p-3">
                      {item.allergens.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {item.allergens.map((a) => (
                            <span key={a} className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 text-[9px] font-bold">
                              {a}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[10px]">None</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT & FLAGGED ITEMS */}
      {activeTab === 'AUDIT' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-amber-600 font-bold text-sm">
              <AlertTriangle className="w-5 h-5" />
              <span>Nutrition Safety & Allergen Audit Notice</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Items flagged for high calorie density (&gt;750 kcal), high sodium (&gt;800mg), or high simple sugars (&gt;15g) automatically receive dietary balance tips and are tagged for portion awareness.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 font-bold text-sm">
              Audited Dishes with Specific Nutritional Markers
            </div>
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold uppercase">
                <tr>
                  <th className="p-4">Dish</th>
                  <th className="p-4">Restaurant</th>
                  <th className="p-4">Calories</th>
                  <th className="p-4">Sodium</th>
                  <th className="p-4">Sugar</th>
                  <th className="p-4">Data Source</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {flaggedDishes.map((dish) => (
                  <tr key={dish.id}>
                    <td className="p-4 font-bold text-slate-900 dark:text-white">{dish.name}</td>
                    <td className="p-4 text-slate-500">{dish.restaurant?.name || 'Partner'}</td>
                    <td className="p-4 font-bold">{dish.calories} kcal</td>
                    <td className="p-4 text-amber-600 font-bold">{dish.sodium}mg</td>
                    <td className="p-4 text-purple-600 font-bold">{dish.sugar}g</td>
                    <td className="p-4 font-semibold">{dish.nutritionSource}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: SCORING WEIGHTS ENGINE */}
      {activeTab === 'RULES' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xl space-y-6 max-w-2xl">
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Recommendation Engine Scoring Weights (100 pts total)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Configure the relative contribution of each deterministic sub-score factor.
            </p>
          </div>

          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <div className="flex justify-between font-bold">
                <span>Goal Alignment Weight:</span>
                <span className="text-emerald-600 font-black">{goalWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={50}
                value={goalWeight}
                onChange={(e) => setGoalWeight(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-bold">
                <span>Protein Suitability Weight:</span>
                <span className="text-emerald-600 font-black">{proteinWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={40}
                value={proteinWeight}
                onChange={(e) => setProteinWeight(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-bold">
                <span>Calorie Budget Suitability:</span>
                <span className="text-emerald-600 font-black">{calorieWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={40}
                value={calorieWeight}
                onChange={(e) => setCalorieWeight(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-bold">
                <span>Dietary & Taste Fit:</span>
                <span className="text-emerald-600 font-black">{dietaryWeight} pts</span>
              </div>
              <input
                type="range"
                min={10}
                max={30}
                value={dietaryWeight}
                onChange={(e) => setDietaryWeight(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-bold">
                <span>Nutritional Quality & Fiber:</span>
                <span className="text-emerald-600 font-black">{qualityWeight} pts</span>
              </div>
              <input
                type="range"
                min={5}
                max={20}
                value={qualityWeight}
                onChange={(e) => setQualityWeight(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
