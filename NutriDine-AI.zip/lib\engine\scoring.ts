import { calculateEnergyNeeds } from './bmr-tdee';
import { evaluateHardConstraints } from './hard-constraints';
import {
  MenuItemData,
  RecommendationCategory,
  RecommendationResult,
  ScoreBreakdown,
  UserProfileData,
} from './types';

/**
 * Calculates a transparent, multi-factor recommendation score (0-100)
 * tailored to an individual user's profile, goals, and restrictions.
 */
export function evaluateDishRecommendation(
  dish: MenuItemData,
  profile: UserProfileData
): RecommendationResult {
  // 1. Evaluate Hard Constraints first (Allergies & Strict Diets)
  const hardConstraints = evaluateHardConstraints(dish, profile);

  const energyNeeds = calculateEnergyNeeds(
    profile.weightKg,
    profile.heightCm,
    profile.age,
    profile.sex,
    profile.activityLevel,
    profile.goal,
    profile.targetCaloriesOverride,
    profile.targetProteinOverride
  );

  const targetMealCalories = Math.round(energyNeeds.targetCalories * 0.35); // Single meal allocation (~35%)
  const targetMealProtein = Math.round((energyNeeds.proteinRangeMin + energyNeeds.proteinRangeMax) / 2 / 3); // ~1/3 of daily

  // Initialize score breakdown
  const breakdown: ScoreBreakdown = {
    goalAlignment: { score: 0, max: 30, reason: '' },
    proteinSuitability: { score: 0, max: 20, reason: '' },
    calorieSuitability: { score: 0, max: 20, reason: '' },
    dietaryCompatibility: { score: 0, max: 20, reason: '' },
    nutritionalQuality: { score: 0, max: 10, reason: '' },
  };

  const detailedExplanation: string[] = [];
  const suggestedModifications: string[] = [];

  // If hard constraint fails, immediate exit with 0 score
  if (hardConstraints.isExcluded) {
    let warningHeadline = '';
    if (hardConstraints.hasAllergenConflict) {
      warningHeadline = `Allergen Alert: Contains ${hardConstraints.conflictingAllergens.join(', ')}`;
      detailedExplanation.push(
        `This item is not recommended because it contains ingredients conflicting with your declared allergies (${hardConstraints.conflictingAllergens.join(
          ', '
        )}).`
      );
    }
    if (hardConstraints.hasDietaryConflict) {
      warningHeadline = warningHeadline || `Dietary Mismatch: ${hardConstraints.conflictingPreferences.join(', ')}`;
      detailedExplanation.push(
        `This item does not align with your strict ${hardConstraints.conflictingPreferences.join(
          ', '
        )} dietary preference.`
      );
    }

    return {
      menuItem: dish,
      score: 0,
      category: 'NOT_RECOMMENDED',
      categoryLabel: 'Not Recommended',
      badgeColor: 'rose',
      headlineReason: warningHeadline || 'Excluded due to restriction conflict',
      detailedExplanation,
      suggestedModifications: ['Please choose an alternative item that is safe for your allergies/diet.'],
      scoreBreakdown: breakdown,
      allergenWarning: hardConstraints.allergenWarning,
      dietaryWarning: hardConstraints.dietaryWarning,
      hasAllergenConflict: hardConstraints.hasAllergenConflict,
      hasDietaryConflict: hardConstraints.hasDietaryConflict,
    };
  }

  // --- Sub-score 1: Goal Alignment (0 - 30 pts) ---
  let goalScore = 20;
  const proteinRatio = dish.calories > 0 ? (dish.protein * 4) / dish.calories : 0; // % of calories from protein

  switch (profile.goal) {
    case 'WEIGHT_LOSS':
      if (dish.calories <= 550 && proteinRatio >= 0.35) {
        goalScore = 29;
        detailedExplanation.push('High protein-to-calorie density promotes fullness while sustaining a calorie deficit.');
      } else if (dish.calories <= 650 && proteinRatio >= 0.25) {
        goalScore = 25;
        detailedExplanation.push('Solid protein ratio supports muscle retention during weight loss.');
      } else if (dish.calories >= 750 || dish.saturatedFat >= 18) {
        goalScore = 14;
        detailedExplanation.push('High energy and saturated fat density; requires portion moderation for fat loss.');
      } else {
        goalScore = 19;
      }
      break;

    case 'MUSCLE_GAIN':
    case 'IMPROVED_PROTEIN':
      if (dish.protein >= 35) {
        goalScore = 29;
        detailedExplanation.push(`Rich in high-quality protein (${dish.protein}g) which strongly supports muscle hypertrophy.`);
      } else if (dish.protein >= 22) {
        goalScore = 24;
        detailedExplanation.push(`Good protein contribution (${dish.protein}g) towards your daily muscle building target.`);
      } else {
        goalScore = 14;
        detailedExplanation.push('Lower protein content relative to your muscle gain target.');
      }
      break;

    case 'WEIGHT_GAIN':
      if (dish.calories >= 550 && dish.protein >= 25) {
        goalScore = 29;
        detailedExplanation.push('Nutrient and energy-dense profile helps you hit your caloric surplus comfortably.');
      } else {
        goalScore = 20;
      }
      break;

    case 'BETTER_ENERGY':
      if (dish.carbohydrates >= 25 && dish.fiber >= 4 && dish.sugar <= 10) {
        goalScore = 28;
        detailedExplanation.push('Complex carbohydrates with fiber provide sustained, crash-free energy.');
      } else if (dish.sugar > 20) {
        goalScore = 13;
        detailedExplanation.push('Higher simple sugars may cause rapid energy spikes and dips.');
      } else {
        goalScore = 20;
      }
      break;

    case 'MAINTENANCE':
    case 'BETTER_NUTRITION':
    case 'NOT_SURE':
    default:
      if (dish.fiber >= 3 && dish.protein >= 15 && dish.saturatedFat <= 6) {
        goalScore = 27;
        detailedExplanation.push('Well-balanced macronutrient distribution suitable for overall vitality and wellness.');
      } else {
        goalScore = 20;
      }
      break;
  }
  breakdown.goalAlignment = {
    score: Math.min(30, Math.max(0, goalScore)),
    max: 30,
    reason: `Aligned with your ${profile.goal.replace(/_/g, ' ').toLowerCase()} goal`,
  };

  // --- Sub-score 2: Protein Suitability (0 - 20 pts) ---
  let proteinScore = 10;
  const proteinPercentOfTarget = dish.protein / (targetMealProtein || 25);

  if (proteinPercentOfTarget >= 0.85 && proteinPercentOfTarget <= 1.5) {
    proteinScore = 20;
    detailedExplanation.push(`Delivers ${dish.protein}g protein, hitting your ~${targetMealProtein}g per-meal target.`);
  } else if (proteinPercentOfTarget > 1.5) {
    proteinScore = 18;
    detailedExplanation.push(`High protein concentration (${dish.protein}g).`);
  } else if (proteinPercentOfTarget >= 0.5) {
    proteinScore = 14;
    detailedExplanation.push(`Moderate protein (${dish.protein}g). Pair with a protein-rich side if needed.`);
  } else {
    proteinScore = 8;
    detailedExplanation.push(`Modest protein (${dish.protein}g). Consider adding a protein complement.`);
  }
  breakdown.proteinSuitability = {
    score: Math.min(20, Math.max(0, proteinScore)),
    max: 20,
    reason: `${dish.protein}g protein vs ~${targetMealProtein}g meal target`,
  };

  // --- Sub-score 3: Calorie Suitability (0 - 20 pts) ---
  let calorieScore = 15;

  if (profile.goal === 'WEIGHT_LOSS') {
    if (dish.calories >= 300 && dish.calories <= 550) {
      calorieScore = 20;
      detailedExplanation.push(`${dish.calories} kcal is an ideal moderate calorie budget for weight management.`);
    } else if (dish.calories < 300) {
      calorieScore = 17; // Light meal / snack
    } else if (dish.calories <= 680) {
      calorieScore = 14;
    } else {
      calorieScore = 8; // High calorie for weight loss
      suggestedModifications.push('Rich entrée: Consider sharing or saving half for later.');
    }
  } else {
    const calorieDiff = Math.abs(dish.calories - targetMealCalories);
    const diffPercentage = calorieDiff / (targetMealCalories || 600);

    if (diffPercentage <= 0.2) {
      calorieScore = 20;
      detailedExplanation.push(`${dish.calories} kcal fits smoothly within your ~${targetMealCalories} kcal estimated meal budget.`);
    } else if (diffPercentage <= 0.4) {
      calorieScore = 16;
    } else if (dish.calories > targetMealCalories * 1.5) {
      calorieScore = 9;
      suggestedModifications.push('Consider sharing with a dining partner or taking half home for another meal.');
    } else {
      calorieScore = 12;
    }
  }

  breakdown.calorieSuitability = {
    score: Math.min(20, Math.max(0, calorieScore)),
    max: 20,
    reason: `${dish.calories} kcal relative to ~${targetMealCalories} kcal meal budget`,
  };

  // --- Sub-score 4: Dietary & Taste Preferences (0 - 20 pts) ---
  let dietScore = 18;

  // Spicy compatibility
  if (profile.spicyPreference === 'MILD' && dish.spicyLevel >= 2) {
    dietScore -= 5;
    suggestedModifications.push('Ask the chef for a mild spice level or yogurt/raita on the side.');
  } else if (profile.spicyPreference === 'VERY_SPICY' && dish.spicyLevel >= 2) {
    dietScore += 2;
  }

  // Preparation method bonus
  const prep = (dish.preparationMethod || '').toLowerCase();
  if (prep.includes('grilled') || prep.includes('tandoori') || prep.includes('steamed') || prep.includes('baked') || prep.includes('raw')) {
    dietScore += 2;
    detailedExplanation.push(`Clean cooking method (${dish.preparationMethod || 'Grilled/Tandoori'}) with minimal added oils.`);
  } else if (prep.includes('fried') || prep.includes('crispy deep fried')) {
    dietScore -= 4;
    suggestedModifications.push('Choose grilled or baked preparation if available.');
  }

  breakdown.dietaryCompatibility = {
    score: Math.min(20, Math.max(0, dietScore)),
    max: 20,
    reason: 'Taste preference & cooking method compatibility',
  };

  // --- Sub-score 5: Nutritional Quality & Micronutrients (0 - 10 pts) ---
  let qualityScore = 6;
  if (dish.fiber >= 5) {
    qualityScore += 2;
    detailedExplanation.push(`High in dietary fiber (${dish.fiber}g) for digestive wellness.`);
  }
  if (dish.sodium > 0 && dish.sodium < 600) {
    qualityScore += 1;
  } else if (dish.sodium > 1100) {
    qualityScore -= 2;
    suggestedModifications.push('Higher sodium: Drink extra water with this meal.');
  }
  if (dish.sugar > 0 && dish.sugar < 6) {
    qualityScore += 1;
  } else if (dish.sugar > 18) {
    qualityScore -= 2;
  }
  if (dish.saturatedFat > 15) {
    qualityScore -= 2;
  }

  breakdown.nutritionalQuality = {
    score: Math.min(10, Math.max(0, qualityScore)),
    max: 10,
    reason: 'Fiber, sodium, and fat balance',
  };

  // Total Score Calculation
  const totalScore =
    breakdown.goalAlignment.score +
    breakdown.proteinSuitability.score +
    breakdown.calorieSuitability.score +
    breakdown.dietaryCompatibility.score +
    breakdown.nutritionalQuality.score;

  const score = Math.min(100, Math.max(0, Math.round(totalScore)));

  // Categorize
  let category: RecommendationCategory = 'GOOD_CHOICE';
  let categoryLabel = 'Good Choice';
  let badgeColor = 'emerald';
  let headlineReason = '';

  if (score >= 85) {
    category = 'BEST_CHOICE';
    categoryLabel = 'Best Choice';
    badgeColor = 'emerald';
    headlineReason = 'Strongest match for your current nutritional goals and dietary profile.';
  } else if (score >= 70) {
    category = 'GOOD_CHOICE';
    categoryLabel = 'Good Choice';
    badgeColor = 'teal';
    headlineReason = 'Solid nutritional profile with minor tradeoffs for your target.';
  } else if (score >= 50) {
    category = 'MODERATE';
    categoryLabel = 'Moderate';
    badgeColor = 'amber';
    headlineReason = 'Can fit nicely with portion control or minor ingredient adjustments.';
  } else if (score >= 30) {
    category = 'OCCASIONAL';
    categoryLabel = 'Occasional Treat';
    badgeColor = 'orange';
    headlineReason = 'A great indulgence that can fit occasionally into a balanced lifestyle.';
  } else {
    category = 'NOT_RECOMMENDED';
    categoryLabel = 'Lower Match';
    badgeColor = 'slate';
    headlineReason = 'Less aligned with your current daily targets.';
  }

  if (suggestedModifications.length === 0) {
    suggestedModifications.push('Enjoy as served, or request dressing/sauces on the side.');
  }

  return {
    menuItem: dish,
    score,
    category,
    categoryLabel,
    badgeColor,
    headlineReason,
    detailedExplanation,
    suggestedModifications,
    scoreBreakdown: breakdown,
    hasAllergenConflict: false,
    hasDietaryConflict: false,
  };
}

export interface DeficitContext {
  remainingCalories: number;
  remainingProtein: number;
  remainingCarbs: number;
  remainingFat: number;
  remainingFiber: number;
  maxBudgetRupees?: number;
  preferredCuisines?: string[];
  mealType?: 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK';
}

export interface WhatToEatRecommendation {
  dish: MenuItemData;
  restaurantName?: string;
  rank: number;
  score: number;
  proteinProvided: number;
  calorieProvided: number;
  price: number;
  headlineReason: string;
  detailedWhy: string;
  actionableModifications: string[];
}

/**
 * Evaluates and ranks menu items specifically against a user's remaining daily nutritional deficit.
 */
export function rankDishesForRemainingDeficit(
  dishes: (MenuItemData & { restaurantName?: string })[],
  profile: UserProfileData,
  deficit: DeficitContext
): WhatToEatRecommendation[] {
  const scoredItems: { item: MenuItemData & { restaurantName?: string }; score: number; why: string; headline: string }[] = [];

  for (const dish of dishes) {
    // 1. Hard constraints check
    const hard = evaluateHardConstraints(dish, profile);
    if (hard.isExcluded) continue;

    // 2. Base recommendation score
    const baseRec = evaluateDishRecommendation(dish, profile);

    // 3. Deficit matching score
    let deficitScore = baseRec.score * 0.4; // 40% weight from base goal compatibility

    // Protein contribution to deficit (up to 30 pts)
    if (deficit.remainingProtein > 0) {
      const proteinCoverageRatio = dish.protein / deficit.remainingProtein;
      if (proteinCoverageRatio >= 0.6 && proteinCoverageRatio <= 1.3) {
        deficitScore += 30; // optimal protein coverage
      } else if (proteinCoverageRatio >= 0.3) {
        deficitScore += 20;
      } else {
        deficitScore += 10;
      }
    } else {
      deficitScore += 20;
    }

    // Calorie fit to remaining deficit (up to 20 pts)
    if (deficit.remainingCalories > 0) {
      const calRatio = dish.calories / deficit.remainingCalories;
      if (calRatio >= 0.5 && calRatio <= 1.05) {
        deficitScore += 20; // fits right within remaining calorie budget
      } else if (calRatio < 0.5) {
        deficitScore += 16; // easily fits
      } else if (calRatio <= 1.25) {
        deficitScore += 8; // slight surplus
      } else {
        deficitScore += 2; // heavily exceeds
      }
    } else {
      deficitScore += 10;
    }

    // Budget check (up to 10 pts)
    if (deficit.maxBudgetRupees && deficit.maxBudgetRupees > 0) {
      if (dish.price <= deficit.maxBudgetRupees) {
        deficitScore += 10;
      } else if (dish.price <= deficit.maxBudgetRupees * 1.2) {
        deficitScore += 5;
      }
    } else {
      deficitScore += 10;
    }

    // Cuisine preference bonus
    if (deficit.preferredCuisines && deficit.preferredCuisines.length > 0 && dish.cuisine) {
      if (deficit.preferredCuisines.some((c) => dish.cuisine?.toLowerCase().includes(c.toLowerCase()))) {
        deficitScore += 5;
      }
    }

    const finalScore = Math.min(100, Math.max(0, Math.round(deficitScore)));

    // Generate dynamic explanation
    let dynamicWhy = '';
    if (deficit.remainingProtein > 15 && dish.protein >= 20) {
      dynamicWhy = `Recommended because you have ~${Math.round(deficit.remainingProtein)}g protein remaining today, and this dish provides ${dish.protein}g protein with ${dish.calories} kcal.`;
    } else if (deficit.remainingCalories > 0 && dish.calories <= deficit.remainingCalories) {
      dynamicWhy = `Fits neatly within your remaining ${Math.round(deficit.remainingCalories)} kcal budget with balanced macros.`;
    } else {
      dynamicWhy = `Optimal balance of nutrients aligned with your active ${profile.goal.replace(/_/g, ' ').toLowerCase()} goal.`;
    }

    const headline = `Provides ${dish.protein}g Protein (${dish.calories} kcal) for ₹${Math.round(dish.price)}`;

    scoredItems.push({
      item: dish,
      score: finalScore,
      why: dynamicWhy,
      headline,
    });
  }

  // Sort descending by final score
  scoredItems.sort((a, b) => b.score - a.score);

  return scoredItems.map((entry, idx) => ({
    dish: entry.item,
    restaurantName: entry.item.restaurantName,
    rank: idx + 1,
    score: entry.score,
    proteinProvided: entry.item.protein,
    calorieProvided: entry.item.calories,
    price: entry.item.price,
    headlineReason: entry.headline,
    detailedWhy: entry.why,
    actionableModifications: [
      'Ask for sauce/dressing on the side for precise calorie control.',
      'Pairs great with fresh lime water or green tea.',
    ],
  }));
}

