import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const users = await prisma.user.findMany({
      where: { role: 'USER' },
      include: {
        profile: true,
        healthMarkers: true,
        dietaryPrefs: true,
        allergies: true,
      },
    });

    return NextResponse.json({ success: true, personas: users });
  } catch (error) {
    console.error('Failed to fetch personas:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch personas' }, { status: 500 });
  }
}
