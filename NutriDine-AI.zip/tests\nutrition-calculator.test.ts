import {
  calculateRecipeNutrition,
  MASTER_INGREDIENTS,
} from '../lib/engine/ingredient-calculator';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ Assertion Failed: ${message}`);
    process.exit(1);
  } else {
    console.log(`✔ Passed: ${message}`);
  }
}

console.log('=== Running Ingredient Auto-Calculator Verification Tests ===\n');

// 1. Test Single Ingredient Nutrition Retrieval
console.log('--- 1. Testing Single Ingredient Metrics ---');
const paneer = MASTER_INGREDIENTS['paneer'];
assert(paneer !== undefined, 'Paneer must exist in master ingredient database');
assert(paneer.caloriesPer100g === 265, 'Paneer calories per 100g should be 265');
assert(paneer.proteinPer100g === 18.3, 'Paneer protein per 100g should be 18.3g');
assert(paneer.allergens.includes('DAIRY'), 'Paneer must declare DAIRY allergen');
assert(paneer.isVegetarian === true, 'Paneer must be vegetarian');

const chicken = MASTER_INGREDIENTS['chicken_breast'];
assert(chicken.isVegetarian === false, 'Chicken breast must not be vegetarian');
assert(chicken.proteinPer100g === 31.0, 'Chicken breast protein per 100g should be 31.0g');

// 2. Test Multi-Ingredient Recipe Aggregation (e.g. Paneer Tikka Skewers)
console.log('\n--- 2. Testing Multi-Ingredient Recipe Nutrition Calculation ---');
// Recipe: Paneer 150g, Bell Pepper 50g, Onion 40g, Mustard Oil 10g
const paneerTikkaRecipe = [
  { ingredientKey: 'paneer', quantityGrams: 150 },
  { ingredientKey: 'bell_pepper', quantityGrams: 50 },
  { ingredientKey: 'onion', quantityGrams: 40 },
  { ingredientKey: 'mustard_oil', quantityGrams: 10 },
];

const calculatedTikka = calculateRecipeNutrition(paneerTikkaRecipe);
// Paneer (1.5 * 265 = 397.5) + Bell pepper (0.5 * 31 = 15.5) + Onion (0.4 * 40 = 16) + Mustard oil (0.1 * 884 = 88.4) = 517.4 -> ~517 kcal
assert(calculatedTikka.totalWeightGrams === 250, 'Total weight should be 250g');
assert(calculatedTikka.calories >= 510 && calculatedTikka.calories <= 530, `Calculated calories should be ~517, got ${calculatedTikka.calories}`);
// Protein: 1.5 * 18.3 + 0.5 * 1.0 + 0.4 * 1.1 + 0 = 27.45 + 0.5 + 0.44 = ~28.4g
assert(calculatedTikka.protein >= 27.5 && calculatedTikka.protein <= 29.5, `Calculated protein should be ~28.4g, got ${calculatedTikka.protein}g`);
assert(calculatedTikka.isVegetarian === true, 'Recipe must be vegetarian');
assert(calculatedTikka.isGlutenFree === true, 'Recipe must be gluten-free');
assert(calculatedTikka.allergens.includes('DAIRY'), 'Recipe must detect DAIRY allergen from paneer');
assert(calculatedTikka.allergens.includes('MUSTARD'), 'Recipe must detect MUSTARD allergen from mustard oil');

// 3. Test Non-Veg / Vegan / Allergen flags on High-Protein Vegan Soya Bowl
console.log('\n--- 3. Testing Vegan High-Protein Soya Bowl ---');
// Recipe: Soya Chunks 80g, Spinach 100g, Olive Oil 10g
const soyaBowlRecipe = [
  { ingredientKey: 'soya_chunks', quantityGrams: 80 },
  { ingredientKey: 'spinach_palak', quantityGrams: 100 },
  { ingredientKey: 'olive_oil', quantityGrams: 10 },
];

const calculatedSoya = calculateRecipeNutrition(soyaBowlRecipe);
assert(calculatedSoya.isVegan === true, 'Soya bowl must be 100% vegan');
assert(calculatedSoya.isVegetarian === true, 'Soya bowl must be vegetarian');
assert(calculatedSoya.protein >= 43 && calculatedSoya.protein <= 46, `Soya bowl protein should be ~44.5g, got ${calculatedSoya.protein}g`);
assert(calculatedSoya.allergens.includes('SOY'), 'Soya bowl must detect SOY allergen');

// 4. Test Jain-Friendly Validation
console.log('\n--- 4. Testing Jain-Friendly Rule Validation ---');
const jainMoongKhichdi = [
  { ingredientKey: 'moong_dal', quantityGrams: 100 },
  { ingredientKey: 'basmati_rice', quantityGrams: 100 },
  { ingredientKey: 'desi_ghee', quantityGrams: 10 },
];
const calculatedJainKhichdi = calculateRecipeNutrition(jainMoongKhichdi);
assert(calculatedJainKhichdi.isJainFriendly === true, 'Moong dal + rice + ghee must be Jain friendly (no root vegetables)');

const nonJainWithOnion = [
  { ingredientKey: 'moong_dal', quantityGrams: 100 },
  { ingredientKey: 'onion', quantityGrams: 50 },
];
const calculatedNonJain = calculateRecipeNutrition(nonJainWithOnion);
assert(calculatedNonJain.isJainFriendly === false, 'Recipe containing onion must NOT be Jain friendly');

console.log('\n======================================================');
console.log('🎉 ALL INGREDIENT NUTRITION CALCULATOR TESTS PASSED! 🎉');
console.log('======================================================\n');
