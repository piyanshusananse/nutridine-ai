'use client';

import { DishModal } from '@/components/DishModal';
import { FoodPrepAnimationModal } from '@/components/FoodPrepAnimationModal';
import { ScoreRing } from '@/components/ui/ScoreRing';
import { WhatShouldIEatModal } from '@/components/WhatShouldIEatModal';
import { useUser } from '@/context/UserContext';
import { evaluateDishRecommendation } from '@/lib/engine/scoring';
import { MenuItemData } from '@/lib/engine/types';
import {
  Activity,
  Award,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Droplets,
  Flame,
  Footprints,
  Heart,
  Layers,
  Plus,
  Scale,
  Search,
  Sparkles,
  TrendingUp,
  User,
  Utensils,
  UtensilsCrossed,
  Zap,
} from 'lucide-react';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

export default function DashboardPage() {
  const { activePersona, userProfile, bmi, energyNeeds, selectedDishForModal, openDishModal, closeDishModal, showToast } =
    useUser();

  const [topDishes, setTopDishes] = useState<MenuItemData[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [todaySummary, setTodaySummary] = useState<any>({ calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 });
  const [isLoggingModalOpen, setIsLoggingModalOpen] = useState(false);
  const [isWhatToEatOpen, setIsWhatToEatOpen] = useState(false);
  const [activePrepDish, setActivePrepDish] = useState<MenuItemData | null>(null);

  // Quick Log Form State
  const [logWeight, setLogWeight] = useState(userProfile.weightKg.toString());
  const [logCalories, setLogCalories] = useState('1850');
  const [logProtein, setLogProtein] = useState('140');
  const [logWater, setLogWater] = useState('2800');
  const [logSteps, setLogSteps] = useState('9200');

  useEffect(() => {
    async function loadData() {
      try {
        // Load top recommended dishes from all restaurants
        const res = await fetch('/api/restaurants');
        const data = await res.json();
        if (data.success && data.restaurants.length > 0) {
          const allItems: MenuItemData[] = [];
          for (const rest of data.restaurants.slice(0, 5)) {
            const restDetail = await fetch(`/api/restaurants/${rest.id}?userId=${activePersona.id}`);
            const restJson = await restDetail.json();
            if (restJson.success) {
              allItems.push(...restJson.restaurant.menuItems);
            }
          }
          // Sort by personalized score
          const ranked = allItems
            .map((item) => ({ item, rec: evaluateDishRecommendation(item, userProfile) }))
            .filter((entry) => !entry.rec.hasAllergenConflict && !entry.rec.hasDietaryConflict)
            .sort((a, b) => b.rec.score - a.rec.score)
            .slice(0, 6)
            .map((e) => e.item);

          setTopDishes(ranked);
        }

        // Load today's food log
        const foodLogRes = await fetch(`/api/food-log?userId=${activePersona.id}`);
        const foodLogData = await foodLogRes.json();
        if (foodLogData.success) {
          setTodaySummary(foodLogData.summary);
        }

        // Load wellness logs
        const logRes = await fetch(`/api/logs?userId=${activePersona.id}`);
        const logData = await logRes.json();
        if (logData.success && logData.logs) {
          setLogs(logData.logs);
        }
      } catch (err) {
        console.error(err);
      }
    }
    loadData();
  }, [activePersona.id, userProfile]);

  const handleSaveLog = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        userId: userProfile.id || activePersona.id,
        date: new Date().toISOString().split('T')[0],
        weightKg: parseFloat(logWeight),
        caloriesConsumed: parseInt(logCalories, 10),
        proteinGrams: parseFloat(logProtein),
        waterMl: parseInt(logWater, 10),
        steps: parseInt(logSteps, 10),
      };

      const res = await fetch('/api/logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success) {
        setLogs((prev) => {
          const filtered = prev.filter((l) => l.date !== data.log.date);
          return [...filtered, data.log].sort((a, b) => a.date.localeCompare(b.date));
        });
        showToast('Daily wellness metrics logged!');
        setIsLoggingModalOpen(false);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const trendData =
    logs.length > 0
      ? logs.map((l) => ({
          date: l.date.slice(5),
          weight: l.weightKg || userProfile.weightKg,
          calories: l.caloriesConsumed || energyNeeds.targetCalories,
          targetCalories: energyNeeds.targetCalories,
          protein: l.proteinGrams || energyNeeds.proteinRangeMin,
        }))
      : [
          { date: '08-25', weight: 83.2, calories: 2100, targetCalories: energyNeeds.targetCalories, protein: 135 },
          { date: '08-26', weight: 82.8, calories: 1950, targetCalories: energyNeeds.targetCalories, protein: 142 },
          { date: '08-27', weight: 82.5, calories: 1880, targetCalories: energyNeeds.targetCalories, protein: 150 },
          { date: '08-28', weight: 82.2, calories: 2020, targetCalories: energyNeeds.targetCalories, protein: 148 },
          { date: '08-29', weight: 82.0, calories: 1850, targetCalories: energyNeeds.targetCalories, protein: 152 },
        ];

  // Remaining calories and protein
  const remainingCalories = Math.max(0, energyNeeds.targetCalories - todaySummary.calories);
  const targetProteinAvg = Math.round((energyNeeds.proteinRangeMin + energyNeeds.proteinRangeMax) / 2);
  const remainingProtein = Math.max(0, targetProteinAvg - todaySummary.protein);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Profile Greeting */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 text-xs font-bold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Active Goal: {userProfile.goal.replace(/_/g, ' ')}</span>
          </div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <span>Good day, {userProfile.name}!</span>
            <span className="text-2xl">{activePersona.avatar}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Your personalized food intelligence & nutrition dashboard.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsWhatToEatOpen(true)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white text-xs font-black shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>What should I eat now?</span>
          </button>

          <Link
            href="/tracker"
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-white text-xs font-bold shadow-sm hover:bg-slate-50 transition-all"
          >
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>Today&apos;s Tracker</span>
          </Link>
        </div>
      </div>

      {/* QUICK ACTIONS BAR */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <button
          onClick={() => setIsWhatToEatOpen(true)}
          className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-left space-y-1 hover:scale-102 transition-all cursor-pointer shadow-sm"
        >
          <span className="text-2xl">🍽️</span>
          <div className="font-extrabold text-xs text-slate-900 dark:text-white">What to Eat?</div>
          <p className="text-[10px] text-slate-500">Deficit recommendations</p>
        </button>

        <Link
          href="/restaurants"
          className="p-4 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-left space-y-1 hover:scale-102 transition-all shadow-sm"
        >
          <span className="text-2xl">🔍</span>
          <div className="font-extrabold text-xs text-slate-900 dark:text-white">Discover Food</div>
          <p className="text-[10px] text-slate-500">10+ restaurants</p>
        </Link>

        <Link
          href="/compare"
          className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 text-left space-y-1 hover:scale-102 transition-all shadow-sm"
        >
          <span className="text-2xl">⚖️</span>
          <div className="font-extrabold text-xs text-slate-900 dark:text-white">Compare Foods</div>
          <p className="text-[10px] text-slate-500">Side-by-side matrix</p>
        </Link>

        <Link
          href="/tracker"
          className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-left space-y-1 hover:scale-102 transition-all shadow-sm"
        >
          <span className="text-2xl">📊</span>
          <div className="font-extrabold text-xs text-slate-900 dark:text-white">Today&apos;s Tracker</div>
          <p className="text-[10px] text-slate-500">Log meals & macros</p>
        </Link>

        <Link
          href="/meal-builder"
          className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-left space-y-1 hover:scale-102 transition-all shadow-sm col-span-2 sm:col-span-1"
        >
          <span className="text-2xl">🍱</span>
          <div className="font-extrabold text-xs text-slate-900 dark:text-white">Meal Builder</div>
          <p className="text-[10px] text-slate-500">Multi-course combos</p>
        </Link>
      </div>

      {/* 1. USER WELLNESS SNAPSHOT CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* BMI Card */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Body Mass Index</span>
            <Scale className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">{bmi.bmi}</span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">{bmi.category}</span>
          </div>
          <div className="text-[10px] text-slate-400">
            {userProfile.weightKg} kg • {userProfile.heightCm} cm
          </div>
        </div>

        {/* Daily Target Calories Card */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Daily Calorie Target</span>
            <Flame className="w-4 h-4 text-orange-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {energyNeeds.targetCalories}
            </span>
            <span className="text-xs font-medium text-slate-400">kcal/day</span>
          </div>
          <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
            {remainingCalories} kcal remaining today
          </div>
        </div>

        {/* Protein Target Card */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Daily Protein Target</span>
            <Zap className="w-4 h-4 text-sky-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {energyNeeds.proteinRangeMin}–{energyNeeds.proteinRangeMax}
            </span>
            <span className="text-xs font-medium text-slate-400">g/day</span>
          </div>
          <div className="text-[10px] text-sky-600 dark:text-sky-400 font-semibold">
            {remainingProtein}g needed today
          </div>
        </div>

        {/* Hydration / Steps Card */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-black uppercase tracking-wider">Daily Hydration</span>
            <Droplets className="w-4 h-4 text-cyan-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {energyNeeds.waterTargetLiters}
            </span>
            <span className="text-xs font-medium text-slate-400">Liters</span>
          </div>
          <div className="text-[10px] text-slate-400">
            Target Steps: {userProfile.healthMarkers?.dailySteps || 8000} / day
          </div>
        </div>
      </div>

      {/* 2. TODAY'S TOP RECOMMENDATIONS */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-600" />
              <span>Today&apos;s Recommended Dishes For You</span>
            </h2>
            <p className="text-xs text-slate-500">
              Top scoring restaurant dishes curated for your {userProfile.goal.replace(/_/g, ' ').toLowerCase()} goal.
            </p>
          </div>
          <Link
            href="/restaurants"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline"
          >
            <span>Explore all menus</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {topDishes.map((dish) => {
            const rec = evaluateDishRecommendation(dish, userProfile);
            return (
              <div
                key={dish.id}
                onClick={() => openDishModal(dish)}
                className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={dish.imageUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80'}
                    alt={dish.name}
                    className="w-14 h-14 rounded-2xl object-cover"
                  />
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors line-clamp-1">
                      {dish.name}
                    </h4>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      ₹{Math.round(dish.price)} • {dish.calories} kcal • {dish.protein}g Protein
                    </div>
                    <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-0.5">
                      {rec.categoryLabel}
                    </div>
                  </div>
                </div>

                <div className="shrink-0">
                  <ScoreRing score={rec.score} size={44} strokeWidth={4} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. PROGRESS TREND CHARTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Calorie & Weight Trend */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
                <span>Calorie Intake vs Target Trend</span>
              </h3>
              <p className="text-xs text-slate-500">Daily intake tracked against estimated goal budget ({energyNeeds.targetCalories} kcal)</p>
            </div>
            <button
              onClick={() => setIsLoggingModalOpen(true)}
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
            >
              + Quick Log
            </button>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="calColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderRadius: '12px',
                    color: '#fff',
                    border: 'none',
                  }}
                />
                <Area type="monotone" dataKey="calories" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#calColor)" name="Calories" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Action Callout Box */}
        <div className="lg:col-span-4 bg-gradient-to-br from-slate-900 to-emerald-950 text-white p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xl">
              🍱
            </div>
            <h3 className="text-xl font-black">Build a Balanced Meal Combo</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Planning your dinner out? Assemble a multi-course dinner combo from your favorite restaurant that automatically fits your macro targets.
            </p>
          </div>

          <Link
            href="/meal-builder"
            className="flex items-center justify-center gap-2 w-full py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-all shadow"
          >
            <span>Launch Smart Meal Builder</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* QUICK LOGGING MODAL */}
      {isLoggingModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5">
            <h3 className="text-lg font-black text-slate-900 dark:text-white">Quick Log Today&apos;s Metrics</h3>

            <form onSubmit={handleSaveLog} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Weight (kg)</label>
                <input
                  type="number"
                  step="0.1"
                  value={logWeight}
                  onChange={(e) => setLogWeight(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Calories Consumed (kcal)</label>
                <input
                  type="number"
                  value={logCalories}
                  onChange={(e) => setLogCalories(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Protein (grams)</label>
                <input
                  type="number"
                  value={logProtein}
                  onChange={(e) => setLogProtein(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Water Intake (ml)</label>
                <input
                  type="number"
                  value={logWater}
                  onChange={(e) => setLogWater(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Daily Steps</label>
                <input
                  type="number"
                  value={logSteps}
                  onChange={(e) => setLogSteps(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsLoggingModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow"
                >
                  Save Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Global Dish Modal */}
      {selectedDishForModal && (
        <DishModal
          dish={selectedDishForModal}
          restaurantMenu={topDishes}
          onClose={closeDishModal}
        />
      )}

      {/* Smart What Should I Eat Modal */}
      <WhatShouldIEatModal
        isOpen={isWhatToEatOpen}
        onClose={() => setIsWhatToEatOpen(false)}
        onSelectOrderDish={(dish) => setActivePrepDish(dish)}
      />

      {/* Food Prep Animation Modal */}
      {activePrepDish && (
        <FoodPrepAnimationModal
          dish={activePrepDish}
          restaurantName={(activePrepDish as any).restaurantName || 'Kitchen'}
          onClose={() => setActivePrepDish(null)}
        />
      )}
    </div>
  );
}
