'use client';

import { AIChatDrawer } from '@/components/AIChatDrawer';
import { DishCard } from '@/components/DishCard';
import { DishModal } from '@/components/DishModal';
import { useUser } from '@/context/UserContext';
import { MenuItemData, RecommendationResult, SmartSwapRecommendation } from '@/lib/engine/types';
import {
  AlertCircle,
  ArrowLeft,
  ChevronDown,
  Filter,
  Flame,
  Layers,
  MapPin,
  Search,
  SlidersHorizontal,
  Sparkles,
  Star,
  UtensilsCrossed,
} from 'lucide-react';
import Link from 'next/link';
import React, { useEffect, use, useState } from 'react';

interface FullRestaurantData {
  id: string;
  name: string;
  slug: string;
  description: string;
  address: string;
  city: string;
  cuisineTypes: string;
  priceRange: number;
  rating: number;
  reviewCount: number;
  bannerUrl?: string;
  categories: { id: string; name: string; sortOrder: number }[];
  menuItems: (MenuItemData & {
    recommendation: RecommendationResult;
    smartSwap?: SmartSwapRecommendation | null;
  })[];
}

export default function RestaurantDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  const { activePersona, selectedDishForModal, openDishModal, closeDishModal } = useUser();

  const [restaurantData, setRestaurantData] = useState<FullRestaurantData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Filter & tab state
  const [activeTab, setActiveTab] = useState<'RECOMMENDED' | 'GOAL_FIT' | 'HIGH_PROTEIN' | 'LIGHT' | 'ALL'>('RECOMMENDED');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [vegetarianOnly, setVegetarianOnly] = useState(false);
  const [glutenFreeOnly, setGlutenFreeOnly] = useState(false);
  const [maxCalorieFilter, setMaxCalorieFilter] = useState<number>(1000);

  useEffect(() => {
    async function loadRestaurant() {
      setIsLoading(true);
      try {
        const res = await fetch(
          `/api/restaurants/${resolvedParams.id}?userId=${activePersona.id || 'user-alex'}`
        );
        const data = await res.json();
        if (data.success) {
          setRestaurantData(data.restaurant);
        }
      } catch (err) {
        console.error('Failed to load restaurant:', err);
      } finally {
        setIsLoading(false);
      }
    }

    loadRestaurant();
  }, [resolvedParams.id, activePersona.id, activePersona.profile]);

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <div className="h-64 rounded-3xl bg-slate-200 dark:bg-slate-800 animate-pulse" />
        <div className="h-12 w-full max-w-md bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-80 rounded-2xl bg-slate-200 dark:bg-slate-800 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (!restaurantData) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-4">
        <UtensilsCrossed className="w-12 h-12 text-slate-400 mx-auto" />
        <h2 className="text-xl font-bold">Restaurant Not Found</h2>
        <Link href="/restaurants" className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold inline-block">
          Return to Restaurants
        </Link>
      </div>
    );
  }

  // Filter and sort items based on activeTab and filters
  let displayedItems = [...restaurantData.menuItems];

  // Apply tab criteria
  if (activeTab === 'RECOMMENDED') {
    displayedItems.sort((a, b) => b.recommendation.score - a.recommendation.score);
  } else if (activeTab === 'GOAL_FIT') {
    displayedItems = displayedItems
      .filter((i) => i.recommendation.category === 'BEST_CHOICE' || i.recommendation.category === 'GOOD_CHOICE')
      .sort((a, b) => b.recommendation.score - a.recommendation.score);
  } else if (activeTab === 'HIGH_PROTEIN') {
    displayedItems.sort((a, b) => b.protein - a.protein);
  } else if (activeTab === 'LIGHT') {
    displayedItems = displayedItems.filter((i) => i.calories <= 450).sort((a, b) => a.calories - b.calories);
  }

  // Category filter
  if (selectedCategory !== 'ALL') {
    displayedItems = displayedItems.filter((i) => i.categoryId === selectedCategory);
  }

  // Dietary filters
  if (vegetarianOnly) {
    displayedItems = displayedItems.filter((i) => i.isVegetarian || i.isVegan);
  }
  if (glutenFreeOnly) {
    displayedItems = displayedItems.filter((i) => i.isGlutenFree);
  }

  // Calorie slider
  if (maxCalorieFilter < 1000) {
    displayedItems = displayedItems.filter((i) => i.calories <= maxCalorieFilter);
  }

  // Search filter
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    displayedItems = displayedItems.filter(
      (i) =>
        i.name.toLowerCase().includes(q) ||
        i.description.toLowerCase().includes(q) ||
        i.ingredients.toLowerCase().includes(q)
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Back button */}
      <Link
        href="/restaurants"
        className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to all restaurants</span>
      </Link>

      {/* Restaurant Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white shadow-2xl border border-slate-800">
        <div className="relative h-64 sm:h-72 w-full">
          <img
            src={
              restaurantData.bannerUrl ||
              'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&auto=format&fit=crop&q=80'
            }
            alt={restaurantData.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-black/30" />

          {/* Top Info Tag */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-black shadow backdrop-blur-sm">
                Verified Menu
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-amber-300 text-xs font-black">
                <Star className="w-3.5 h-3.5 fill-amber-300" /> {restaurantData.rating} ({restaurantData.reviewCount})
              </span>
            </div>
          </div>

          {/* Bottom Title & Details */}
          <div className="absolute bottom-5 left-5 right-5 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
            <div className="space-y-1">
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight">{restaurantData.name}</h1>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                <span className="flex items-center gap-1 text-emerald-400">
                  <MapPin className="w-3.5 h-3.5" /> {restaurantData.address}, {restaurantData.city}
                </span>
                <span>•</span>
                <span className="text-emerald-300 font-bold">{'₹'.repeat(restaurantData.priceRange)}</span>
                <span>•</span>
                <span>{restaurantData.cuisineTypes}</span>
              </div>
            </div>

            {/* Active Persona Banner in header */}
            <div className="px-4 py-2 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 backdrop-blur-md flex items-center gap-2.5">
              <span className="text-xl">{activePersona.avatar}</span>
              <div className="text-left">
                <div className="text-[10px] uppercase font-black text-emerald-400">Personalized Menu For</div>
                <div className="text-xs font-extrabold text-white">
                  {activePersona.name} ({activePersona.profile.goal.replace(/_/g, ' ')})
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs & Filter Bar */}
      <div className="space-y-4">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800 scrollbar-none">
          {[
            { id: 'RECOMMENDED', label: '⭐ Recommended For You', icon: Sparkles },
            { id: 'GOAL_FIT', label: '🎯 Fits Your Goal', icon: Sparkles },
            { id: 'HIGH_PROTEIN', label: '🥩 High Protein', icon: Flame },
            { id: 'LIGHT', label: '🥗 Light Options (<450 kcal)', icon: UtensilsCrossed },
            { id: 'ALL', label: '📖 Full Menu', icon: Layers },
          ].map((tab) => {
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Search & Category Filter Sub-bar */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          {/* Search */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dishes or ingredients..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white"
            />
          </div>

          {/* Category Dropdown */}
          <div className="sm:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white"
            >
              <option value="ALL">All Categories</option>
              {restaurantData.categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Dietary Toggles */}
          <div className="sm:col-span-3 flex items-center gap-2">
            <button
              onClick={() => setVegetarianOnly(!vegetarianOnly)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                vegetarianOnly
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
              }`}
            >
              🌱 Veg
            </button>
            <button
              onClick={() => setGlutenFreeOnly(!glutenFreeOnly)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                glutenFreeOnly
                  ? 'bg-sky-600 text-white border-sky-600 shadow'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
              }`}
            >
              🌾 GF
            </button>
          </div>
        </div>
      </div>

      {/* Menu Dish Cards Grid */}
      {displayedItems.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <UtensilsCrossed className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">No Dishes Match Filters</h3>
          <p className="text-xs text-slate-500">Try clearing the search term or dietary checkboxes.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('ALL');
              setVegetarianOnly(false);
              setGlutenFreeOnly(false);
            }}
            className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedItems.map((dish) => (
            <DishCard
              key={dish.id}
              dish={dish}
              recommendation={dish.recommendation}
              smartSwap={dish.smartSwap}
              onSelect={() => openDishModal(dish)}
            />
          ))}
        </div>
      )}

      {/* Dish Modal */}
      {selectedDishForModal && (
        <DishModal
          dish={selectedDishForModal}
          restaurantMenu={restaurantData.menuItems}
          onClose={closeDishModal}
        />
      )}

      {/* Floating AI Chat Assistant */}
      <AIChatDrawer
        restaurantId={restaurantData.id}
        restaurantName={restaurantData.name}
        menuItems={restaurantData.menuItems}
      />
    </div>
  );
}
