'use client';

import { FoodPrepAnimationModal } from '@/components/FoodPrepAnimationModal';
import { MacroBar } from '@/components/ui/MacroBar';
import { ScoreRing } from '@/components/ui/ScoreRing';
import { useUser } from '@/context/UserContext';
import { evaluateDishRecommendation } from '@/lib/engine/scoring';
import { findSmartSwaps } from '@/lib/engine/smart-swaps';
import { MenuItemData } from '@/lib/engine/types';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  ChefHat,
  Flame,
  Info,
  Layers,
  Scale,
  ShieldAlert,
  Sparkles,
  Utensils,
  X,
} from 'lucide-react';
import React, { useState } from 'react';

interface DishModalProps {
  dish: MenuItemData | null;
  restaurantMenu?: MenuItemData[];
  onClose: () => void;
}

export function DishModal({ dish, restaurantMenu = [], onClose }: DishModalProps) {
  const { userProfile, activePersona, addToComparison, openDishModal, showToast } = useUser();
  const [isPrepModalOpen, setIsPrepModalOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK'>('LUNCH');

  if (!dish) return null;

  const recommendation = evaluateDishRecommendation(dish, userProfile);
  const smartSwap = findSmartSwaps(dish, restaurantMenu, userProfile);

  const handleLogMeal = async () => {
    try {
      const res = await fetch('/api/food-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activePersona.id,
          menuItemId: dish.id,
          dishName: dish.name,
          restaurantName: (dish as any).restaurantName || 'Restaurant Dish',
          mealType: selectedSlot,
          calories: dish.calories,
          protein: dish.protein,
          carbs: dish.carbohydrates,
          fat: dish.fat,
          fiber: dish.fiber,
          sodium: dish.sodium,
          sugar: dish.sugar,
          quantity: 1,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Logged "${dish.name}" to today's ${selectedSlot.toLowerCase()}!`);
        onClose();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
        <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
          {/* Header with image */}
          <div className="relative h-60 w-full bg-slate-800 overflow-hidden shrink-0">
            {dish.imageUrl ? (
              <img src={dish.imageUrl} alt={dish.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-6xl">🍲</div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md transition-colors cursor-pointer z-10"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Top category & tags */}
            <div className="absolute top-4 left-4 flex flex-wrap gap-2 z-10">
              {dish.categoryName && (
                <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-bold">
                  {dish.categoryName}
                </span>
              )}
              {dish.isVegetarian && (
                <span className="px-3 py-1 rounded-full bg-emerald-600/90 backdrop-blur-md text-white text-xs font-bold">
                  🌱 Vegetarian
                </span>
              )}
              {dish.isVegan && (
                <span className="px-3 py-1 rounded-full bg-green-600/90 backdrop-blur-md text-white text-xs font-bold">
                  🌿 Vegan
                </span>
              )}
              {dish.isGlutenFree && (
                <span className="px-3 py-1 rounded-full bg-sky-600/90 backdrop-blur-md text-white text-xs font-bold">
                  🌾 Gluten-Free
                </span>
              )}
            </div>

            {/* Bottom Title & Price */}
            <div className="absolute bottom-4 left-5 right-5 text-white flex items-end justify-between">
              <div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight drop-shadow-md">{dish.name}</h2>
                <p className="text-xs text-slate-300 mt-0.5">
                  Serving: {dish.servingSize} • Prep: {dish.preparationMethod || 'Standard'}
                </p>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black text-emerald-400">₹{Math.round(dish.price)}</span>
              </div>
            </div>
          </div>

          {/* Scrollable Content Body */}
          <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
            {/* Allergen Warning Banner if present */}
            {recommendation.hasAllergenConflict && (
              <div className="bg-rose-50 dark:bg-rose-950/60 border-2 border-rose-300 dark:border-rose-800 rounded-2xl p-4 flex items-start gap-3 text-rose-900 dark:text-rose-200">
                <ShieldAlert className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-sm">CRITICAL ALLERGEN WARNING</h4>
                  <p className="text-xs mt-0.5 leading-relaxed">{recommendation.allergenWarning}</p>
                  <p className="text-[11px] text-rose-700 dark:text-rose-300 font-semibold mt-1">
                    ⚠️ Ingredient/allergen information should be confirmed with the restaurant before ordering.
                  </p>
                </div>
              </div>
            )}

            {/* Recommendation Match Card */}
            <div className="bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-slate-50 dark:from-emerald-950/40 dark:via-teal-950/20 dark:to-slate-900 rounded-3xl p-5 border border-emerald-500/20 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <ScoreRing score={recommendation.score} size={64} strokeWidth={5} />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                        Personalized Match Score
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-600 text-white">
                        {recommendation.categoryLabel}
                      </span>
                    </div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                      {userProfile.name}&apos;s Match: {recommendation.score}/100
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Evaluated for your <strong className="text-slate-900 dark:text-white">{userProfile.goal.replace(/_/g, ' ').toLowerCase()}</strong> goal
                    </p>
                  </div>
                </div>
              </div>

              {/* Why this recommendation list */}
              <div className="space-y-2 pt-2 border-t border-emerald-500/10">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  Why this is recommended for you:
                </h4>
                <ul className="space-y-1.5">
                  {recommendation.detailedExplanation.map((point, idx) => (
                    <li key={idx} className="text-xs text-slate-700 dark:text-slate-300 flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Transparent Score Sub-breakdowns */}
              <div className="pt-3 border-t border-emerald-500/10 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Transparent Score Factors:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Goal Alignment</span>
                    <span className="font-extrabold text-emerald-600">
                      {recommendation.scoreBreakdown.goalAlignment.score}/{recommendation.scoreBreakdown.goalAlignment.max}
                    </span>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Protein Suitability</span>
                    <span className="font-extrabold text-emerald-600">
                      {recommendation.scoreBreakdown.proteinSuitability.score}/{recommendation.scoreBreakdown.proteinSuitability.max}
                    </span>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Calorie Suitability</span>
                    <span className="font-extrabold text-emerald-600">
                      {recommendation.scoreBreakdown.calorieSuitability.score}/{recommendation.scoreBreakdown.calorieSuitability.max}
                    </span>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center justify-between">
                    <span className="text-slate-600 dark:text-slate-300">Taste & Dietary Fit</span>
                    <span className="font-extrabold text-emerald-600">
                      {recommendation.scoreBreakdown.dietaryCompatibility.score}/{recommendation.scoreBreakdown.dietaryCompatibility.max}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Smart Substitutions / "Make It Better" */}
            {recommendation.suggestedModifications && recommendation.suggestedModifications.length > 0 && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                  <ChefHat className="w-4 h-4" />
                  Smart Substitutions & Customizations:
                </h4>
                <ul className="space-y-1">
                  {recommendation.suggestedModifications.map((mod, idx) => (
                    <li key={idx} className="text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
                      <span className="font-bold">•</span>
                      <span>{mod}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Smart Swap Alternative from same restaurant */}
            {smartSwap && smartSwap.betterDish.id !== dish.id && (
              <div className="bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-sky-600 dark:text-sky-400">
                    Smart Swap Alternative
                  </span>
                  <h5 className="font-bold text-sm text-slate-900 dark:text-white mt-0.5">{smartSwap.betterDish.name}</h5>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">{smartSwap.reason}</p>
                </div>
                <button
                  onClick={() => openDishModal(smartSwap.betterDish)}
                  className="px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold flex items-center gap-1 shrink-0 transition-all cursor-pointer shadow"
                >
                  <span>View Swap</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Complete Nutritional Facts */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">
                  Nutritional Breakdown
                </h4>
                <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  Data: {dish.nutritionSource.replace(/_/g, ' ')}
                </span>
              </div>

              <MacroBar
                protein={dish.protein}
                carbs={dish.carbohydrates}
                fat={dish.fat}
                calories={dish.calories}
              />

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Dietary Fiber</span>
                  <span className="font-extrabold text-slate-900 dark:text-white text-sm">{dish.fiber}g</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Sugar</span>
                  <span className="font-extrabold text-slate-900 dark:text-white text-sm">{dish.sugar}g</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Sodium</span>
                  <span className="font-extrabold text-slate-900 dark:text-white text-sm">{dish.sodium}mg</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Saturated Fat</span>
                  <span className="font-extrabold text-slate-900 dark:text-white text-sm">{dish.saturatedFat}g</span>
                </div>
              </div>
            </div>

            {/* Ingredients and Allergens */}
            <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block mb-1">Ingredients:</span>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl">
                  {dish.ingredients || 'Standard kitchen recipe.'}
                </p>
              </div>
              {dish.allergens && (
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block mb-1">Declared Allergens:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {dish.allergens.split(',').map((allergen, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 font-bold text-[11px]"
                      >
                        ⚠️ {allergen.trim()}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <button
                onClick={() => addToComparison(dish)}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer shadow-sm transition-all"
              >
                <Scale className="w-4 h-4 text-sky-600" />
                <span>Compare</span>
              </button>

              <button
                onClick={() => setIsPrepModalOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold cursor-pointer shadow transition-all"
              >
                <ChefHat className="w-4 h-4" />
                <span>Order & Track Prep</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedSlot}
                onChange={(e) => setSelectedSlot(e.target.value as any)}
                className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold dark:text-white cursor-pointer"
              >
                <option value="BREAKFAST">🌅 Breakfast</option>
                <option value="LUNCH">☀️ Lunch</option>
                <option value="DINNER">🌙 Dinner</option>
                <option value="SNACK">🍎 Snack</option>
              </select>

              <button
                onClick={handleLogMeal}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black cursor-pointer shadow-lg shadow-emerald-600/20 transition-all"
              >
                <Utensils className="w-4 h-4" />
                <span>Add to Tracker</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Food Prep Animation Modal */}
      {isPrepModalOpen && (
        <FoodPrepAnimationModal
          dish={dish}
          restaurantName={(dish as any).restaurantName || 'Kitchen'}
          onClose={() => setIsPrepModalOpen(false)}
        />
      )}
    </>
  );
}
