import { evaluateHardConstraints } from '../engine/hard-constraints';
import { evaluateDishRecommendation } from '../engine/scoring';
import { MenuItemData, UserProfileData } from '../engine/types';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface AIChatResponse {
  answer: string;
  recommendedDishes: MenuItemData[];
  quickPrompts?: string[];
}

/**
 * Intelligent restaurant menu-grounded conversational assistant.
 * Strictly guarantees recommendations are real dishes from the currently selected restaurant.
 */
export async function generateMenuChatResponse(
  userQuery: string,
  restaurantName: string,
  menuItems: MenuItemData[],
  profile: UserProfileData,
  chatHistory: ChatMessage[] = []
): Promise<AIChatResponse> {
  const queryLower = userQuery.toLowerCase();

  // Filter safe items
  const safeItems = menuItems.filter((dish) => {
    const check = evaluateHardConstraints(dish, profile);
    return !check.isExcluded && dish.isAvailable;
  });

  const scoredItems = safeItems
    .map((dish) => ({
      dish,
      rec: evaluateDishRecommendation(dish, profile),
    }))
    .sort((a, b) => b.rec.score - a.rec.score);

  // 1. Check for specific intent patterns
  const isHighProtein =
    queryLower.includes('high protein') ||
    queryLower.includes('protein') ||
    queryLower.includes('muscle') ||
    queryLower.includes('max protein');

  const isLowCalorie =
    queryLower.includes('under 500') ||
    queryLower.includes('under 600') ||
    queryLower.includes('under 700') ||
    queryLower.includes('low calorie') ||
    queryLower.includes('light') ||
    queryLower.includes('lose weight') ||
    queryLower.includes('weight loss');

  const isVegetarianOnly =
    queryLower.includes('veg') ||
    queryLower.includes('vegetarian') ||
    queryLower.includes('paneer') ||
    queryLower.includes('tofu') ||
    queryLower.includes('plant based');

  const isDessertOrSweet =
    queryLower.includes('dessert') ||
    queryLower.includes('sweet') ||
    queryLower.includes('treat') ||
    queryLower.includes('sugar');

  const isCompare =
    queryLower.includes('compare') ||
    queryLower.includes('vs') ||
    queryLower.includes('difference between');

  // Specific calorie threshold extraction e.g. "under 600"
  const calorieMatch = queryLower.match(/under\s+(\d+)/);
  const calorieLimit = calorieMatch ? parseInt(calorieMatch[1], 10) : null;

  let candidates = [...scoredItems];

  if (isVegetarianOnly) {
    candidates = candidates.filter((c) => c.dish.isVegetarian || c.dish.isVegan);
  }

  if (calorieLimit) {
    candidates = candidates.filter((c) => c.dish.calories <= calorieLimit);
  } else if (isLowCalorie) {
    candidates = candidates.filter((c) => c.dish.calories <= 550);
  }

  if (isHighProtein) {
    candidates.sort((a, b) => b.dish.protein - a.dish.protein);
  }

  if (isDessertOrSweet) {
    const desserts = menuItems.filter(
      (m) =>
        (m.categoryName || '').toLowerCase().includes('dessert') ||
        m.name.toLowerCase().includes('jamun') ||
        m.name.toLowerCase().includes('cake') ||
        m.name.toLowerCase().includes('parfait')
    );
    if (desserts.length > 0) {
      const bestDessert = desserts[0];
      return {
        answer: `If you're craving something sweet at **${restaurantName}**, **${bestDessert.name}** (${bestDessert.calories} kcal, ${bestDessert.sugar}g sugar) is available. You can pair it with a light high-protein main to keep your overall meal balanced!`,
        recommendedDishes: [bestDessert],
        quickPrompts: ['Show best high-protein dishes', 'What is under 600 calories?', 'Build a balanced meal'],
      };
    }
  }

  // Handle dish comparison query
  if (isCompare) {
    const mentionedDishes = menuItems.filter((dish) =>
      queryLower.includes(dish.name.toLowerCase().slice(0, 5))
    );
    if (mentionedDishes.length >= 2) {
      const d1 = mentionedDishes[0];
      const d2 = mentionedDishes[1];
      const r1 = evaluateDishRecommendation(d1, profile);
      const r2 = evaluateDishRecommendation(d2, profile);
      const winner = r1.score >= r2.score ? d1 : d2;
      const loser = winner.id === d1.id ? d2 : d1;
      const winnerRec = winner.id === d1.id ? r1 : r2;

      return {
        answer: `Comparing **${d1.name}** and **${d2.name}** for your ${profile.goal.replace(/_/g, ' ').toLowerCase()} goal:\n\n` +
          `• **${winner.name}** (${winner.calories} kcal, ${winner.protein}g protein) scores **${winnerRec.score}/100**.\n` +
          `• **${loser.name}** (${loser.calories} kcal, ${loser.protein}g protein).\n\n` +
          `**Verdict:** **${winner.name}** is the stronger match for your profile because it offers a better protein-to-calorie density.`,
        recommendedDishes: [winner, loser],
        quickPrompts: ['Show me smart swaps', 'Build a complete dinner', 'What else is high protein?'],
      };
    }
  }

  const topPicks = candidates.slice(0, 3).map((c) => c.dish);

  if (topPicks.length === 0) {
    const fallbackTop = scoredItems.slice(0, 2).map((c) => c.dish);
    return {
      answer: `I searched the menu of **${restaurantName}**, but didn't find dishes that strictly fit every filter together. However, based on your overall ${profile.goal.replace(
        /_/g,
        ' '
      ).toLowerCase()} goal, here are the highest rated dishes available:`,
      recommendedDishes: fallbackTop,
      quickPrompts: ['High protein options', 'Under 600 calories', 'Vegetarian choices'],
    };
  }

  // Generate structured, conversational response
  const leadDish = topPicks[0];
  const leadRec = evaluateDishRecommendation(leadDish, profile);

  let responseText = `Based on your profile (${profile.goal.replace(/_/g, ' ').toLowerCase()} target) and **${restaurantName}'s** current menu, here are the standout choices:\n\n`;

  topPicks.forEach((dish, idx) => {
    const rec = evaluateDishRecommendation(dish, profile);
    responseText += `${idx + 1}. **${dish.name}** — **${rec.score}% Match**\n`;
    responseText += `   • Nutrition: **${dish.calories} kcal** | **${dish.protein}g Protein** | **${dish.carbohydrates}g Carbs** | **${dish.fat}g Fat**\n`;
    responseText += `   • *Why:* ${rec.headlineReason} ${rec.detailedExplanation[0] || ''}\n\n`;
  });

  if (leadRec.suggestedModifications.length > 0) {
    responseText += `💡 **Pro Tip for ordering:** ${leadRec.suggestedModifications[0]}`;
  }

  return {
    answer: responseText,
    recommendedDishes: topPicks,
    quickPrompts: [
      'What are the lightest side options?',
      'Can you build a 650 kcal dinner?',
      'Compare top 2 dishes',
      'What are the allergen-free items?',
    ],
  };
}
