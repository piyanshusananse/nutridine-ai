import { prisma } from '@/lib/prisma';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get('q') || '';
    const cuisine = searchParams.get('cuisine') || '';
    const city = searchParams.get('city') || '';

    const restaurants = await prisma.restaurant.findMany({
      where: {
        isActive: true,
        AND: [
          query
            ? {
                OR: [
                  { name: { contains: query } },
                  { description: { contains: query } },
                  { cuisineTypes: { contains: query } },
                ],
              }
            : {},
          cuisine ? { cuisineTypes: { contains: cuisine } } : {},
          city ? { city: { contains: city } } : {},
        ],
      },
      include: {
        categories: true,
        _count: {
          select: { menuItems: true },
        },
      },
      orderBy: { rating: 'desc' },
    });

    return NextResponse.json({ success: true, restaurants });
  } catch (error) {
    console.error('Error fetching restaurants:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch restaurants' }, { status: 500 });
  }
}
