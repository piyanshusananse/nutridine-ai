import { AllergenType, DietaryPreferenceType, MenuItemData, UserProfileData } from './types';

export interface HardConstraintResult {
  isExcluded: boolean;
  hasAllergenConflict: boolean;
  hasDietaryConflict: boolean;
  allergenWarning?: string;
  dietaryWarning?: string;
  conflictingAllergens: string[];
  conflictingPreferences: string[];
}

const ALLERGEN_KEYWORD_MAP: Record<AllergenType, string[]> = {
  PEANUTS: ['peanut', 'peanuts', 'groundnut', 'peanut butter', 'peanut oil'],
  TREE_NUTS: ['tree nut', 'walnut', 'almond', 'cashew', 'pistachio', 'hazelnut', 'pecan', 'macadamia', 'pine nut'],
  DAIRY: ['dairy', 'milk', 'cheese', 'butter', 'cream', 'paneer', 'yogurt', 'curd', 'ghee', 'whey', 'lactose', 'casein'],
  EGGS: ['egg', 'eggs', 'egg whites', 'egg yolk', 'mayonnaise', 'albumin'],
  SOY: ['soy', 'soya', 'soy sauce', 'tofu', 'edamame', 'tempeh', 'soybean', 'miso'],
  GLUTEN: ['gluten', 'wheat', 'flour', 'maida', 'atta', 'bread', 'roti', 'naan', 'pasta', 'noodles', 'barley', 'rye', 'couscous'],
  SHELLFISH: ['shellfish', 'prawn', 'prawns', 'shrimp', 'crab', 'lobster', 'clam', 'mussel', 'oyster', 'squid', 'calamari'],
  FISH: ['fish', 'salmon', 'tuna', 'cod', 'tilapia', 'pomfret', 'anchovy', 'trout', 'bass'],
  SESAME: ['sesame', 'til', 'tahini', 'sesame oil', 'sesame seeds'],
  MUSTARD: ['mustard', 'sarson', 'mustard oil', 'mustard seeds'],
  SULFITES: ['sulfite', 'sulfites', 'sulphites', 'wine'],
};

export function evaluateHardConstraints(
  dish: MenuItemData,
  profile: UserProfileData
): HardConstraintResult {
  const result: HardConstraintResult = {
    isExcluded: false,
    hasAllergenConflict: false,
    hasDietaryConflict: false,
    conflictingAllergens: [],
    conflictingPreferences: [],
  };

  const dishAllergensLower = (dish.allergens || '').toLowerCase();
  const dishIngredientsLower = (dish.ingredients || '').toLowerCase();
  const dishNameLower = dish.name.toLowerCase();
  const dishDescLower = dish.description.toLowerCase();
  const fullDishText = `${dishNameLower} ${dishDescLower} ${dishIngredientsLower} ${dishAllergensLower}`;

  // 1. Hard Allergen Evaluation
  if (profile.allergies && profile.allergies.length > 0) {
    for (const allergy of profile.allergies) {
      const allergyUpper = allergy.toUpperCase() as AllergenType;
      const directCodeMatch = dishAllergensLower.includes(allergy.toLowerCase());
      
      const keywords = ALLERGEN_KEYWORD_MAP[allergyUpper] || [allergy.toLowerCase()];
      const keywordMatch = keywords.some((kw) => fullDishText.includes(kw));

      // Specific Dairy Exception Check (if dish is specifically marked isDairyFree)
      if (allergyUpper === 'DAIRY' && dish.isDairyFree) {
        continue;
      }
      // Specific Gluten Exception Check (if dish is specifically marked isGlutenFree)
      if (allergyUpper === 'GLUTEN' && dish.isGlutenFree) {
        continue;
      }

      if (directCodeMatch || keywordMatch) {
        result.hasAllergenConflict = true;
        result.conflictingAllergens.push(allergy);
      }
    }
  }

  if (result.conflictingAllergens.length > 0) {
    result.isExcluded = true;
    result.allergenWarning = `Contains or may contain ${result.conflictingAllergens.join(
      ', '
    )}, conflicting with your allergy profile.`;
  }

  // 2. Strict Dietary Preference Evaluation
  const prefs = profile.dietaryPreferences || [];

  if (prefs.includes('VEGAN')) {
    if (!dish.isVegan) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('VEGAN');
    }
  } else if (prefs.includes('VEGETARIAN')) {
    if (!dish.isVegetarian && !dish.isVegan) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('VEGETARIAN');
    }
  } else if (prefs.includes('JAIN')) {
    // Jain: Vegetarian and strictly no root vegetables (onion, garlic, potato, radish, carrot)
    const rootVegetables = ['onion', 'garlic', 'potato', 'aloo', 'pyaz', 'lehsun', 'ginger', 'root'];
    const hasRoots = rootVegetables.some((rv) => fullDishText.includes(rv));
    if (!dish.isVegetarian || hasRoots) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('JAIN (No root vegetables/onion/garlic)');
    }
  } else if (prefs.includes('EGGETARIAN')) {
    const isEggItem = fullDishText.includes('egg') || dish.tags?.includes('egg');
    if (!dish.isVegetarian && !dish.isVegan && !isEggItem) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('EGGETARIAN');
    }
  } else if (prefs.includes('PESCATARIAN')) {
    const isFish = dish.tags?.includes('fish') || dish.tags?.includes('seafood') || fullDishText.includes('fish') || fullDishText.includes('salmon') || fullDishText.includes('prawn');
    if (!dish.isVegetarian && !dish.isVegan && !isFish) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('PESCATARIAN');
    }
  }

  if (prefs.includes('GLUTEN_FREE') && !dish.isGlutenFree) {
    const glutenKeywords = ALLERGEN_KEYWORD_MAP['GLUTEN'];
    const hasGluten = glutenKeywords.some((kw) => fullDishText.includes(kw));
    if (hasGluten) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('GLUTEN_FREE');
    }
  }

  if (prefs.includes('LACTOSE_FREE') && !dish.isDairyFree) {
    const dairyKeywords = ALLERGEN_KEYWORD_MAP['DAIRY'];
    const hasDairy = dairyKeywords.some((kw) => fullDishText.includes(kw));
    if (hasDairy) {
      result.hasDietaryConflict = true;
      result.conflictingPreferences.push('LACTOSE_FREE');
    }
  }

  if (result.conflictingPreferences.length > 0) {
    result.isExcluded = true;
    result.dietaryWarning = `Does not meet your ${result.conflictingPreferences.join(
      ', '
    )} dietary preference.`;
  }

  return result;
}
