'use client';

import React from 'react';

interface ScoreRingProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  showLabel?: boolean;
}

export function ScoreRing({
  score,
  size = 56,
  strokeWidth = 5,
  showLabel = true,
}: ScoreRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const safeScore = Math.min(100, Math.max(0, score));
  const strokeDashoffset = circumference - (safeScore / 100) * circumference;

  let colorClass = 'text-emerald-500';
  let bgClass = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300';

  if (safeScore >= 85) {
    colorClass = 'text-emerald-500';
    bgClass = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300';
  } else if (safeScore >= 70) {
    colorClass = 'text-teal-500';
    bgClass = 'bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-300';
  } else if (safeScore >= 50) {
    colorClass = 'text-amber-500';
    bgClass = 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300';
  } else if (safeScore >= 30) {
    colorClass = 'text-orange-500';
    bgClass = 'bg-orange-50 text-orange-700 dark:bg-orange-950/50 dark:text-orange-300';
  } else {
    colorClass = 'text-rose-500';
    bgClass = 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300';
  }

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-slate-100 dark:text-slate-800"
          fill="transparent"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className={`${colorClass} transition-all duration-700 ease-out`}
          fill="transparent"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-xs font-black tracking-tight leading-none text-slate-900 dark:text-white">
          {safeScore}%
        </span>
        {showLabel && size >= 54 && (
          <span className="text-[9px] font-semibold text-slate-500 dark:text-slate-400 leading-none mt-0.5">
            MATCH
          </span>
        )}
      </div>
    </div>
  );
}
