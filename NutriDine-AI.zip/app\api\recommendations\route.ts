import { calculateEnergyNeeds } from '@/lib/engine/bmr-tdee';
import {
  DeficitContext,
  rankDishesForRemainingDeficit,
} from '@/lib/engine/scoring';
import {
  AllergenType,
  DietaryPreferenceType,
  MenuItemData,
  UserProfileData,
} from '@/lib/engine/types';
import prisma from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId') || 'user-alex';
    const date = searchParams.get('date') || new Date().toISOString().split('T')[0];
    const budgetParam = searchParams.get('budget');
    const mealType = (searchParams.get('mealType') || 'LUNCH') as 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK';

    // 1. Fetch user & profile
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        profile: true,
        healthMarkers: true,
        dietaryPrefs: true,
        allergies: true,
      },
    });

    if (!user || !user.profile) {
      return NextResponse.json(
        { success: false, error: { code: 'USER_NOT_FOUND', message: 'User profile not found.' } },
        { status: 404 }
      );
    }

    const userProfile: UserProfileData = {
      id: user.id,
      name: user.name,
      age: user.profile.age,
      sex: user.profile.sex as any,
      heightCm: user.profile.heightCm,
      weightKg: user.profile.weightKg,
      activityLevel: user.profile.activityLevel as any,
      goal: user.profile.goal as any,
      targetCaloriesOverride: user.profile.targetCaloriesOverride,
      targetProteinOverride: user.profile.targetProteinOverride,
      spicyPreference: (user.profile.spicyPreference as any) || 'MEDIUM',
      sweetPreference: (user.profile.sweetPreference as any) || 'MODERATE',
      dietaryPreferences: user.dietaryPrefs.map((p) => p.preference as DietaryPreferenceType),
      allergies: user.allergies.map((a) => a.allergen as AllergenType),
    };

    // 2. Compute user's daily baseline energy needs
    const energyNeeds = calculateEnergyNeeds(
      userProfile.weightKg,
      userProfile.heightCm,
      userProfile.age,
      userProfile.sex,
      userProfile.activityLevel,
      userProfile.goal,
      userProfile.targetCaloriesOverride,
      userProfile.targetProteinOverride
    );

    // 3. Fetch today's logged foods
    const todayLogs = await prisma.foodLog.findMany({
      where: {
        userId,
        date,
      },
    });

    const consumed = todayLogs.reduce(
      (acc, log) => ({
        calories: acc.calories + log.calories * log.quantity,
        protein: acc.protein + log.protein * log.quantity,
        carbs: acc.carbs + log.carbs * log.quantity,
        fat: acc.fat + log.fat * log.quantity,
        fiber: acc.fiber + log.fiber * log.quantity,
      }),
      { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
    );

    const avgTargetProtein = Math.round((energyNeeds.proteinRangeMin + energyNeeds.proteinRangeMax) / 2);
    const avgTargetCarbs = Math.round((energyNeeds.carbsRangeMin + energyNeeds.carbsRangeMax) / 2);
    const avgTargetFat = Math.round((energyNeeds.fatRangeMin + energyNeeds.fatRangeMax) / 2);

    const remainingDeficit: DeficitContext = {
      remainingCalories: Math.max(0, energyNeeds.targetCalories - consumed.calories),
      remainingProtein: Math.max(0, avgTargetProtein - consumed.protein),
      remainingCarbs: Math.max(0, avgTargetCarbs - consumed.carbs),
      remainingFat: Math.max(0, avgTargetFat - consumed.fat),
      remainingFiber: Math.max(0, energyNeeds.fiberTargetGrams - consumed.fiber),
      maxBudgetRupees: budgetParam ? parseFloat(budgetParam) : undefined,
      mealType,
    };

    // 4. Fetch all available dishes from active verified restaurants
    const menuItems = await prisma.menuItem.findMany({
      where: {
        isAvailable: true,
        restaurant: {
          isActive: true,
        },
      },
      include: {
        restaurant: {
          select: {
            id: true,
            name: true,
            city: true,
            cuisineTypes: true,
          },
        },
        category: {
          select: {
            name: true,
          },
        },
      },
    });

    const formattedDishes: (MenuItemData & { restaurantName: string })[] = menuItems.map((item) => ({
      id: item.id,
      restaurantId: item.restaurantId,
      restaurantName: item.restaurant.name,
      categoryId: item.categoryId,
      categoryName: item.category.name,
      name: item.name,
      description: item.description,
      price: item.price,
      servingSize: item.servingSize,
      calories: item.calories,
      protein: item.protein,
      carbohydrates: item.carbohydrates,
      fat: item.fat,
      fiber: item.fiber,
      sugar: item.sugar,
      sodium: item.sodium,
      saturatedFat: item.saturatedFat,
      ingredients: item.ingredients,
      allergens: item.allergens,
      preparationMethod: item.preparationMethod || undefined,
      isVegetarian: item.isVegetarian,
      isVegan: item.isVegan,
      isGlutenFree: item.isGlutenFree,
      isDairyFree: item.isDairyFree,
      spicyLevel: item.spicyLevel,
      cuisine: item.cuisine || undefined,
      tags: item.tags || undefined,
      imageUrl: item.imageUrl || undefined,
      isAvailable: item.isAvailable,
      nutritionSource: item.nutritionSource as any,
    }));

    // 5. Rank dishes for remaining deficit
    const recommendations = rankDishesForRemainingDeficit(
      formattedDishes,
      userProfile,
      remainingDeficit
    );

    return NextResponse.json({
      success: true,
      user: {
        name: user.name,
        goal: userProfile.goal,
      },
      dailyTargets: {
        calories: energyNeeds.targetCalories,
        proteinMin: energyNeeds.proteinRangeMin,
        proteinMax: energyNeeds.proteinRangeMax,
        fiber: energyNeeds.fiberTargetGrams,
      },
      todayConsumed: consumed,
      remainingDeficit,
      recommendations: recommendations.slice(0, 10), // Top 10 ranked recommendations
    });
  } catch (error) {
    console.error('Error fetching smart recommendations:', error);
    return NextResponse.json(
      { success: false, error: { code: 'REC_ERROR', message: 'Failed to generate recommendations.' } },
      { status: 500 }
    );
  }
}
