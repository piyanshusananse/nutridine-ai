'use client';

import { AlertTriangle, Info } from 'lucide-react';
import React, { useState } from 'react';

export function DisclaimerBanner() {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-teal-500/10 border-y border-amber-200/50 dark:border-amber-900/30 px-4 py-2.5 text-xs text-slate-700 dark:text-slate-300">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
          <span>
            <strong className="font-semibold text-slate-900 dark:text-white">Wellness Guidance Notice:</strong>{' '}
            NutriDine AI provides nutritional estimates and personalized goal scoring for general wellness. It does not provide medical diagnosis.
            Always verify ingredients and allergens directly with restaurant staff.
          </span>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-slate-400 hover:text-slate-700 dark:hover:text-white font-bold text-xs shrink-0 self-end sm:self-auto cursor-pointer"
        >
          ✕ Dismiss
        </button>
      </div>
    </div>
  );
}
