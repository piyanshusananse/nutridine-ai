'use client';

import { calculateBMI } from '@/lib/engine/bmi';
import { calculateEnergyNeeds } from '@/lib/engine/bmr-tdee';
import {
  ActivityLevel,
  AllergenType,
  BMICalculation,
  DietaryPreferenceType,
  EnergyNeeds,
  MenuItemData,
  Sex,
  UserGoal,
  UserProfileData,
} from '@/lib/engine/types';
import React, { createContext, useContext, useEffect, useState } from 'react';

export interface PersonaOption {
  id: string;
  name: string;
  avatar: string;
  tagline: string;
  profile: UserProfileData;
}

export const PRESET_PERSONAS: PersonaOption[] = [
  {
    id: 'user-alex',
    name: 'Alex Chen',
    avatar: '👨‍💼',
    tagline: '28M • Weight Loss • High Protein',
    profile: {
      id: 'user-alex',
      name: 'Alex Chen',
      age: 28,
      sex: 'MALE',
      heightCm: 175,
      weightKg: 82,
      activityLevel: 'MODERATE',
      goal: 'WEIGHT_LOSS',
      spicyPreference: 'SPICY',
      sweetPreference: 'LOW',
      dietaryPreferences: ['NON_VEGETARIAN', 'LOW_CARB'],
      allergies: [],
      healthMarkers: {
        restingHeartRate: 68,
        dailySteps: 9500,
        dailyWaterIntakeMl: 3000,
        sleepDurationHours: 7.5,
      },
    },
  },
  {
    id: 'user-priya',
    name: 'Priya Patel',
    avatar: '👩‍🔬',
    tagline: '26F • Vegetarian • Muscle Gain • Peanut Allergy',
    profile: {
      id: 'user-priya',
      name: 'Priya Patel',
      age: 26,
      sex: 'FEMALE',
      heightCm: 163,
      weightKg: 56,
      activityLevel: 'LIGHT',
      goal: 'MUSCLE_GAIN',
      spicyPreference: 'MEDIUM',
      sweetPreference: 'MODERATE',
      dietaryPreferences: ['VEGETARIAN'],
      allergies: ['PEANUTS', 'TREE_NUTS'],
      healthMarkers: {
        restingHeartRate: 72,
        dailySteps: 7500,
        dailyWaterIntakeMl: 2400,
        sleepDurationHours: 8.0,
      },
    },
  },
  {
    id: 'user-marcus',
    name: 'Marcus Vance',
    avatar: '🏃‍♂️',
    tagline: '32M • Pescatarian • Gluten-Free • Very Active',
    profile: {
      id: 'user-marcus',
      name: 'Marcus Vance',
      age: 32,
      sex: 'MALE',
      heightCm: 182,
      weightKg: 78,
      activityLevel: 'VERY_ACTIVE',
      goal: 'IMPROVED_PROTEIN',
      spicyPreference: 'MEDIUM',
      sweetPreference: 'LOW',
      dietaryPreferences: ['PESCATARIAN', 'GLUTEN_FREE'],
      allergies: ['GLUTEN'],
      healthMarkers: {
        restingHeartRate: 58,
        dailySteps: 12000,
        dailyWaterIntakeMl: 3500,
        sleepDurationHours: 8.0,
      },
    },
  },
];

interface UserContextType {
  activePersona: PersonaOption;
  userProfile: UserProfileData;
  bmi: BMICalculation;
  energyNeeds: EnergyNeeds;
  comparisonDishes: MenuItemData[];
  selectedDishForModal: MenuItemData | null;
  switchPersona: (personaId: string) => void;
  updateProfile: (updates: Partial<UserProfileData>) => void;
  addToComparison: (dish: MenuItemData) => void;
  removeFromComparison: (dishId: string) => void;
  clearComparison: () => void;
  openDishModal: (dish: MenuItemData) => void;
  closeDishModal: () => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [activePersona, setActivePersona] = useState<PersonaOption>(PRESET_PERSONAS[0]);
  const [userProfile, setUserProfile] = useState<UserProfileData>(PRESET_PERSONAS[0].profile);
  const [comparisonDishes, setComparisonDishes] = useState<MenuItemData[]>([]);
  const [selectedDishForModal, setSelectedDishForModal] = useState<MenuItemData | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Recompute BMI & Energy
  const bmi = calculateBMI(userProfile.weightKg, userProfile.heightCm);
  const energyNeeds = calculateEnergyNeeds(
    userProfile.weightKg,
    userProfile.heightCm,
    userProfile.age,
    userProfile.sex,
    userProfile.activityLevel,
    userProfile.goal,
    userProfile.targetCaloriesOverride,
    userProfile.targetProteinOverride
  );

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const switchPersona = (personaId: string) => {
    const found = PRESET_PERSONAS.find((p) => p.id === personaId);
    if (found) {
      setActivePersona(found);
      setUserProfile(found.profile);
      showToast(`Switched active profile to ${found.name} (${found.profile.goal.replace(/_/g, ' ')})`);
    }
  };

  const updateProfile = (updates: Partial<UserProfileData>) => {
    setUserProfile((prev) => {
      const next = { ...prev, ...updates };
      return next;
    });
    showToast('Personal wellness profile updated successfully!');
  };

  const addToComparison = (dish: MenuItemData) => {
    if (comparisonDishes.some((d) => d.id === dish.id)) {
      showToast(`${dish.name} is already in comparison tray.`);
      return;
    }
    if (comparisonDishes.length >= 3) {
      showToast('You can compare up to 3 dishes at a time.');
      return;
    }
    setComparisonDishes((prev) => [...prev, dish]);
    showToast(`Added "${dish.name}" to comparison (${comparisonDishes.length + 1}/3)`);
  };

  const removeFromComparison = (dishId: string) => {
    setComparisonDishes((prev) => prev.filter((d) => d.id !== dishId));
  };

  const clearComparison = () => {
    setComparisonDishes([]);
  };

  const openDishModal = (dish: MenuItemData) => {
    setSelectedDishForModal(dish);
  };

  const closeDishModal = () => {
    setSelectedDishForModal(null);
  };

  return (
    <UserContext.Provider
      value={{
        activePersona,
        userProfile,
        bmi,
        energyNeeds,
        comparisonDishes,
        selectedDishForModal,
        switchPersona,
        updateProfile,
        addToComparison,
        removeFromComparison,
        clearComparison,
        openDishModal,
        closeDishModal,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
