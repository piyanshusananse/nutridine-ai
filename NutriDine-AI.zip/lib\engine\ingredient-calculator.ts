import { AllergenType, DietaryPreferenceType } from './types';

export interface IngredientNutritionalInfo {
  id: string;
  name: string;
  category: 'PROTEIN' | 'GRAIN' | 'VEGETABLE' | 'DAIRY' | 'FAT_OIL' | 'LEGUME' | 'NUT_SEED' | 'SPICE' | 'OTHER';
  caloriesPer100g: number;
  proteinPer100g: number;
  carbsPer100g: number;
  fatPer100g: number;
  fiberPer100g: number;
  sodiumMgPer100g: number;
  sugarPer100g: number;
  saturatedFatPer100g: number;
  allergens: AllergenType[];
  isVegetarian: boolean;
  isVegan: boolean;
  isGlutenFree: boolean;
  isDairyFree: boolean;
  isJainFriendly: boolean; // No root vegetables (onion, garlic, potato, carrot)
}

export const MASTER_INGREDIENTS: Record<string, IngredientNutritionalInfo> = {
  paneer: {
    id: 'paneer',
    name: 'Paneer (Indian Cottage Cheese)',
    category: 'DAIRY',
    caloriesPer100g: 265,
    proteinPer100g: 18.3,
    carbsPer100g: 3.4,
    fatPer100g: 20.8,
    fiberPer100g: 0,
    sodiumMgPer100g: 18,
    sugarPer100g: 2.6,
    saturatedFatPer100g: 13.0,
    allergens: ['DAIRY'],
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: false,
    isJainFriendly: true,
  },
  chicken_breast: {
    id: 'chicken_breast',
    name: 'Skinless Chicken Breast',
    category: 'PROTEIN',
    caloriesPer100g: 165,
    proteinPer100g: 31.0,
    carbsPer100g: 0,
    fatPer100g: 3.6,
    fiberPer100g: 0,
    sodiumMgPer100g: 74,
    sugarPer100g: 0,
    saturatedFatPer100g: 1.0,
    allergens: [],
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: false,
  },
  tofu_firm: {
    id: 'tofu_firm',
    name: 'Firm Tofu',
    category: 'PROTEIN',
    caloriesPer100g: 144,
    proteinPer100g: 17.3,
    carbsPer100g: 2.8,
    fatPer100g: 8.7,
    fiberPer100g: 2.3,
    sodiumMgPer100g: 14,
    sugarPer100g: 0.6,
    saturatedFatPer100g: 1.3,
    allergens: ['SOY'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  soya_chunks: {
    id: 'soya_chunks',
    name: 'Soya Chunks / TVP',
    category: 'LEGUME',
    caloriesPer100g: 345,
    proteinPer100g: 52.0,
    carbsPer100g: 33.0,
    fatPer100g: 0.5,
    fiberPer100g: 13.0,
    sodiumMgPer100g: 20,
    sugarPer100g: 7.0,
    saturatedFatPer100g: 0.1,
    allergens: ['SOY'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  moong_dal: {
    id: 'moong_dal',
    name: 'Yellow Moong Dal (Cooked)',
    category: 'LEGUME',
    caloriesPer100g: 105,
    proteinPer100g: 7.0,
    carbsPer100g: 19.1,
    fatPer100g: 0.4,
    fiberPer100g: 5.2,
    sodiumMgPer100g: 115,
    sugarPer100g: 1.2,
    saturatedFatPer100g: 0.1,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  chickpeas_chana: {
    id: 'chickpeas_chana',
    name: 'Kabuli Chana / Chickpeas (Cooked)',
    category: 'LEGUME',
    caloriesPer100g: 164,
    proteinPer100g: 8.9,
    carbsPer100g: 27.4,
    fatPer100g: 2.6,
    fiberPer100g: 7.6,
    sodiumMgPer100g: 24,
    sugarPer100g: 4.8,
    saturatedFatPer100g: 0.3,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  basmati_rice: {
    id: 'basmati_rice',
    name: 'Basmati Rice (Steamed)',
    category: 'GRAIN',
    caloriesPer100g: 130,
    proteinPer100g: 2.7,
    carbsPer100g: 28.2,
    fatPer100g: 0.3,
    fiberPer100g: 0.4,
    sodiumMgPer100g: 1,
    sugarPer100g: 0.1,
    saturatedFatPer100g: 0.1,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  brown_rice: {
    id: 'brown_rice',
    name: 'Brown Rice (Cooked)',
    category: 'GRAIN',
    caloriesPer100g: 112,
    proteinPer100g: 2.6,
    carbsPer100g: 23.5,
    fatPer100g: 0.9,
    fiberPer100g: 1.8,
    sodiumMgPer100g: 2,
    sugarPer100g: 0.2,
    saturatedFatPer100g: 0.2,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  wheat_flour_atta: {
    id: 'wheat_flour_atta',
    name: 'Whole Wheat Flour / Atta (Roti)',
    category: 'GRAIN',
    caloriesPer100g: 260,
    proteinPer100g: 9.0,
    carbsPer100g: 54.0,
    fatPer100g: 1.5,
    fiberPer100g: 8.5,
    sodiumMgPer100g: 5,
    sugarPer100g: 1.0,
    saturatedFatPer100g: 0.3,
    allergens: ['GLUTEN'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: false,
    isDairyFree: true,
    isJainFriendly: true,
  },
  spinach_palak: {
    id: 'spinach_palak',
    name: 'Fresh Spinach / Palak',
    category: 'VEGETABLE',
    caloriesPer100g: 23,
    proteinPer100g: 2.9,
    carbsPer100g: 3.6,
    fatPer100g: 0.4,
    fiberPer100g: 2.2,
    sodiumMgPer100g: 79,
    sugarPer100g: 0.4,
    saturatedFatPer100g: 0.1,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  bell_pepper: {
    id: 'bell_pepper',
    name: 'Capsicum / Bell Pepper',
    category: 'VEGETABLE',
    caloriesPer100g: 31,
    proteinPer100g: 1.0,
    carbsPer100g: 6.0,
    fatPer100g: 0.3,
    fiberPer100g: 2.1,
    sodiumMgPer100g: 4,
    sugarPer100g: 4.2,
    saturatedFatPer100g: 0.1,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  onion: {
    id: 'onion',
    name: 'Onion (Raw/Cooked)',
    category: 'VEGETABLE',
    caloriesPer100g: 40,
    proteinPer100g: 1.1,
    carbsPer100g: 9.3,
    fatPer100g: 0.1,
    fiberPer100g: 1.7,
    sodiumMgPer100g: 4,
    sugarPer100g: 4.2,
    saturatedFatPer100g: 0.0,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: false, // Root vegetable
  },
  garlic: {
    id: 'garlic',
    name: 'Garlic',
    category: 'VEGETABLE',
    caloriesPer100g: 149,
    proteinPer100g: 6.4,
    carbsPer100g: 33.1,
    fatPer100g: 0.5,
    fiberPer100g: 2.1,
    sodiumMgPer100g: 17,
    sugarPer100g: 1.0,
    saturatedFatPer100g: 0.1,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: false, // Root vegetable
  },
  tomato: {
    id: 'tomato',
    name: 'Tomato (Fresh/Puree)',
    category: 'VEGETABLE',
    caloriesPer100g: 18,
    proteinPer100g: 0.9,
    carbsPer100g: 3.9,
    fatPer100g: 0.2,
    fiberPer100g: 1.2,
    sodiumMgPer100g: 5,
    sugarPer100g: 2.6,
    saturatedFatPer100g: 0.0,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  curd_dahi: {
    id: 'curd_dahi',
    name: 'Plain Curd / Dahi / Yogurt',
    category: 'DAIRY',
    caloriesPer100g: 61,
    proteinPer100g: 3.5,
    carbsPer100g: 4.7,
    fatPer100g: 3.3,
    fiberPer100g: 0,
    sodiumMgPer100g: 46,
    sugarPer100g: 4.7,
    saturatedFatPer100g: 2.1,
    allergens: ['DAIRY'],
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: false,
    isJainFriendly: true,
  },
  desi_ghee: {
    id: 'desi_ghee',
    name: 'Desi Ghee (Clarified Butter)',
    category: 'FAT_OIL',
    caloriesPer100g: 884,
    proteinPer100g: 0.3,
    carbsPer100g: 0,
    fatPer100g: 99.5,
    fiberPer100g: 0,
    sodiumMgPer100g: 2,
    sugarPer100g: 0,
    saturatedFatPer100g: 61.9,
    allergens: ['DAIRY'],
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: false,
    isJainFriendly: true,
  },
  mustard_oil: {
    id: 'mustard_oil',
    name: 'Mustard Oil (Kachi Ghani)',
    category: 'FAT_OIL',
    caloriesPer100g: 884,
    proteinPer100g: 0,
    carbsPer100g: 0,
    fatPer100g: 100.0,
    fiberPer100g: 0,
    sodiumMgPer100g: 0,
    sugarPer100g: 0,
    saturatedFatPer100g: 12.0,
    allergens: ['MUSTARD'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  olive_oil: {
    id: 'olive_oil',
    name: 'Extra Virgin Olive Oil',
    category: 'FAT_OIL',
    caloriesPer100g: 884,
    proteinPer100g: 0,
    carbsPer100g: 0,
    fatPer100g: 100.0,
    fiberPer100g: 0,
    sodiumMgPer100g: 2,
    sugarPer100g: 0,
    saturatedFatPer100g: 14.0,
    allergens: [],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  cashews: {
    id: 'cashews',
    name: 'Cashew Nuts (Kaju)',
    category: 'NUT_SEED',
    caloriesPer100g: 553,
    proteinPer100g: 18.2,
    carbsPer100g: 30.2,
    fatPer100g: 43.8,
    fiberPer100g: 3.3,
    sodiumMgPer100g: 12,
    sugarPer100g: 5.9,
    saturatedFatPer100g: 7.8,
    allergens: ['TREE_NUTS'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  peanuts: {
    id: 'peanuts',
    name: 'Roasted Peanuts (Moongphali)',
    category: 'NUT_SEED',
    caloriesPer100g: 567,
    proteinPer100g: 25.8,
    carbsPer100g: 16.1,
    fatPer100g: 49.2,
    fiberPer100g: 8.5,
    sodiumMgPer100g: 18,
    sugarPer100g: 4.7,
    saturatedFatPer100g: 6.8,
    allergens: ['PEANUTS'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
  egg_whole: {
    id: 'egg_whole',
    name: 'Whole Chicken Egg',
    category: 'PROTEIN',
    caloriesPer100g: 143,
    proteinPer100g: 12.6,
    carbsPer100g: 0.7,
    fatPer100g: 9.5,
    fiberPer100g: 0,
    sodiumMgPer100g: 142,
    sugarPer100g: 0.4,
    saturatedFatPer100g: 3.1,
    allergens: ['EGGS'],
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: false,
  },
  salmon_fish: {
    id: 'salmon_fish',
    name: 'Fresh Salmon Fillet',
    category: 'PROTEIN',
    caloriesPer100g: 208,
    proteinPer100g: 20.4,
    carbsPer100g: 0,
    fatPer100g: 13.4,
    fiberPer100g: 0,
    sodiumMgPer100g: 59,
    sugarPer100g: 0,
    saturatedFatPer100g: 3.1,
    allergens: ['FISH'],
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: false,
  },
  prawns_shrimp: {
    id: 'prawns_shrimp',
    name: 'Fresh Prawns / Shrimp',
    category: 'PROTEIN',
    caloriesPer100g: 99,
    proteinPer100g: 24.0,
    carbsPer100g: 0.2,
    fatPer100g: 0.3,
    fiberPer100g: 0,
    sodiumMgPer100g: 111,
    sugarPer100g: 0,
    saturatedFatPer100g: 0.1,
    allergens: ['SHELLFISH'],
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: false,
  },
  sesame_seeds: {
    id: 'sesame_seeds',
    name: 'White Sesame Seeds (Til)',
    category: 'NUT_SEED',
    caloriesPer100g: 573,
    proteinPer100g: 17.7,
    carbsPer100g: 23.4,
    fatPer100g: 49.7,
    fiberPer100g: 11.8,
    sodiumMgPer100g: 11,
    sugarPer100g: 0.3,
    saturatedFatPer100g: 7.0,
    allergens: ['SESAME'],
    isVegetarian: true,
    isVegan: true,
    isGlutenFree: true,
    isDairyFree: true,
    isJainFriendly: true,
  },
};

export interface RecipeItemInput {
  ingredientKey: string;
  quantityGrams: number;
}

export interface CalculatedRecipeNutrition {
  totalWeightGrams: number;
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
  fiber: number;
  sodium: number;
  sugar: number;
  saturatedFat: number;
  allergens: AllergenType[];
  isVegetarian: boolean;
  isVegan: boolean;
  isGlutenFree: boolean;
  isDairyFree: boolean;
  isJainFriendly: boolean;
  itemizedBreakdown: {
    name: string;
    quantityGrams: number;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }[];
}

/**
 * Calculates estimated nutritional values and allergen profile from a list of recipe ingredients.
 */
export function calculateRecipeNutrition(items: RecipeItemInput[]): CalculatedRecipeNutrition {
  let totalWeightGrams = 0;
  let calories = 0;
  let protein = 0;
  let carbohydrates = 0;
  let fat = 0;
  let fiber = 0;
  let sodium = 0;
  let sugar = 0;
  let saturatedFat = 0;

  const allergenSet = new Set<AllergenType>();
  let isVegetarian = true;
  let isVegan = true;
  let isGlutenFree = true;
  let isDairyFree = true;
  let isJainFriendly = true;

  const itemizedBreakdown: CalculatedRecipeNutrition['itemizedBreakdown'] = [];

  for (const item of items) {
    const key = item.ingredientKey.toLowerCase().trim().replace(/[\s-]+/g, '_');
    const ingredient = MASTER_INGREDIENTS[key];

    if (!ingredient) {
      continue;
    }

    const factor = item.quantityGrams / 100;
    totalWeightGrams += item.quantityGrams;

    const itemCal = Math.round(ingredient.caloriesPer100g * factor);
    const itemProt = Number((ingredient.proteinPer100g * factor).toFixed(1));
    const itemCarb = Number((ingredient.carbsPer100g * factor).toFixed(1));
    const itemFat = Number((ingredient.fatPer100g * factor).toFixed(1));

    calories += itemCal;
    protein += itemProt;
    carbohydrates += itemCarb;
    fat += itemFat;
    fiber += ingredient.fiberPer100g * factor;
    sodium += ingredient.sodiumMgPer100g * factor;
    sugar += ingredient.sugarPer100g * factor;
    saturatedFat += ingredient.saturatedFatPer100g * factor;

    ingredient.allergens.forEach((a) => allergenSet.add(a));

    if (!ingredient.isVegetarian) isVegetarian = false;
    if (!ingredient.isVegan) isVegan = false;
    if (!ingredient.isGlutenFree) isGlutenFree = false;
    if (!ingredient.isDairyFree) isDairyFree = false;
    if (!ingredient.isJainFriendly) isJainFriendly = false;

    itemizedBreakdown.push({
      name: ingredient.name,
      quantityGrams: item.quantityGrams,
      calories: itemCal,
      protein: itemProt,
      carbs: itemCarb,
      fat: itemFat,
    });
  }

  return {
    totalWeightGrams,
    calories: Math.round(calories),
    protein: Number(protein.toFixed(1)),
    carbohydrates: Number(carbohydrates.toFixed(1)),
    fat: Number(fat.toFixed(1)),
    fiber: Number(fiber.toFixed(1)),
    sodium: Math.round(sodium),
    sugar: Number(sugar.toFixed(1)),
    saturatedFat: Number(saturatedFat.toFixed(1)),
    allergens: Array.from(allergenSet),
    isVegetarian,
    isVegan,
    isGlutenFree,
    isDairyFree,
    isJainFriendly,
    itemizedBreakdown,
  };
}
