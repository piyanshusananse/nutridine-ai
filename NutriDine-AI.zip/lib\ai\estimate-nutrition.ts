export interface EstimatedNutritionResult {
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
  fiber: number;
  sodium: number;
  saturatedFat: number;
  sugar: number;
  allergensDetected: string[];
  isVegetarian: boolean;
  isVegan: boolean;
  isGlutenFree: boolean;
  isDairyFree: boolean;
  confidenceScore: number; // 0 - 100
  disclaimer: string;
}

// Nutritional lookup heuristics per 100g of common ingredients
const INGREDIENT_LOOKUP: Record<
  string,
  { cal: number; p: number; c: number; f: number; fib: number; sod: number; allergens?: string[] }
> = {
  chicken: { cal: 165, p: 31, c: 0, f: 3.6, fib: 0, sod: 74 },
  paneer: { cal: 265, p: 18, c: 3, f: 20, fib: 0, sod: 20, allergens: ['DAIRY'] },
  tofu: { cal: 76, p: 8, c: 1.9, f: 4.8, fib: 0.3, sod: 7, allergens: ['SOY'] },
  salmon: { cal: 208, p: 20, c: 0, f: 13, fib: 0, sod: 59, allergens: ['FISH'] },
  fish: { cal: 140, p: 22, c: 0, f: 5, fib: 0, sod: 60, allergens: ['FISH'] },
  egg: { cal: 143, p: 13, c: 0.7, f: 9.5, fib: 0, sod: 142, allergens: ['EGGS'] },
  rice: { cal: 130, p: 2.7, c: 28, f: 0.3, fib: 0.4, sod: 1 },
  quinoa: { cal: 120, p: 4.4, c: 21.3, f: 1.9, fib: 2.8, sod: 7 },
  dal: { cal: 115, p: 9, c: 20, f: 0.5, fib: 8, sod: 2 },
  lentils: { cal: 116, p: 9, c: 20, f: 0.4, fib: 7.9, sod: 2 },
  chickpeas: { cal: 164, p: 8.9, c: 27.4, f: 2.6, fib: 7.6, sod: 24 },
  wheat: { cal: 340, p: 13, c: 72, f: 2.5, fib: 10.7, sod: 2, allergens: ['GLUTEN'] },
  flour: { cal: 364, p: 10, c: 76, f: 1, fib: 2.7, sod: 2, allergens: ['GLUTEN'] },
  bread: { cal: 265, p: 9, c: 49, f: 3.2, fib: 2.7, sod: 490, allergens: ['GLUTEN'] },
  milk: { cal: 60, p: 3.2, c: 4.8, f: 3.2, fib: 0, sod: 44, allergens: ['DAIRY'] },
  butter: { cal: 717, p: 0.8, c: 0.1, f: 81, fib: 0, sod: 643, allergens: ['DAIRY'] },
  cream: { cal: 340, p: 2.8, c: 3.7, f: 36, fib: 0, sod: 38, allergens: ['DAIRY'] },
  cheese: { cal: 402, p: 25, c: 1.3, f: 33, fib: 0, sod: 621, allergens: ['DAIRY'] },
  yogurt: { cal: 61, p: 3.5, c: 4.7, f: 3.3, fib: 0, sod: 46, allergens: ['DAIRY'] },
  curd: { cal: 61, p: 3.5, c: 4.7, f: 3.3, fib: 0, sod: 46, allergens: ['DAIRY'] },
  avocado: { cal: 160, p: 2, c: 8.5, f: 14.7, fib: 6.7, sod: 7 },
  spinach: { cal: 23, p: 2.9, c: 3.6, f: 0.4, fib: 2.2, sod: 79 },
  broccoli: { cal: 34, p: 2.8, c: 6.6, f: 0.4, fib: 2.6, sod: 33 },
  tomato: { cal: 18, p: 0.9, c: 3.9, f: 0.2, fib: 1.2, sod: 5 },
  onion: { cal: 40, p: 1.1, c: 9.3, f: 0.1, fib: 1.7, sod: 4 },
  peanut: { cal: 567, p: 26, c: 16, f: 49, fib: 8.5, sod: 18, allergens: ['PEANUTS'] },
  cashew: { cal: 553, p: 18, c: 30, f: 44, fib: 3.3, sod: 12, allergens: ['TREE_NUTS'] },
  almond: { cal: 579, p: 21, c: 22, f: 50, fib: 12.5, sod: 1, allergens: ['TREE_NUTS'] },
  sugar: { cal: 387, p: 0, c: 100, f: 0, fib: 0, sod: 1 },
  oil: { cal: 884, p: 0, c: 0, f: 100, fib: 0, sod: 0 },
  olive: { cal: 115, p: 0.8, c: 6, f: 11, fib: 3.2, sod: 735 },
};

/**
 * Deterministically estimates dish nutritional facts from ingredients and serving weight.
 */
export function estimateNutritionFromIngredients(
  dishName: string,
  ingredientsText: string,
  servingWeightGrams: number = 350
): EstimatedNutritionResult {
  const ingredientsList = ingredientsText
    .toLowerCase()
    .split(/[,;\n]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  let totalCal = 0;
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFat = 0;
  let totalFiber = 0;
  let totalSodium = 0;
  const allergensSet = new Set<string>();

  let recognizedCount = 0;
  const portionPerIngredient = servingWeightGrams / Math.max(1, ingredientsList.length);

  for (const rawIng of ingredientsList) {
    let matched = false;
    for (const [key, data] of Object.entries(INGREDIENT_LOOKUP)) {
      if (rawIng.includes(key)) {
        matched = true;
        recognizedCount++;
        const factor = portionPerIngredient / 100;
        totalCal += data.cal * factor;
        totalProtein += data.p * factor;
        totalCarbs += data.c * factor;
        totalFat += data.f * factor;
        totalFiber += data.fib * factor;
        totalSodium += data.sod * factor;

        if (data.allergens) {
          data.allergens.forEach((a) => allergensSet.add(a));
        }
        break;
      }
    }
  }

  // Base cooking adjustment (cooking oil & seasoning base)
  totalFat += 8; // ~8g cooking fat
  totalCal += 72;
  totalSodium += 350; // cooking salt

  // Dietary checks
  const nonVegKeywords = ['chicken', 'mutton', 'lamb', 'beef', 'pork', 'fish', 'salmon', 'prawn', 'shrimp', 'crab'];
  const hasNonVeg = ingredientsList.some((ing) => nonVegKeywords.some((k) => ing.includes(k)));
  const isVegetarian = !hasNonVeg;
  const hasDairy = allergensSet.has('DAIRY');
  const hasEgg = allergensSet.has('EGGS');
  const isVegan = isVegetarian && !hasDairy && !hasEgg;
  const isGlutenFree = !allergensSet.has('GLUTEN');
  const isDairyFree = !hasDairy;

  const confidenceScore = Math.min(
    95,
    Math.max(45, Math.round((recognizedCount / Math.max(1, ingredientsList.length)) * 100))
  );

  return {
    calories: Math.round(totalCal || 420),
    protein: Math.round((totalProtein || 18) * 10) / 10,
    carbohydrates: Math.round((totalCarbs || 45) * 10) / 10,
    fat: Math.round((totalFat || 14) * 10) / 10,
    fiber: Math.round((totalFiber || 4) * 10) / 10,
    sodium: Math.round(totalSodium || 550),
    saturatedFat: Math.round((totalFat * 0.25) * 10) / 10,
    sugar: Math.round((totalCarbs * 0.1) * 10) / 10,
    allergensDetected: Array.from(allergensSet),
    isVegetarian,
    isVegan,
    isGlutenFree,
    isDairyFree,
    confidenceScore,
    disclaimer:
      'AI Estimated Nutrition: These figures are estimated mathematically based on ingredients and standard serving portions. Not laboratory tested. Always consult restaurant staff for strict dietary needs.',
  };
}
