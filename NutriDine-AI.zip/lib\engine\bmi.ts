import { BMICalculation } from './types';

/**
 * Calculates Body Mass Index (BMI) and provides non-judgmental wellness context.
 * Formula: weight (kg) / [height (m)]^2
 */
export function calculateBMI(weightKg: number, heightCm: number): BMICalculation {
  if (!weightKg || !heightCm || heightCm <= 0 || weightKg <= 0) {
    return {
      bmi: 0,
      category: 'Healthy range',
      color: 'emerald',
      disclaimer:
        'BMI is a general wellness indicator and does not fully represent individual body composition, athletic build, or medical status.',
    };
  }

  const heightM = heightCm / 100;
  const rawBmi = weightKg / (heightM * heightM);
  const bmi = Math.round(rawBmi * 10) / 10;

  let category: BMICalculation['category'] = 'Healthy range';
  let color = 'emerald';

  if (bmi < 18.5) {
    category = 'Underweight';
    color = 'amber';
  } else if (bmi < 25) {
    category = 'Healthy range';
    color = 'emerald';
  } else if (bmi < 30) {
    category = 'Overweight';
    color = 'sky';
  } else if (bmi < 35) {
    category = 'Obesity class I';
    color = 'indigo';
  } else {
    category = 'Obesity class II+';
    color = 'purple';
  }

  return {
    bmi,
    category,
    color,
    disclaimer:
      'BMI is one general wellness marker among many. It does not measure body fat percentage, lean muscle mass, or metabolic health directly.',
  };
}
