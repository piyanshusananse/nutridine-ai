import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { AuthProvider } from '@/components/AuthProvider';
import { UserProvider } from '@/context/UserContext';
import { Navbar } from '@/components/Navbar';
import { DisclaimerBanner } from '@/components/ui/DisclaimerBanner';
import { ComparisonTray } from '@/components/ComparisonTray';
import { MobileBottomNav } from '@/components/MobileBottomNav';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'NutriDine AI — Personalized Restaurant Food Recommendations',
  description:
    'AI-powered restaurant menu recommendations personalized to your body, lifestyle, and fitness goals. Know exactly what to order at any restaurant.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="h-full">
      <body className={`${inter.className} min-h-full flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 antialiased`}>
        <AuthProvider>
          <UserProvider>
          <DisclaimerBanner />
          <Navbar />
          <main className="flex-1 pb-20 md:pb-10">
            {children}
          </main>
          <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-8 px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 font-black text-sm text-slate-900 dark:text-white">
                <span className="p-1 rounded-lg bg-emerald-600 text-white text-xs">🥗</span>
                <span>NutriDine AI</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Personalized AI Restaurant Menu & Food Recommendation System • Empowering Healthy Dining
              </p>
              <div className="text-[11px] text-slate-400">
                © {new Date().getFullYear()} NutriDine AI. All rights reserved.
              </div>
            </div>
          </footer>
          <ComparisonTray />
          <MobileBottomNav />
        </UserProvider>
      </AuthProvider>
    </body>
  </html>
  );
}
