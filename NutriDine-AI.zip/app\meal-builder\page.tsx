'use client';

import { MacroBar } from '@/components/ui/MacroBar';
import { useUser } from '@/context/UserContext';
import { MealCombination } from '@/lib/engine/types';
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Coffee,
  Flame,
  Layers,
  Moon,
  Plus,
  RefreshCw,
  Sparkles,
  Sun,
  Utensils,
  UtensilsCrossed,
} from 'lucide-react';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';

export default function MealBuilderPage() {
  const { activePersona, userProfile, energyNeeds, showToast } = useUser();

  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string>('rest-mumbai-spice');
  const [mealType, setMealType] = useState<'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK'>('DINNER');
  const [targetCalories, setTargetCalories] = useState<number>(
    Math.round(energyNeeds.targetCalories * 0.35)
  );

  const [combinations, setCombinations] = useState<MealCombination[]>([]);
  const [selectedComboIndex, setSelectedComboIndex] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function loadRestaurants() {
      try {
        const res = await fetch('/api/restaurants');
        const data = await res.json();
        if (data.success && data.restaurants.length > 0) {
          setRestaurants(data.restaurants);
          setSelectedRestaurantId(data.restaurants[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    }
    loadRestaurants();
  }, []);

  const generateMeal = async () => {
    if (!selectedRestaurantId) return;
    setIsLoading(true);

    try {
      const res = await fetch('/api/meal-builder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: selectedRestaurantId,
          userId: userProfile.id || 'user-alex',
          mealType,
          targetCalories,
        }),
      });

      const data = await res.json();
      if (data.success && data.combinations) {
        setCombinations(data.combinations);
        setSelectedComboIndex(0);
        showToast('Generated optimal meal combinations!');
      }
    } catch (err) {
      console.error('Error generating meal combinations:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (selectedRestaurantId) {
      generateMeal();
    }
  }, [selectedRestaurantId, mealType, activePersona.id]);

  const currentCombo = combinations[selectedComboIndex];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-10 shadow-2xl space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/20 text-teal-400 text-xs font-bold border border-teal-500/30">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Combinatorial AI Meal Planner</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight">Smart Meal Builder</h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
          NutriDine AI combines entrées, sides, and beverages from a single restaurant menu to build a complete, balanced meal tailored precisely to your calorie and protein budget.
        </p>
      </div>

      {/* Configuration Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Control Column */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <h3 className="text-sm font-black uppercase tracking-wider text-slate-900 dark:text-white">
            1. Meal Parameters
          </h3>

          {/* Restaurant Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Select Restaurant</label>
            <select
              value={selectedRestaurantId}
              onChange={(e) => setSelectedRestaurantId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold focus:ring-2 focus:ring-emerald-500 dark:text-white"
            >
              {restaurants.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
          </div>

          {/* Meal Type Buttons */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Meal Type</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'BREAKFAST', label: 'Breakfast', icon: Coffee },
                { id: 'LUNCH', label: 'Lunch', icon: Sun },
                { id: 'DINNER', label: 'Dinner', icon: Moon },
                { id: 'SNACK', label: 'Snack', icon: Sparkles },
              ].map((m) => {
                const Icon = m.icon;
                const isSelected = mealType === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setMealType(m.id as any);
                      let newCal = Math.round(energyNeeds.targetCalories * 0.35);
                      if (m.id === 'BREAKFAST') newCal = Math.round(energyNeeds.targetCalories * 0.25);
                      if (m.id === 'SNACK') newCal = Math.round(energyNeeds.targetCalories * 0.15);
                      setTargetCalories(newCal);
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Calorie Target Slider */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Target Meal Energy</label>
              <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                {targetCalories} kcal
              </span>
            </div>
            <input
              type="range"
              min={250}
              max={1200}
              step={25}
              value={targetCalories}
              onChange={(e) => setTargetCalories(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Light (250 kcal)</span>
              <span>Hearty (1200 kcal)</span>
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={generateMeal}
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Generate Meal Combinations</span>
          </button>
        </div>

        {/* Right Output Column */}
        <div className="lg:col-span-8 space-y-6">
          {isLoading ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 border border-slate-200 dark:border-slate-800 text-center space-y-3">
              <RefreshCw className="w-8 h-8 animate-spin text-emerald-600 mx-auto" />
              <p className="text-xs text-slate-500">
                Solving optimal item combinations from {selectedRestaurantId}...
              </p>
            </div>
          ) : combinations.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
              <UtensilsCrossed className="w-12 h-12 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">No Valid Combinations Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No safe menu combinations were found for your strict dietary constraints at this calorie budget.
                Try adjusting the target calories.
              </p>
            </div>
          ) : (
            <>
              {/* Alternative Combination Selector Tabs */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {combinations.map((combo, idx) => {
                  const isSelected = selectedComboIndex === idx;
                  return (
                    <button
                      key={idx}
                      onClick={() => setSelectedComboIndex(idx)}
                      className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-slate-900 text-white border-slate-900 dark:bg-emerald-600 dark:border-emerald-600 shadow-md'
                          : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50'
                      }`}
                    >
                      <span>{combo.goalFitVerdict}</span>
                      <span className="ml-2 opacity-75 font-normal">({combo.totalCalories} kcal)</span>
                    </button>
                  );
                })}
              </div>

              {/* Main Selected Meal Combination Card */}
              {currentCombo && (
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
                  {/* Top Verdict & Score */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-bold mb-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Recommended {mealType.toLowerCase()} for {userProfile.name}</span>
                      </div>
                      <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                        {currentCombo.goalFitVerdict}
                      </h2>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 max-w-xl">
                        {currentCombo.explanation}
                      </p>
                    </div>

                    <div className="text-right shrink-0 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-100 dark:border-slate-700">
                      <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                        {currentCombo.combinedScore}%
                      </div>
                      <div className="text-[10px] font-bold uppercase text-slate-400">Meal Fit Score</div>
                    </div>
                  </div>

                  {/* Course Items List */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                      Selected Course Items:
                    </h4>
                    <div className="space-y-2.5">
                      {currentCombo.items.map(({ menuItem, role }, i) => (
                        <div
                          key={menuItem.id}
                          className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/80 gap-3"
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={
                                menuItem.imageUrl ||
                                'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80'
                              }
                              alt={menuItem.name}
                              className="w-12 h-12 rounded-xl object-cover"
                            />
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                  {role}
                                </span>
                                <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                                  {menuItem.name}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-500 mt-0.5">
                                {menuItem.calories} kcal • {menuItem.protein}g Prot • {menuItem.carbohydrates}g Carb • {menuItem.fat}g Fat
                              </div>
                            </div>
                          </div>

                          <div className="text-right font-black text-sm text-slate-900 dark:text-white shrink-0">
                            ₹{Math.round(menuItem.price)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Combined Nutrition Metrics */}
                  <div className="space-y-3 pt-2">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                      Combined Meal Nutrition:
                    </h4>
                    <MacroBar
                      protein={currentCombo.totalProtein}
                      carbs={currentCombo.totalCarbs}
                      fat={currentCombo.totalFat}
                      calories={currentCombo.totalCalories}
                    />

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Total Calories</span>
                        <span className="font-extrabold text-slate-900 dark:text-white text-base">
                          {currentCombo.totalCalories} kcal
                        </span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Total Protein</span>
                        <span className="font-extrabold text-emerald-600 text-base">
                          {currentCombo.totalProtein}g
                        </span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Total Fiber</span>
                        <span className="font-extrabold text-sky-600 text-base">{currentCombo.totalFiber}g</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Est. Meal Total</span>
                        <span className="font-extrabold text-slate-900 dark:text-white text-base">
                          ₹
                          {Math.round(
                            currentCombo.items.reduce((sum, it) => sum + it.menuItem.price, 0)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                    <Link
                      href={`/restaurants/${selectedRestaurantId}`}
                      className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors"
                    >
                      View Restaurant Menu
                    </Link>

                    <button
                      onClick={() => {
                        showToast(`Successfully logged ${mealType.toLowerCase()} to your dashboard tracker!`);
                      }}
                      className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold shadow-lg shadow-emerald-600/20 cursor-pointer transition-all"
                    >
                      Save & Log This Meal
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
