import { calculateEnergyNeeds } from './bmr-tdee';
import { evaluateHardConstraints } from './hard-constraints';
import { evaluateDishRecommendation } from './scoring';
import { MealCombination, MenuItemData, UserProfileData } from './types';

/**
 * Intelligent combinatorial meal generator that builds complete, multi-course meals
 * strictly from a restaurant's real menu, fitting the user's specific calorie & macro budget.
 */
export function buildSmartMealCombinations(
  restaurantId: string,
  restaurantName: string,
  menuItems: MenuItemData[],
  profile: UserProfileData,
  mealType: 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK' = 'DINNER',
  targetCaloriesOverride?: number
): MealCombination[] {
  // 1. Filter out unsafe items for this user
  const safeItems = menuItems.filter((dish) => {
    const hardCheck = evaluateHardConstraints(dish, profile);
    return !hardCheck.isExcluded && dish.isAvailable;
  });

  if (safeItems.length === 0) {
    return [];
  }

  // 2. Calculate user target for this meal
  const energy = calculateEnergyNeeds(
    profile.weightKg,
    profile.heightCm,
    profile.age,
    profile.sex,
    profile.activityLevel,
    profile.goal,
    profile.targetCaloriesOverride,
    profile.targetProteinOverride
  );

  let mealCalorieBudget = Math.round(energy.targetCalories * 0.35); // 35% for lunch/dinner
  if (mealType === 'BREAKFAST') mealCalorieBudget = Math.round(energy.targetCalories * 0.25);
  if (mealType === 'SNACK') mealCalorieBudget = Math.round(energy.targetCalories * 0.15);

  if (targetCaloriesOverride && targetCaloriesOverride >= 200) {
    mealCalorieBudget = targetCaloriesOverride;
  }

  // Group items by category / role
  const mains: MenuItemData[] = [];
  const starters: MenuItemData[] = [];
  const sidesAndSalads: MenuItemData[] = [];
  const beverages: MenuItemData[] = [];

  for (const item of safeItems) {
    const nameLower = item.name.toLowerCase();
    const catLower = (item.categoryName || '').toLowerCase();
    const descLower = item.description.toLowerCase();

    if (catLower.includes('beverage') || catLower.includes('drink') || nameLower.includes('water') || nameLower.includes('lassi') || nameLower.includes('smoothie')) {
      beverages.push(item);
    } else if (catLower.includes('starter') || catLower.includes('soup') || catLower.includes('appetizer')) {
      starters.push(item);
    } else if (catLower.includes('salad') || catLower.includes('side') || nameLower.includes('roti') || nameLower.includes('rice') || nameLower.includes('bread')) {
      sidesAndSalads.push(item);
    } else {
      mains.push(item);
    }
  }

  // Fallback if categorization is sparse: use items by calorie bands
  const scoredSafeItems = safeItems
    .map((item) => ({ item, rec: evaluateDishRecommendation(item, profile) }))
    .sort((a, b) => b.rec.score - a.rec.score);

  const combinations: MealCombination[] = [];

  // Combo 1: Optimal Goal Match Combo (Top Scoring Main + Complementary Starter/Side)
  const topMain = (mains.length > 0 ? mains : safeItems)
    .map((item) => ({ item, rec: evaluateDishRecommendation(item, profile) }))
    .sort((a, b) => b.rec.score - a.rec.score)[0]?.item;

  if (topMain) {
    const selectedItems: MealCombination['items'] = [{ menuItem: topMain, role: 'MAIN' }];
    let currentCals = topMain.calories;

    // Add a side or salad if budget permits (>150 kcal remaining)
    const remainingCals = mealCalorieBudget - currentCals;
    if (remainingCals >= 120 && sidesAndSalads.length > 0) {
      const bestSide = sidesAndSalads
        .filter((s) => s.id !== topMain.id && s.calories <= remainingCals + 80)
        .sort((a, b) => b.fiber - a.fiber || a.calories - b.calories)[0];
      if (bestSide) {
        selectedItems.push({ menuItem: bestSide, role: 'SIDE' });
        currentCals += bestSide.calories;
      }
    }

    // Add a light beverage / water if budget permits
    const lightDrink = beverages.find((b) => b.calories <= 80 || b.name.toLowerCase().includes('water'));
    if (lightDrink && selectedItems.length < 3) {
      selectedItems.push({ menuItem: lightDrink, role: 'BEVERAGE' });
    }

    const totals = calculateMealTotals(selectedItems);
    combinations.push({
      mealType,
      restaurantId,
      restaurantName,
      items: selectedItems,
      ...totals,
      combinedScore: Math.round(
        selectedItems.reduce((acc, it) => acc + evaluateDishRecommendation(it.menuItem, profile).score, 0) /
          selectedItems.length
      ),
      goalFitVerdict: 'Highest Goal Alignment Combo',
      explanation: `Assembled to hit approximately ${totals.totalCalories} kcal with ${totals.totalProtein}g protein, specifically tailored for your ${profile.goal.replace(
        /_/g,
        ' '
      ).toLowerCase()} target.`,
    });
  }

  // Combo 2: High Protein Powerhouse Combo
  const highProteinMain = [...safeItems].sort((a, b) => b.protein - a.protein)[0];
  if (highProteinMain && (!topMain || highProteinMain.id !== topMain.id || safeItems.length > 2)) {
    const proteinItems: MealCombination['items'] = [{ menuItem: highProteinMain, role: 'MAIN' }];

    // Complement with high-fiber or light starter
    const starterOrSide = [...safeItems]
      .filter((i) => i.id !== highProteinMain.id && i.calories <= Math.max(150, mealCalorieBudget - highProteinMain.calories + 50))
      .sort((a, b) => b.protein + b.fiber - (a.protein + a.fiber))[0];

    if (starterOrSide) {
      proteinItems.push({ menuItem: starterOrSide, role: 'STARTER' });
    }

    const totals = calculateMealTotals(proteinItems);
    combinations.push({
      mealType,
      restaurantId,
      restaurantName,
      items: proteinItems,
      ...totals,
      combinedScore: Math.round(
        proteinItems.reduce((acc, it) => acc + evaluateDishRecommendation(it.menuItem, profile).score, 0) /
          proteinItems.length
      ),
      goalFitVerdict: 'Maximum Protein Focus',
      explanation: `Packaged with ${totals.totalProtein}g total protein to optimize muscle recovery and fullness.`,
    });
  }

  // Combo 3: Light & Lean / High Fiber Combo
  const leanItemsList = [...safeItems].filter((i) => i.calories <= mealCalorieBudget * 0.7);
  if (leanItemsList.length >= 2) {
    const bestLeanMain = leanItemsList.sort((a, b) => b.fiber / (b.calories || 1) - a.fiber / (a.calories || 1))[0];
    const bestLeanSide = leanItemsList.filter((i) => i.id !== bestLeanMain.id)[0];

    if (bestLeanMain && bestLeanSide) {
      const leanComboItems: MealCombination['items'] = [
        { menuItem: bestLeanMain, role: 'MAIN' },
        { menuItem: bestLeanSide, role: 'SIDE' },
      ];
      const totals = calculateMealTotals(leanComboItems);
      combinations.push({
        mealType,
        restaurantId,
        restaurantName,
        items: leanComboItems,
        ...totals,
        combinedScore: Math.round(
          leanComboItems.reduce((acc, it) => acc + evaluateDishRecommendation(it.menuItem, profile).score, 0) /
            leanComboItems.length
        ),
        goalFitVerdict: 'Light, Nutrient-Dense & High-Fiber',
        explanation: `A lighter meal option delivering ${totals.totalFiber}g fiber at only ${totals.totalCalories} total calories.`,
      });
    }
  }

  return combinations;
}

function calculateMealTotals(items: MealCombination['items']) {
  let totalCalories = 0;
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFat = 0;
  let totalFiber = 0;
  let totalSodium = 0;

  for (const { menuItem } of items) {
    totalCalories += menuItem.calories;
    totalProtein += menuItem.protein;
    totalCarbs += menuItem.carbohydrates;
    totalFat += menuItem.fat;
    totalFiber += menuItem.fiber || 0;
    totalSodium += menuItem.sodium || 0;
  }

  return {
    totalCalories: Math.round(totalCalories),
    totalProtein: Math.round(totalProtein * 10) / 10,
    totalCarbs: Math.round(totalCarbs * 10) / 10,
    totalFat: Math.round(totalFat * 10) / 10,
    totalFiber: Math.round(totalFiber * 10) / 10,
    totalSodium: Math.round(totalSodium),
  };
}
