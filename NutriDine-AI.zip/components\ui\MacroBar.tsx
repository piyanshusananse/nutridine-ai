'use client';

import React from 'react';

interface MacroBarProps {
  protein: number;
  carbs: number;
  fat: number;
  calories?: number;
  compact?: boolean;
}

export function MacroBar({ protein, carbs, fat, calories, compact = false }: MacroBarProps) {
  const proteinCals = protein * 4;
  const carbsCals = carbs * 4;
  const fatCals = fat * 9;
  const totalCals = proteinCals + carbsCals + fatCals || 1;

  const proteinPct = Math.round((proteinCals / totalCals) * 100);
  const carbsPct = Math.round((carbsCals / totalCals) * 100);
  const fatPct = Math.round((fatCals / totalCals) * 100);

  if (compact) {
    return (
      <div className="space-y-1 w-full">
        <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full flex overflow-hidden">
          <div style={{ width: `${proteinPct}%` }} className="bg-emerald-500 transition-all" />
          <div style={{ width: `${carbsPct}%` }} className="bg-sky-400 transition-all" />
          <div style={{ width: `${fatPct}%` }} className="bg-amber-400 transition-all" />
        </div>
        <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400">
          <span className="text-emerald-700 dark:text-emerald-400 font-semibold">{protein}g Protein</span>
          <span className="text-sky-700 dark:text-sky-400 font-semibold">{carbs}g Carbs</span>
          <span className="text-amber-700 dark:text-amber-400 font-semibold">{fat}g Fat</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 dark:bg-slate-900/60 rounded-xl p-3 border border-slate-100 dark:border-slate-800 space-y-2">
      {calories && (
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Energy Breakdown
          </span>
          <span className="text-xs font-bold text-slate-900 dark:text-white">{calories} kcal</span>
        </div>
      )}
      <div className="h-2 w-full bg-slate-200 dark:bg-slate-700 rounded-full flex overflow-hidden">
        <div style={{ width: `${proteinPct}%` }} className="bg-emerald-500 transition-all" title={`Protein: ${proteinPct}%`} />
        <div style={{ width: `${carbsPct}%` }} className="bg-sky-400 transition-all" title={`Carbs: ${carbsPct}%`} />
        <div style={{ width: `${fatPct}%` }} className="bg-amber-400 transition-all" title={`Fat: ${fatPct}%`} />
      </div>
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/40 rounded-lg p-1.5">
          <div className="text-[10px] uppercase font-bold text-emerald-700 dark:text-emerald-400">Protein</div>
          <div className="font-extrabold text-slate-900 dark:text-white">{protein}g</div>
          <div className="text-[9px] text-emerald-600 dark:text-emerald-500">{proteinPct}%</div>
        </div>
        <div className="bg-sky-50 dark:bg-sky-950/40 border border-sky-100 dark:border-sky-900/40 rounded-lg p-1.5">
          <div className="text-[10px] uppercase font-bold text-sky-700 dark:text-sky-400">Carbs</div>
          <div className="font-extrabold text-slate-900 dark:text-white">{carbs}g</div>
          <div className="text-[9px] text-sky-600 dark:text-sky-500">{carbsPct}%</div>
        </div>
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/40 rounded-lg p-1.5">
          <div className="text-[10px] uppercase font-bold text-amber-700 dark:text-amber-400">Fat</div>
          <div className="font-extrabold text-slate-900 dark:text-white">{fat}g</div>
          <div className="text-[9px] text-amber-600 dark:text-amber-500">{fatPct}%</div>
        </div>
      </div>
    </div>
  );
}
