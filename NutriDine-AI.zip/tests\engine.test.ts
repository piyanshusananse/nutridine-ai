import { calculateBMI } from '../lib/engine/bmi';
import { calculateBMR, calculateEnergyNeeds } from '../lib/engine/bmr-tdee';
import { evaluateHardConstraints } from '../lib/engine/hard-constraints';
import { buildSmartMealCombinations } from '../lib/engine/meal-builder';
import { evaluateDishRecommendation, rankDishesForRemainingDeficit } from '../lib/engine/scoring';
import { findSmartSwaps } from '../lib/engine/smart-swaps';
import { MenuItemData, UserProfileData } from '../lib/engine/types';

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ Assertion Failed: ${message}`);
    process.exit(1);
  } else {
    console.log(`✔ Passed: ${message}`);
  }
}

console.log('=== Running NutriDine AI Engine Verification Tests ===\n');

// 1. Test BMI Calculation
console.log('--- 1. Testing BMI Calculation ---');
const bmiHealthy = calculateBMI(70, 175);
assert(bmiHealthy.bmi === 22.9, 'BMI for 70kg / 175cm should be 22.9');
assert(bmiHealthy.category === 'Healthy range', 'Category should be Healthy range');

const bmiOverweight = calculateBMI(85, 170);
assert(bmiOverweight.bmi === 29.4, 'BMI for 85kg / 170cm should be 29.4');
assert(bmiOverweight.category === 'Overweight', 'Category should be Overweight');

// 2. Test Mifflin-St Jeor BMR & TDEE Calculations
console.log('\n--- 2. Testing Mifflin-St Jeor BMR & Energy Needs ---');
// Male: 10 * 82 + 6.25 * 175 - 5 * 28 + 5 = 820 + 1093.75 - 140 + 5 = 1778.75 -> 1779
const maleBmr = calculateBMR(82, 175, 28, 'MALE');
assert(maleBmr === 1779, `Male BMR should be 1779, got ${maleBmr}`);

// Female: 10 * 56 + 6.25 * 163 - 5 * 26 - 161 = 560 + 1018.75 - 130 - 161 = 1287.75 -> 1288
const femaleBmr = calculateBMR(56, 163, 26, 'FEMALE');
assert(femaleBmr === 1288, `Female BMR should be 1288, got ${femaleBmr}`);

// Energy Needs for Alex (82kg, 175cm, 28M, Moderate Activity, Weight Loss)
const alexNeeds = calculateEnergyNeeds(82, 175, 28, 'MALE', 'MODERATE', 'WEIGHT_LOSS');
// TDEE = 1779 * 1.55 = 2757; Deficit = 2757 - 500 = 2257
assert(alexNeeds.tdee === 2757, `Alex TDEE should be 2757, got ${alexNeeds.tdee}`);
assert(alexNeeds.targetCalories === 2257, `Alex Target Calories should be 2257, got ${alexNeeds.targetCalories}`);
assert(alexNeeds.proteinRangeMin >= 130, 'Alex Protein Range Min should be >= 130g');

// 3. Test Hard Constraints & Allergen Exclusions
console.log('\n--- 3. Testing Hard Constraints & Allergen Exclusions ---');

const mockDishButterChicken: MenuItemData = {
  id: 'dish-1',
  restaurantId: 'rest-1',
  categoryId: 'cat-1',
  name: 'Butter Chicken',
  description: 'Rich curry with cashew cream and butter',
  price: 18.0,
  servingSize: '350g',
  calories: 780,
  protein: 38,
  carbohydrates: 18,
  fat: 58,
  fiber: 3,
  sugar: 10,
  sodium: 890,
  saturatedFat: 26,
  ingredients: 'Chicken, cream, butter, cashews, spices',
  allergens: 'DAIRY, TREE_NUTS',
  isVegetarian: false,
  isVegan: false,
  isGlutenFree: true,
  isDairyFree: false,
  spicyLevel: 1,
  isAvailable: true,
  nutritionSource: 'EXACT',
};

const mockDishTandooriChicken: MenuItemData = {
  id: 'dish-2',
  restaurantId: 'rest-1',
  categoryId: 'cat-1',
  name: 'Tandoori Chicken Tikka',
  description: 'Lean chicken roasted in tandoor',
  price: 17.0,
  servingSize: '280g',
  calories: 380,
  protein: 48,
  carbohydrates: 6,
  fat: 16,
  fiber: 2,
  sugar: 2,
  sodium: 580,
  saturatedFat: 4,
  ingredients: 'Chicken, yogurt, spices',
  allergens: 'DAIRY',
  isVegetarian: false,
  isVegan: false,
  isGlutenFree: true,
  isDairyFree: false,
  spicyLevel: 2,
  isAvailable: true,
  nutritionSource: 'EXACT',
};

const mockDishDalTadka: MenuItemData = {
  id: 'dish-3',
  restaurantId: 'rest-1',
  categoryId: 'cat-2',
  name: 'Yellow Dal Tadka',
  description: 'Yellow lentils with cumin and garlic',
  price: 13.0,
  servingSize: '350g',
  calories: 260,
  protein: 16,
  carbohydrates: 36,
  fat: 6,
  fiber: 12,
  sugar: 3,
  sodium: 480,
  saturatedFat: 1,
  ingredients: 'Lentils, tomatoes, cumin, garlic',
  allergens: '',
  isVegetarian: true,
  isVegan: true,
  isGlutenFree: true,
  isDairyFree: true,
  spicyLevel: 1,
  isAvailable: true,
  nutritionSource: 'EXACT',
};

const priyaProfile: UserProfileData = {
  name: 'Priya',
  age: 26,
  sex: 'FEMALE',
  heightCm: 163,
  weightKg: 56,
  activityLevel: 'LIGHT',
  goal: 'MUSCLE_GAIN',
  dietaryPreferences: ['VEGETARIAN'],
  allergies: ['TREE_NUTS'],
};

const priyaButterChickenCheck = evaluateHardConstraints(mockDishButterChicken, priyaProfile);
assert(priyaButterChickenCheck.isExcluded === true, 'Butter chicken must be excluded for Priya (Vegetarian & Tree Nut allergen)');
assert(priyaButterChickenCheck.hasAllergenConflict === true, 'Priya allergen conflict should be triggered (cashew/tree nuts)');
assert(priyaButterChickenCheck.hasDietaryConflict === true, 'Priya dietary conflict should be triggered (not vegetarian)');

const priyaDalCheck = evaluateHardConstraints(mockDishDalTadka, priyaProfile);
assert(priyaDalCheck.isExcluded === false, 'Dal Tadka should be allowed for Priya');

// 4. Test Multi-Persona Differential Scoring
console.log('\n--- 4. Testing Multi-Persona Recommendation Scoring ---');
const alexProfile: UserProfileData = {
  name: 'Alex',
  age: 28,
  sex: 'MALE',
  heightCm: 175,
  weightKg: 82,
  activityLevel: 'MODERATE',
  goal: 'WEIGHT_LOSS',
  dietaryPreferences: ['NON_VEGETARIAN'],
  allergies: [],
};

const alexTandooriRec = evaluateDishRecommendation(mockDishTandooriChicken, alexProfile);
const alexButterRec = evaluateDishRecommendation(mockDishButterChicken, alexProfile);

assert(alexTandooriRec.score >= 85, `Alex Tandoori score should be >= 85 (Best Choice), got ${alexTandooriRec.score}`);
assert(alexTandooriRec.category === 'BEST_CHOICE', 'Alex Tandoori category should be BEST_CHOICE');
assert(alexButterRec.score < alexTandooriRec.score, 'Butter chicken should score lower than Tandoori for weight loss');

// 5. Test Smart Swaps
console.log('\n--- 5. Testing Smart Food Swaps ---');
const swapResult = findSmartSwaps(
  mockDishButterChicken,
  [mockDishButterChicken, mockDishTandooriChicken, mockDishDalTadka],
  alexProfile
);
assert(swapResult !== null, 'Smart swap should return an alternative');
assert(swapResult!.betterDish.id === mockDishTandooriChicken.id, 'Smart swap should suggest Tandoori Chicken over Butter Chicken');
assert(swapResult!.calorieDiff < 0, 'Calorie diff should show reduction');
assert(swapResult!.actionableTips.length > 0, 'Actionable tips should be provided');

// 6. Test Meal Combination Builder
console.log('\n--- 6. Testing Meal Combination Builder ---');
const mealCombos = buildSmartMealCombinations(
  'rest-1',
  'Mumbai Spice House',
  [mockDishTandooriChicken, mockDishDalTadka, mockDishButterChicken],
  alexProfile,
  'DINNER',
  700
);
assert(mealCombos.length > 0, 'Should generate at least 1 valid meal combination');
assert(mealCombos[0].totalCalories <= 800, `Combo total calories should fit budget, got ${mealCombos[0].totalCalories}`);

// 7. Test Smart "What Should I Eat Now?" Deficit Matcher
console.log('\n--- 7. Testing Smart Deficit Matcher (What Should I Eat Now?) ---');

const alexRemainingDeficit = {
  remainingCalories: 550,
  remainingProtein: 45,
  remainingCarbs: 40,
  remainingFat: 20,
  remainingFiber: 10,
  maxBudgetRupees: 500,
};

const deficitRecommendations = rankDishesForRemainingDeficit(
  [mockDishTandooriChicken, mockDishDalTadka, mockDishButterChicken],
  alexProfile,
  alexRemainingDeficit
);

assert(deficitRecommendations.length > 0, 'Should return ranked deficit recommendations');
assert(
  deficitRecommendations[0].dish.id === mockDishTandooriChicken.id,
  'Tandoori Chicken should be rank 1 (Provides 48g protein within 550 kcal budget)'
);
assert(deficitRecommendations[0].score >= 80, `Top deficit match score should be >= 80, got ${deficitRecommendations[0].score}`);
assert(deficitRecommendations[0].detailedWhy.includes('protein remaining'), 'Reason should mention remaining protein');

console.log('\n=============================================');
console.log('🎉 ALL NUTRIDINE AI ENGINE TESTS PASSED! 🎉');
console.log('=============================================\n');

