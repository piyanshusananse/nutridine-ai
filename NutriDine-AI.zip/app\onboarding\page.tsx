'use client';

import { useUser } from '@/context/UserContext';
import { calculateBMI } from '@/lib/engine/bmi';
import { calculateEnergyNeeds } from '@/lib/engine/bmr-tdee';
import {
  ActivityLevel,
  AllergenType,
  DietaryPreferenceType,
  Sex,
  UserGoal,
  UserProfileData,
} from '@/lib/engine/types';
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Heart,
  HelpCircle,
  Info,
  Layers,
  Scale,
  ShieldAlert,
  Sparkles,
  Target,
  User,
  Zap,
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import React, { useState } from 'react';

const DIETARY_OPTIONS: { id: DietaryPreferenceType; label: string; icon: string }[] = [
  { id: 'NON_VEGETARIAN', label: 'Non-Vegetarian', icon: '🍗' },
  { id: 'VEGETARIAN', label: 'Vegetarian', icon: '🥦' },
  { id: 'VEGAN', label: '100% Vegan', icon: '🌱' },
  { id: 'EGGETARIAN', label: 'Eggetarian', icon: '🥚' },
  { id: 'PESCATARIAN', label: 'Pescatarian (Fish)', icon: '🐟' },
  { id: 'JAIN', label: 'Jain (No Root Veg)', icon: '🌿' },
  { id: 'HALAL', label: 'Halal Certified', icon: '🌙' },
  { id: 'GLUTEN_FREE', label: 'Gluten-Free Diet', icon: '🌾' },
  { id: 'LACTOSE_FREE', label: 'Dairy / Lactose-Free', icon: '🥛' },
  { id: 'LOW_CARB', label: 'Low-Carb / Keto', icon: '🥑' },
];

const ALLERGEN_OPTIONS: { id: AllergenType; label: string; icon: string }[] = [
  { id: 'PEANUTS', label: 'Peanuts', icon: '🥜' },
  { id: 'TREE_NUTS', label: 'Tree Nuts (Almonds, Cashews, Walnuts)', icon: '🌰' },
  { id: 'DAIRY', label: 'Dairy / Milk Products', icon: '🧀' },
  { id: 'EGGS', label: 'Eggs', icon: '🥚' },
  { id: 'SOY', label: 'Soy / Soya', icon: '🫘' },
  { id: 'GLUTEN', label: 'Wheat / Gluten', icon: '🌾' },
  { id: 'SHELLFISH', label: 'Shellfish / Prawns / Crab', icon: '🦐' },
  { id: 'FISH', label: 'Fish', icon: '🐟' },
  { id: 'SESAME', label: 'Sesame Seeds', icon: '🌱' },
  { id: 'MUSTARD', label: 'Mustard Seeds / Oil', icon: '🟡' },
];

export default function OnboardingPage() {
  const router = useRouter();
  const { updateProfile, showToast } = useUser();

  const [step, setStep] = useState<number>(1);

  // Form State
  const [name, setName] = useState('Alex');
  const [age, setAge] = useState<number>(28);
  const [sex, setSex] = useState<Sex>('MALE');
  const [heightCm, setHeightCm] = useState<number>(175);
  const [weightKg, setWeightKg] = useState<number>(75);

  const [activityLevel, setActivityLevel] = useState<ActivityLevel>('MODERATE');
  const [goal, setGoal] = useState<UserGoal>('WEIGHT_LOSS');
  const [customGoal, setCustomGoal] = useState('');

  const [dietaryPrefs, setDietaryPrefs] = useState<DietaryPreferenceType[]>(['NON_VEGETARIAN']);
  const [allergies, setAllergies] = useState<AllergenType[]>([]);
  const [spicyPref, setSpicyPref] = useState<'MILD' | 'MEDIUM' | 'SPICY' | 'VERY_SPICY'>('MEDIUM');

  // Step 4: Optional wellness markers & Calorie override
  const [restingHR, setRestingHR] = useState<string>('68');
  const [dailySteps, setDailySteps] = useState<string>('8000');
  const [dailyWater, setDailyWater] = useState<string>('2500');
  const [sleepHours, setSleepHours] = useState<string>('7.5');
  const [calorieOverride, setCalorieOverride] = useState<string>('');

  // Live Calculations
  const liveBmi = calculateBMI(weightKg, heightCm);
  const liveEnergy = calculateEnergyNeeds(
    weightKg,
    heightCm,
    age,
    sex,
    activityLevel,
    goal,
    calorieOverride ? parseInt(calorieOverride, 10) : null
  );

  const toggleDietary = (pref: DietaryPreferenceType) => {
    if (dietaryPrefs.includes(pref)) {
      setDietaryPrefs(dietaryPrefs.filter((p) => p !== pref));
    } else {
      setDietaryPrefs([...dietaryPrefs, pref]);
    }
  };

  const toggleAllergy = (allergen: AllergenType) => {
    if (allergies.includes(allergen)) {
      setAllergies(allergies.filter((a) => a !== allergen));
    } else {
      setAllergies([...allergies, allergen]);
    }
  };

  const handleFinish = async () => {
    const finalProfile: UserProfileData = {
      name: name || 'Diner',
      age: Number(age) || 28,
      sex,
      heightCm: Number(heightCm) || 175,
      weightKg: Number(weightKg) || 75,
      activityLevel,
      goal,
      customGoalDesc: customGoal,
      targetCaloriesOverride: calorieOverride ? parseInt(calorieOverride, 10) : null,
      spicyPreference: spicyPref,
      dietaryPreferences: dietaryPrefs,
      allergies,
      healthMarkers: {
        restingHeartRate: restingHR ? parseInt(restingHR, 10) : undefined,
        dailySteps: dailySteps ? parseInt(dailySteps, 10) : undefined,
        dailyWaterIntakeMl: dailyWater ? parseInt(dailyWater, 10) : undefined,
        sleepDurationHours: sleepHours ? parseFloat(sleepHours) : undefined,
      },
    };

    updateProfile(finalProfile);

    // Save to API
    try {
      await fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(finalProfile),
      });
    } catch (e) {
      console.warn('Local save active:', e);
    }

    showToast(`Welcome ${name}! Your personalized recommendation targets are active.`);
    router.push('/restaurants');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 sm:py-12 space-y-8">
      {/* Step Progress Tracker */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-black uppercase tracking-wider text-slate-500">
          <span>Step {step} of 4</span>
          <span className="text-emerald-600 dark:text-emerald-400">
            {step === 1 && 'Basic Information'}
            {step === 2 && 'Lifestyle & Fitness Goal'}
            {step === 3 && 'Dietary & Allergies'}
            {step === 4 && 'Wellness Targets Review'}
          </span>
        </div>
        <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-full flex overflow-hidden">
          <div
            style={{ width: `${(step / 4) * 100}%` }}
            className="bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-300"
          />
        </div>
      </div>

      {/* STEP 1: BASIC INFORMATION */}
      {step === 1 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6 animate-in fade-in duration-200">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">Basic Information</h2>
            <p className="text-xs text-slate-500">
              Tell us about your body metrics so we can accurately estimate your baseline energy needs.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                First Name / Nickname
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Alex"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Biological Sex</label>
              <div className="grid grid-cols-3 gap-2">
                {(['MALE', 'FEMALE', 'OTHER'] as Sex[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSex(s)}
                    className={`py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                      sex === s
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Age</label>
              <input
                type="number"
                min={14}
                max={100}
                value={age}
                onChange={(e) => setAge(parseInt(e.target.value, 10) || 25)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Height: <span className="text-emerald-600 font-extrabold">{heightCm} cm</span> (
                {Math.floor(heightCm / 30.48)}&apos;{Math.round((heightCm % 30.48) / 2.54)}&quot;)
              </label>
              <input
                type="range"
                min={130}
                max={220}
                value={heightCm}
                onChange={(e) => setHeightCm(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600 mt-2"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Weight: <span className="text-emerald-600 font-extrabold">{weightKg} kg</span> (
                {Math.round(weightKg * 2.20462)} lbs)
              </label>
              <input
                type="range"
                min={35}
                max={160}
                value={weightKg}
                onChange={(e) => setWeightKg(parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600 mt-2"
              />
            </div>
          </div>

          {/* Live BMI Preview Card */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Calculated Baseline Indicator
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xl font-black text-slate-900 dark:text-white">BMI: {liveBmi.bmi}</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  {liveBmi.category}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 max-w-lg">{liveBmi.disclaimer}</p>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/20 cursor-pointer"
            >
              <span>Continue to Lifestyle & Goals</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: LIFESTYLE & GOALS */}
      {step === 2 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6 animate-in fade-in duration-200">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">Lifestyle & Primary Goal</h2>
            <p className="text-xs text-slate-500">
              Select your activity level and fitness objective so we can calibrate your energy targets.
            </p>
          </div>

          {/* Activity Level */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Activity Level</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {[
                { id: 'SEDENTARY', label: 'Sedentary', desc: 'Desk job, little workout' },
                { id: 'LIGHT', label: 'Lightly Active', desc: '1–3 light workouts / week' },
                { id: 'MODERATE', label: 'Moderately Active', desc: '3–5 moderate workouts / week' },
                { id: 'VERY_ACTIVE', label: 'Very Active', desc: '6–7 intense workouts / week' },
                { id: 'EXTRA_ACTIVE', label: 'Extremely Active', desc: 'Athletic training / physical job' },
              ].map((act) => (
                <button
                  key={act.id}
                  type="button"
                  onClick={() => setActivityLevel(act.id as ActivityLevel)}
                  className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                    activityLevel === act.id
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 shadow'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                  }`}
                >
                  <div className="font-extrabold text-xs text-slate-900 dark:text-white">{act.label}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{act.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Goal Selector */}
          <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Primary Fitness Goal</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {[
                { id: 'WEIGHT_LOSS', label: 'Weight / Fat Loss', icon: '🔥', desc: 'Caloric deficit with high satiety & protein' },
                { id: 'MUSCLE_GAIN', label: 'Muscle Gain & Hypertrophy', icon: '💪', desc: 'Caloric surplus with high protein priority' },
                { id: 'MAINTENANCE', label: 'Weight Maintenance', icon: '⚖️', desc: 'Balanced macronutrients for steady weight' },
                { id: 'BETTER_NUTRITION', label: 'Better General Nutrition', icon: '🥗', desc: 'Clean whole foods, high fiber & micronutrients' },
                { id: 'IMPROVED_PROTEIN', label: 'Improved Protein Intake', icon: '🥩', desc: 'Optimize daily protein for tone & recovery' },
                { id: 'BETTER_ENERGY', label: 'Better Energy & Vitality', icon: '⚡', desc: 'Complex carbs with steady glycemic load' },
                { id: 'NOT_SURE', label: 'Not Sure (Balanced Default)', icon: '🧭', desc: 'Intelligent balanced maintenance' },
              ].map((g) => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => setGoal(g.id as UserGoal)}
                  className={`p-3 rounded-2xl text-left border transition-all flex items-start gap-3 cursor-pointer ${
                    goal === g.id
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 shadow'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                  }`}
                >
                  <span className="text-2xl shrink-0">{g.icon}</span>
                  <div>
                    <div className="font-extrabold text-xs text-slate-900 dark:text-white">{g.label}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{g.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white text-xs font-bold"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={() => setStep(3)}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/20 cursor-pointer"
            >
              <span>Continue to Dietary & Allergies</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: DIETARY & ALLERGIES */}
      {step === 3 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6 animate-in fade-in duration-200">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">Dietary & Allergies</h2>
            <p className="text-xs text-slate-500">
              Hard constraints strictly override nutrition scoring for your safety.
            </p>
          </div>

          {/* Prominent Allergy Disclaimer */}
          <div className="bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 p-4 rounded-2xl flex items-start gap-3 text-rose-900 dark:text-rose-200 text-xs">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-extrabold uppercase tracking-wider block">Important Safety Rule:</span>
              <p className="mt-0.5 text-slate-700 dark:text-slate-300">
                Restaurant ingredient information may be incomplete. Always verify allergens with restaurant staff before consuming.
              </p>
            </div>
          </div>

          {/* Allergy Selector */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold uppercase tracking-wider text-rose-700 dark:text-rose-400 block">
              Declared Food Allergies (Dishes with these will be excluded):
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {ALLERGEN_OPTIONS.map((a) => {
                const isSelected = allergies.includes(a.id);
                return (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => toggleAllergy(a.id)}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-rose-600 text-white border-rose-600 shadow-md font-bold'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-rose-300'
                    }`}
                  >
                    <span>{a.icon}</span>
                    <span className="text-xs truncate">{a.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dietary Preferences */}
          <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              Dietary Lifestyle Preferences:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {DIETARY_OPTIONS.map((d) => {
                const isSelected = dietaryPrefs.includes(d.id);
                return (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => toggleDietary(d.id)}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow font-bold'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
                    }`}
                  >
                    <span>{d.icon}</span>
                    <span className="text-xs truncate">{d.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Spicy Preference */}
          <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Spicy Food Tolerance</label>
            <div className="grid grid-cols-4 gap-2">
              {(['MILD', 'MEDIUM', 'SPICY', 'VERY_SPICY'] as const).map((sp) => (
                <button
                  key={sp}
                  type="button"
                  onClick={() => setSpicyPref(sp)}
                  className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    spicyPref === sp
                      ? 'bg-orange-500 text-white border-orange-500 shadow'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {sp === 'MILD' && '🌶️ Mild'}
                  {sp === 'MEDIUM' && '🌶️🌶️ Med'}
                  {sp === 'SPICY' && '🌶️🌶️🌶️ Hot'}
                  {sp === 'VERY_SPICY' && '🔥 Extra'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white text-xs font-bold"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={() => setStep(4)}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/20 cursor-pointer"
            >
              <span>Continue to Target Summary</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: HEALTH MARKERS & ESTIMATED TARGETS REVIEW */}
      {step === 4 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6 animate-in fade-in duration-200">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">Estimated Wellness Targets</h2>
            <p className="text-xs text-slate-500">
              Calculated using standard Mifflin-St Jeor metabolic equations. You can override your target calories anytime.
            </p>
          </div>

          {/* Energy Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
                Estimated TDEE
              </span>
              <span className="text-2xl font-black text-slate-900 dark:text-white mt-1 block">
                {liveEnergy.tdee} <span className="text-xs font-medium text-slate-400">kcal/day</span>
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Basal BMR: {liveEnergy.bmr} kcal</span>
            </div>

            <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800">
              <span className="text-[10px] font-black uppercase tracking-wider text-teal-700 dark:text-teal-400 block">
                Goal Target Energy
              </span>
              <span className="text-2xl font-black text-slate-900 dark:text-white mt-1 block">
                {liveEnergy.targetCalories} <span className="text-xs font-medium text-slate-400">kcal</span>
              </span>
              <span className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold block mt-0.5">
                {goal === 'WEIGHT_LOSS' ? 'Deficit for fat loss' : 'Calibrated for goal'}
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800">
              <span className="text-[10px] font-black uppercase tracking-wider text-sky-700 dark:text-sky-400 block">
                Protein Range
              </span>
              <span className="text-2xl font-black text-slate-900 dark:text-white mt-1 block">
                {liveEnergy.proteinRangeMin}–{liveEnergy.proteinRangeMax} <span className="text-xs font-medium text-slate-400">g</span>
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Supports lean mass</span>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800">
              <span className="text-[10px] font-black uppercase tracking-wider text-purple-700 dark:text-purple-400 block">
                Hydration Target
              </span>
              <span className="text-2xl font-black text-slate-900 dark:text-white mt-1 block">
                {liveEnergy.waterTargetLiters} <span className="text-xs font-medium text-slate-400">Liters</span>
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">Daily fluid intake</span>
            </div>
          </div>

          {/* Optional Calorie Target Override */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Manual Calorie Target Override (Optional)
              </label>
              <span className="text-[11px] text-slate-400">Leave blank to use estimated {liveEnergy.targetCalories} kcal</span>
            </div>
            <input
              type="number"
              value={calorieOverride}
              onChange={(e) => setCalorieOverride(e.target.value)}
              placeholder={`e.g. ${liveEnergy.targetCalories}`}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none dark:text-white"
            />
          </div>

          {/* Optional Health Markers Inputs */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-500" />
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Optional General Health Markers
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              These are general wellness inputs and are not a medical diagnosis.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  Resting HR (bpm)
                </label>
                <input
                  type="number"
                  value={restingHR}
                  onChange={(e) => setRestingHR(e.target.value)}
                  placeholder="68"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  Daily Steps Goal
                </label>
                <input
                  type="number"
                  value={dailySteps}
                  onChange={(e) => setDailySteps(e.target.value)}
                  placeholder="8000"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  Water Goal (ml)
                </label>
                <input
                  type="number"
                  value={dailyWater}
                  onChange={(e) => setDailyWater(e.target.value)}
                  placeholder="2500"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs dark:text-white"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  Sleep (Hours)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={sleepHours}
                  onChange={(e) => setSleepHours(e.target.value)}
                  placeholder="7.5"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs dark:text-white"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setStep(3)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white text-xs font-bold"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={handleFinish}
              className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm shadow-xl shadow-emerald-600/30 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Save & View Recommendations</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
