'use client';

import { useUser } from '@/context/UserContext';
import { ArrowRight, Scale, Trash2, X } from 'lucide-react';
import Link from 'next/link';
import React from 'react';

export function ComparisonTray() {
  const { comparisonDishes, removeFromComparison, clearComparison } = useUser();

  if (comparisonDishes.length === 0) return null;

  return (
    <div className="fixed bottom-16 sm:bottom-6 left-1/2 transform -translate-x-1/2 z-40 w-11/12 max-w-2xl animate-in slide-in-from-bottom-5 duration-200">
      <div className="bg-slate-900/95 text-white backdrop-blur-lg rounded-2xl p-3 sm:p-4 shadow-2xl border border-slate-700 flex items-center justify-between gap-3">
        {/* Left info */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-extrabold flex items-center gap-2">
              <span>Compare Dishes</span>
              <span className="px-1.5 py-0.5 rounded bg-sky-600 text-[10px] text-white">
                {comparisonDishes.length}/3
              </span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              {comparisonDishes.map((dish) => (
                <div
                  key={dish.id}
                  className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded-lg text-[11px] font-medium text-slate-200 max-w-[120px]"
                >
                  <span className="truncate">{dish.name}</span>
                  <button
                    onClick={() => removeFromComparison(dish.id)}
                    className="text-slate-400 hover:text-white cursor-pointer ml-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right CTA */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={clearComparison}
            className="p-2 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
            title="Clear all"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <Link
            href="/compare"
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs transition-all shadow-lg shadow-sky-500/30"
          >
            <span>Compare Now</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
