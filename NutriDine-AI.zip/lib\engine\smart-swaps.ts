import { evaluateDishRecommendation } from './scoring';
import { MenuItemData, SmartSwapRecommendation, UserProfileData } from './types';

/**
 * Finds intelligent, menu-aware food swaps strictly from the SAME restaurant
 * and generates practical "Make It Better" actionable preparation tips.
 */
export function findSmartSwaps(
  targetDish: MenuItemData,
  restaurantMenu: MenuItemData[],
  profile: UserProfileData
): SmartSwapRecommendation | null {
  const currentRec = evaluateDishRecommendation(targetDish, profile);

  // If the dish is already a top-tier "Best Choice" (score >= 88), no urgent swap needed
  // but we can still suggest preparation tweaks
  const otherItems = restaurantMenu.filter((item) => item.id !== targetDish.id && item.isAvailable);

  // Score all other dishes from the same restaurant
  const scoredAlternatives = otherItems
    .map((item) => ({
      item,
      rec: evaluateDishRecommendation(item, profile),
    }))
    .filter((entry) => !entry.rec.hasAllergenConflict && !entry.rec.hasDietaryConflict)
    .sort((a, b) => b.rec.score - a.rec.score);

  // Find a dish in the same category or adjacent main/starter category that has a strictly higher score
  const betterOption = scoredAlternatives.find(
    (alt) =>
      alt.rec.score > currentRec.score + 10 &&
      (alt.item.categoryId === targetDish.categoryId ||
        alt.item.isVegetarian === targetDish.isVegetarian ||
        alt.rec.score >= 82)
  );

  // Actionable "Make It Better" preparation tips
  const actionableTips: string[] = [];

  const dishNameLower = targetDish.name.toLowerCase();
  const descLower = targetDish.description.toLowerCase();
  const prepLower = (targetDish.preparationMethod || '').toLowerCase();

  if (descLower.includes('cream') || descLower.includes('butter') || descLower.includes('gravy') || descLower.includes('sauce') || descLower.includes('mayo')) {
    actionableTips.push('Ask for creamy sauces, gravies, or dressing served on the side so you control portion size.');
  }

  if (prepLower.includes('fried') || descLower.includes('crispy') || descLower.includes('deep fried')) {
    actionableTips.push('Ask if the kitchen can prepare this grilled, baked, or tandoori-roasted instead of deep-fried.');
  }

  if (descLower.includes('fries') || descLower.includes('naan') || descLower.includes('white rice')) {
    actionableTips.push('Swap heavy sides (fries, butter naan) for a fresh garden salad, steamed broccoli, or tandoori roti.');
  }

  if (targetDish.calories > 750) {
    actionableTips.push('Portion mindfulness: Share this entrée with a dining companion or box half before starting.');
  }

  if (targetDish.sugar > 15 || descLower.includes('sweet') || descLower.includes('syrup')) {
    actionableTips.push('Enjoy with a splash of fresh lime or hot black tea/sparkling water to balance sweet notes.');
  }

  if (actionableTips.length === 0) {
    actionableTips.push('Request olive oil or light vinaigrette instead of heavier house dressings.');
    actionableTips.push('Pair with extra vegetables or a clear broth soup to boost satiety and fiber.');
  }

  if (!betterOption) {
    // If no single dish has +10 higher score, check if we have any higher scoring dish in the menu
    const topDish = scoredAlternatives[0];
    if (topDish && topDish.rec.score > currentRec.score) {
      return {
        originalDish: targetDish,
        betterDish: topDish.item,
        reason: `A stronger match on this menu is "${topDish.item.name}" with ${topDish.item.protein}g protein and a ${topDish.rec.score}/100 goal match score.`,
        calorieDiff: topDish.item.calories - targetDish.calories,
        proteinDiff: Math.round((topDish.item.protein - targetDish.protein) * 10) / 10,
        actionableTips,
      };
    }

    return {
      originalDish: targetDish,
      betterDish: targetDish,
      reason: `You can customize "${targetDish.name}" with simple ordering modifications to best fit your targets.`,
      calorieDiff: 0,
      proteinDiff: 0,
      actionableTips,
    };
  }

  const calorieDiff = betterOption.item.calories - targetDish.calories;
  const proteinDiff = Math.round((betterOption.item.protein - targetDish.protein) * 10) / 10;

  let swapReason = `"${betterOption.item.name}" is a higher match (${betterOption.rec.score}/100)`;
  if (calorieDiff < 0) {
    swapReason += ` with ${Math.abs(calorieDiff)} fewer calories`;
  }
  if (proteinDiff > 0) {
    swapReason += ` and ${proteinDiff}g more protein`;
  }
  swapReason += ` from this same restaurant.`;

  return {
    originalDish: targetDish,
    betterDish: betterOption.item,
    reason: swapReason,
    calorieDiff,
    proteinDiff,
    actionableTips,
  };
}
